"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var samples_search_filter_pipe_1 = require("../filters/samples-search-filter.pipe");
var samples_status_filter_pipe_1 = require("../filters/samples-status-filter.pipe");
var samples_customer_filter_pipe_1 = require("../filters/samples-customer-filter.pipe");
var dropdown_component_1 = require("ul_portal_components/app/content/form/dropdown.component");
var pager_service_1 = require("ul_portal_components/app/services/pager.service");
var sample_service_1 = require("../shared/sample.service");
var SamplesListComponent = (function () {
    function SamplesListComponent(_sampleService, pagerService) {
        this._sampleService = _sampleService;
        this.pagerService = pagerService;
        this.sortType = '';
        this.parentURL = '';
        this.currentPage = 1;
        this.startIndex = 0;
        this.endIndex = 0;
        this.totalPages = 1;
        this.pager = {};
        this.lastSelectedStatuses = [];
        this.lastSelectedCompanies = [];
    }
    SamplesListComponent.prototype.Configuration = function () {
        var _this = this;
        this._sampleService.GetConfiguration()
            .subscribe(function (data) {
            _this.deepLinkUrl = data;
            _this.parentURL = _this.deepLinkUrl.naftURL;
        });
    };
    /* PBI-15019 Sample List View Components Business Logic Integration */
    SamplesListComponent.prototype.filterStatusResults = function (data) {
        if (data != undefined) {
            this.lastSelectedStatuses = data;
            this.updateList();
        }
    };
    SamplesListComponent.prototype.filterCompanyResults = function (data) {
        if (data != undefined) {
            this.lastSelectedCompanies = data;
            this.updateList();
        }
    };
    //filterDateResults(data: any) {
    //    if (data != undefined) {
    //        this.lastSelectedDateData = data;
    //        this.updateList();
    //    }
    //}
    SamplesListComponent.prototype.searchSamples = function (data) {
        if (data != undefined) {
            this.filterValue = data;
            this.updateList();
        }
    };
    SamplesListComponent.prototype.updateList = function () {
        this.listItems = [];
        for (var i = 0; i < this.samplesList.length; i++) {
            this.listItems.push(this.getColumnObject(this.samplesList[i]));
        }
        if (this.filterValue) {
            var searchPipe = new samples_search_filter_pipe_1.SamplesSearchFilterPipe();
            searchPipe.transform(this.listItems, this.filterValue);
            this.listItems = searchPipe.filteredList;
        }
        if (this.lastSelectedStatuses) {
            var statusPipe = new samples_status_filter_pipe_1.SamplesStatusFilterPipe();
            statusPipe.transform(this.listItems, this.lastSelectedStatuses);
            this.listItems = (statusPipe.filteredValue) ? statusPipe.filteredValue : statusPipe.checkedStatusList;
        }
        if (this.lastSelectedCompanies) {
            var companyPipe = new samples_customer_filter_pipe_1.SamplesCustomerFilterPipe();
            companyPipe.transform(this.listItems, this.lastSelectedCompanies);
            this.listItems = (companyPipe.filteredValue) ? companyPipe.filteredValue : companyPipe.checkedCompanyList;
        }
        //if (this.lastSelectedDateData) {
        //    let datePipe = new SamplesDateFilterPipe();
        //    datePipe.transform(this.listItems, this.lastSelectedDateData);
        //    this.listItems = datePipe.filteredValue;
        //}
        this.pagedItems = this.listItems;
        this.setPage(1);
        this.updatePagingDropdown(this.listItems.length);
    };
    //onSortHeader(data: any) {
    //    this.sortType = (this.selectedSortValue != data.data) ? '' : this.sortType;
    //    this.sortType = ((this.sortType != '') && (this.sortType != 'DES')) ? 'DES' : 'ASC';
    //    this.onSortEvent({ "label": data.data });
    //}
    SamplesListComponent.prototype.onSortEvent = function (data) {
        //if (data.label.indexOf('Highest First') > -1) {
        //    $('.header-col-5 div h6').removeClass("h6-toggle");
        //}
        //if (data.label.indexOf('Lowest First') > -1) {
        //    $('.header-col-5 div h6').addClass("h6-toggle");
        //}
        //if (data.label.indexOf('Oldest First') > -1) {
        //    $('.header-col-3 div h6').removeClass("h6-toggle");
        //}
        //if (data.label.indexOf('Newest First') > -1) {
        //    $('.header-col-3 div h6').addClass("h6-toggle");
        //}
        this.selectedSortValue = data.label;
        this.pagedItems = this.listItems;
        this.setPage(1);
        this.updatePagingDropdown(this.listItems.length);
    };
    SamplesListComponent.prototype.updatePagingDropdown = function (count) {
        if (!this.pager) {
            this.setPage(1);
        }
        var arr = this.pager.pages;
        var pages = new Array();
        for (var i = 0; i < arr.length; i++) {
            pages.push(new dropdown_component_1.DropdownValue((i + 1).toString(), (i + 1).toString()));
        }
        this.pages = pages;
        this.resultCount = count;
    };
    SamplesListComponent.prototype.setPage = function (page) {
        if (page < 1 || page > this.pager.totalPages) {
            return;
        }
        // get pager object from service
        this.pager = this.pagerService.getPager(this.listItems.length, page);
        // get current page of items
        this.startIndex = this.pager.startIndex;
        this.endIndex = this.pager.endIndex + 1;
        this.pagedItems = this.listItems;
        this.selectedPage = new dropdown_component_1.DropdownValue((page).toString(), (page).toString());
    };
    SamplesListComponent.prototype.toggleRefiners = function (data) {
        if (this.enableRefiners) {
            this.enableRefiners = false;
        }
        else {
            this.enableRefiners = true;
        }
    };
    SamplesListComponent.prototype.addCompanyRefinerOptions = function (data) {
        if (!this.refinerCompanyObject[data]) {
            this.refinerCompanyObject[data] = 1;
        }
        else {
            this.refinerCompanyObject[data] = this.refinerCompanyObject[data] + 1;
        }
    };
    SamplesListComponent.prototype.updateRefinerCompanyItems = function () {
        for (var key in this.refinerCompanyObject) {
            if (this.refinerCompanyObject.hasOwnProperty(key)) {
                this.refinerCompanyItems.push({ "label": key, "value": this.refinerCompanyObject[key] });
            }
        }
        this.lastSelectedCompanies = this.refinerCompanyItems;
    };
    SamplesListComponent.prototype.addStatusOptions = function (data) {
        if (!this.refinerStatusObject["Not Received"]) {
            this.refinerStatusObject["Not Received"] = 0;
        }
        if (!this.refinerStatusObject["Received"]) {
            this.refinerStatusObject["Received"] = 0;
        }
        if (!this.refinerStatusObject["Returned to Customer"]) {
            this.refinerStatusObject["Returned to Customer"] = 0;
        }
        if (!this.refinerStatusObject["Customer Picked Up"]) {
            this.refinerStatusObject["Customer Picked Up"] = 0;
        }
        if (!this.refinerStatusObject["Destroyed"]) {
            this.refinerStatusObject["Destroyed"] = 0;
        }
        if (!this.refinerStatusObject["Archived"]) {
            this.refinerStatusObject["Archived"] = 0;
        }
        if (!this.refinerStatusObject[data]) {
            this.refinerStatusObject[data] = 1;
        }
        else {
            this.refinerStatusObject[data] = this.refinerStatusObject[data] + 1;
        }
    };
    SamplesListComponent.prototype.updateRefinerStatusItems = function () {
        for (var key in this.refinerStatusObject) {
            if (this.refinerStatusObject.hasOwnProperty(key)) {
                this.refinerStatusItems.push({ "label": key, "value": this.refinerStatusObject[key] });
            }
        }
        var arr = new Array();
        for (var i = 0; i < this.refinerStatusItems.length; i++) {
            if (this.refinerStatusItems[i].label == 'Not Received') {
                arr.push(this.refinerStatusItems[i]);
            }
        }
        for (var i = 0; i < this.refinerStatusItems.length; i++) {
            if (this.refinerStatusItems[i].label == 'Received') {
                arr.push(this.refinerStatusItems[i]);
            }
        }
        for (var i = 0; i < this.refinerStatusItems.length; i++) {
            if (this.refinerStatusItems[i].label == 'Returned to Customer') {
                arr.push(this.refinerStatusItems[i]);
            }
        }
        for (var i = 0; i < this.refinerStatusItems.length; i++) {
            if (this.refinerStatusItems[i].label == 'Customer Picked Up') {
                arr.push(this.refinerStatusItems[i]);
            }
        }
        for (var i = 0; i < this.refinerStatusItems.length; i++) {
            if (this.refinerStatusItems[i].label == 'Destroyed') {
                arr.push(this.refinerStatusItems[i]);
            }
        }
        for (var i = 0; i < this.refinerStatusItems.length; i++) {
            if (this.refinerStatusItems[i].label == 'Archived') {
                arr.push(this.refinerStatusItems[i]);
            }
        }
        this.refinerStatusItems = arr;
        this.lastSelectedStatuses = this.refinerStatusItems;
    };
    SamplesListComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.refinerCompanyItems = new Array();
        this.samplesListItemClass = "samples-list-item";
        this.refinerStatusItems = new Array();
        this.refinerStatusObject = new Object();
        this.refinerCompanyObject = new Object();
        this.headerStatusLabel = "Status";
        this.enableRefiners = true;
        this.headerTitle = "Samples";
        this.breadCrumbs = "Work / Samples";
        //this.columns = [
        //    "Description",
        //    "Creation Date",
        //    "Quote Number",
        //    "Price"
        //];
        this.selectedSortValue = "Sample Number : High to Low";
        this.sortValues = [
            new dropdown_component_1.DropdownValue('SampleNumber', 'Sample Number: High to Low'),
            new dropdown_component_1.DropdownValue('SampleNumber', 'Sample Number: Low to High'),
            new dropdown_component_1.DropdownValue('Description', 'Sample Description: A-Z'),
            new dropdown_component_1.DropdownValue('Description', 'Sample Description: Z-A'),
            new dropdown_component_1.DropdownValue('CustomerName', 'Company Name: A-Z'),
            new dropdown_component_1.DropdownValue('CustomerName', 'Company Name: Z-A'),
            new dropdown_component_1.DropdownValue('ProjectNumber', 'Project Number: High to Low'),
            new dropdown_component_1.DropdownValue('ProjectNumber', 'Project Number: Low to High'),
            new dropdown_component_1.DropdownValue('OrderNumber', 'Order Number: High to Low'),
            new dropdown_component_1.DropdownValue('OrderNumber', 'Order Number: Low to High')
        ];
        this.pages = [
            new dropdown_component_1.DropdownValue('1', '1')
        ];
        this.listItems = new Array();
        this._sampleService.getSamplesList().subscribe(function (samples) {
            _this.contentLoaded = true;
            //(<any>document).getElementById('loadingQuotes').style.display = 'inline';
            _this.samplesList = samples.ItemList;
            if (!samples.success) {
                _this.errorMessage = samples.message;
            }
            else if (_this.samplesList === null || _this.samplesList === undefined) {
                _this.errorMessage = "No Records Found";
            }
            if (_this.samplesList != undefined && _this.samplesList != null) {
                _this.Configuration();
                _this.errorMessage = '';
                for (var i = 0; i < _this.samplesList.length; i++) {
                    if (_this.samplesList[i].DisposalDate == null) {
                        switch (_this.samplesList[i].Status) {
                            case "Un-received":
                                //this.samplesList[i].QuoteStatus = "Draft";
                                _this.samplesList[i].Status = "Not Received";
                                break;
                            case "Incomplete":
                            case "Complete":
                            case "Authorized":
                            case "In Progress":
                            case "Rejected":
                                //this.samplesList[i].QuoteStatus = "Accepted";
                                _this.samplesList[i].Status = "Received";
                                break;
                            default: break;
                        }
                    }
                    else {
                        switch (_this.samplesList[i].DispositionMethod) {
                            case "RETURN":
                                //this.samplesList[i].QuoteStatus = "Offered";
                                _this.samplesList[i].Status = "Returned to Customer";
                                break;
                            case "DESTROY":
                                _this.samplesList[i].Status = "Destroyed";
                                break;
                            case "ARCHIVE":
                                _this.samplesList[i].Status = "Archived";
                                break;
                            case "PICKUP":
                                _this.samplesList[i].Status = "Customer Picked Up";
                                break;
                            default: break;
                        }
                    }
                    _this.addCompanyRefinerOptions(_this.samplesList[i].CustomerName);
                    _this.addStatusOptions(_this.samplesList[i].Status);
                    _this.listItems.push(_this.getColumnObject(_this.samplesList[i]));
                }
            }
            _this.updateRefinerStatusItems();
            _this.updateRefinerCompanyItems();
            _this.setPage(1);
            _this.updatePagingDropdown(_this.listItems.length);
            var getUpdateDate = new Date(Date.now() - samples.Age.TotalMilliseconds);
            _this.updateDate = (getUpdateDate.getMonth() + 1) + '/' + getUpdateDate.getDate() + '/' + getUpdateDate.getFullYear();
            _this.udateHours = getUpdateDate.getTime();
        }, function (error) {
            _this.errorMessage = error;
        });
    };
    SamplesListComponent.prototype.onLeftPage = function (data) {
        this.setPage(this.pager.currentPage - 1);
    };
    SamplesListComponent.prototype.onRightPage = function (data) {
        this.setPage(this.pager.currentPage + 1);
    };
    SamplesListComponent.prototype.onPageEvent = function (data) {
        var page = parseInt(data.value);
        this.setPage(page);
    };
    SamplesListComponent.prototype.getStatusColor = function (status) {
        switch (status) {
            case 'Not Received':
                return 'draft-text';
            case 'Received':
                return 'accepted-text';
            case 'Returned to Customer':
            case 'Destroyed':
            case 'Archived':
            case 'Customer Picked Up':
                return 'destroyed-text';
            default: {
                return 'default-text';
            }
        }
    };
    SamplesListComponent.prototype.getBorderColorClass = function (listItem) {
        var status = listItem[4].Status;
        switch (status) {
            case 'Not Received':
                return 'draft';
            case 'Received':
                return 'accepted';
            case 'Returned to Customer':
            case 'Destroyed':
            case 'Archived':
            case 'Customer Picked Up':
                return 'destroyed';
            default: {
                return 'default';
            }
        }
    };
    SamplesListComponent.prototype.getColumnObject = function (data) {
        var listItem = new Array();
        var columnObject1 = new Object();
        columnObject1.type = 'large';
        columnObject1.value = '';
        columnObject1.underValue = '<span class="' + this.getStatusColor(data.Status) + '">' + data.Status + '</span> | Customer Name: ' + data.CustomerName + ' | Project No:  ' + data.ProjectNumber + ' | Order No: ' + data.OrderNumber;
        columnObject1.statusValue = data.Status;
        columnObject1.largeValue = 'Sample No: ' + data.SampleNumber;
        columnObject1.linkdata = data.SampleNumber;
        columnObject1.routerlink = ['/SampleDetail', data.SampleNumber];
        listItem.push(columnObject1);
        var columnObject2 = new Object();
        columnObject2.status = data.Status;
        columnObject2.sampleNumber = data.SampleNumber;
        columnObject2.description = data.Description;
        columnObject2.customerName = data.CustomerName;
        columnObject2.projectNumber = data.ProjectNumber;
        columnObject2.orderNumber = data.OrderNumber;
        columnObject2.partySiteNumber = data.PartySiteNumber;
        listItem.push(columnObject2);
        return listItem;
    };
    //deepLinkURL(orderNo: number, psn: number): void {
    //    let details = "URL/Orders/OrderDetail/" + orderNo + "-" + psn;
    //    parent.postMessage(details, this.parentURL);
    //}
    SamplesListComponent.prototype.sampleLinkURL = function (sampleNumber) {
        console.log("Samples:" + sampleNumber);
        var sampleUrl = "Internal/Samples/SampleDetail/" + sampleNumber;
        parent.postMessage(sampleUrl, this.parentURL);
    };
    return SamplesListComponent;
}());
SamplesListComponent = __decorate([
    core_1.Component({
        templateUrl: '../../../app/samples/sample-list/sample-list.component.html',
        styleUrls: ['../../../app/samples/sample-list/sample-list.component.css']
    }),
    __metadata("design:paramtypes", [sample_service_1.SamplesService, typeof (_a = typeof pager_service_1.PagerService !== "undefined" && pager_service_1.PagerService) === "function" && _a || Object])
], SamplesListComponent);
exports.SamplesListComponent = SamplesListComponent;
var _a;
//export class SamplesListComponent implements OnInit {
//    @ViewChild('filterCount') filterCountEl: ElementRef;
//    loadingSpinnerURL = 'images/preload.gif';
//    samples: SampleList = new SampleList();
//    filteredCount: FilterCount = new FilterCount();
//    sampleList: SampleListItem[];
//    relationshipFilterCount: any[] = [];
//    customerFilterCount: any[] = [];
//    refinedRecordList: SampleListItem[] = [];
//    finalList: SampleListItem[];
//    updateDate: any;
//    updateHours: any;
//    /*Status Refiner Implementation*/
//    statusfilterlist: any[] = [];
//    enableAllstatus: boolean = false;
//    statusCount: number = 0;
//    rdStatus: string;
//    chkStatusList: any[] = [];
//    chkStatusList1: any[] = [];
//    statusSlelectAll: any[] = [];
//    statusFilterList: string[] = ['Not Received',
//        'Received',
//        'Returned to Customer',
//        'Customer Picked Up',
//        'Destroyed',
//        'Archived'];
//    showMoreCompany: boolean = false;
//    selectAllStatus: boolean = true;
//    status: string;
//    /*Variable declaration for Pagination*/
//    totalItems: number = 0;
//    currentPage: number = 1;
//    itemsPerPage: number = 15;
//    startIndex: number = 0;
//    endIndex: number = 0;
//    totalPages: number = 1;
//    pagesArr: number[] = [];
//    maxSize: number = 0;
//    enableFwdBtn: boolean = false;
//    enableBackBtn: boolean = false;
//    totalCount: number = 0;
//    finalpagecount: number = 0;
//    deepLinkUrl: any;
//    parentURL: string = "";
//    enableAllcustomer: boolean = false;
//    companyClass: string;
//    visibleMore: boolean = false;
//    viewless: number = 0;
//    viewmore: number = 5;
//    showstatus: boolean = true;
//    /*Column Sorting*/
//    selectedSortOption: sortOption = new sortOption('Sample Number : High to Low', false);
//    sortOptions = [
//        new sortOption('Sample Number : High to Low', false),
//        new sortOption('Sample Number : Low to High', false),
//        new sortOption('Sample Description : A-Z', true),
//        new sortOption('Sample Description : Z-A', false),
//        new sortOption('Company Name : A-Z', true),
//        new sortOption('Company Name: Z-A', false),
//        new sortOption('Project Number: High to Low', true),
//        new sortOption('Project Number: Low to High', false),
//        new sortOption('Order Number : High to Low', true),
//        new sortOption('Order Number: Low to High', false),
//    ];
//    customerNameList: any[] = [];
//    statusFilterSelectall: any[] = [];
//    errorMessage: string;
//    errorState: boolean = false;
//    errormsg: string;
//    noRecords: string = "No Records Found";
//    constructor(private _logger: Logger, private _sampleService: SampleService) { }
//    ngAfterViewInit() {
//        this.loadingSpinnerURL = (<any>window).cdnURL + 'Global/images/preload.gif';
//    }
//    ngOnInit(): void {
//        (<any>document).getElementById('loadingSample').style.visibility = "visible";
//        this._sampleService.GetSamplesList()
//            .subscribe((samples: SampleList) => {
//                this.sampleList = samples.ItemList;
//                if (samples.success != null && !samples.success) {
//                    this.errormsg = samples.message;
//                    this.handleError();
//                }
//                else if (this.sampleList === null || this.sampleList === undefined) {
//                    this.errormsg = this.noRecords;
//                    this.handleError();
//                }
//                if (this.sampleList != undefined && this.sampleList != null) {
//                    this.errormsg = '';
//                    this.finalPageCount(this.sampleList);
//                    this.finalList = this.refinedRecordList;
//                    if (this.customerNameList !== null && this.customerNameList.length > 5) {
//                        this.companyClass = "companyContainer";
//                        this.visibleMore = true;
//                    }
//                    for (var j = 0; j < this.customerNameList.length; j++) {
//                        let customerCount = 0;
//                        let customerName = '';
//                        for (var k = 0; k < this.finalList.length; k++) {
//                            if (this.finalList[k].CustomerName != null && this.customerNameList[j].toLowerCase() == this.finalList[k].CustomerName.toLowerCase()) {
//                                customerCount = customerCount + 1;
//                                customerName = this.finalList[k].CustomerName;
//                            }
//                        }
//                        if (customerCount > 0) {
//                            this.customerFilterCount.push({ "Name": customerName, "Count": customerCount })
//                        }
//                    }
//                    this.statuscount();
//                    var getUpdateDate = new Date(Date.now());
//                    this.updateDate = (getUpdateDate.getMonth() + 1) + '/' + getUpdateDate.getDate() + '/' + getUpdateDate.getFullYear();
//                    this.updateHours = getUpdateDate.getTime();
//                    (<any>document).getElementById('loadingSample').style.display = 'none';
//                    this.filteredCount.count = this.finalList.length;
//                    this.setPaginationProperties(this.filteredCount.count);
//                    this.ConfigurationURL();
//                }
//            }, (error: any) => {
//                this.handleError();
//            },
//            () => this._logger.info('Get all Items complete' + this.sampleList));
//    }
//    private handleError(): void {
//        (<any>document).getElementById('loadingSample').style.display = 'none';
//        this.errorState = true;
//    }
//    finalPageCount(items?: SampleListItem[]): void {
//        for (var i = 0; i < items.length; i++) {
//            items[i].CustomerNameDisplaypurpose = items[i].CustomerName;
//            items[i].DescriptionDisplaypurpose = items[i].Description;
//            items[i].OrderNumberDisplaypurpose = items[i].OrderNumber;
//            items[i].PartySiteNumberDisplaypurpose = items[i].PartySiteNumber;
//            items[i].ProjectNumberDisplaypurpose = items[i].ProjectNumber;
//            items[i].SampleNumberDisplaypurpose = items[i].SampleNumber;
//            if (items[i].Status === 'Un-received' && items[i].DisposalDate == null) {
//                items[i].Cssclass = 'data-list not-received col-md-12';
//                items[i].SecondCssClass = 'data-list-status not-received row';
//                items[i].Status = 'Not Received';
//                this.refinedRecordList.push(items[i]);
//                if (items[i].CustomerName !== null && !this.customerNameList.find(x => x.toLowerCase() == items[i].CustomerName.toLowerCase())) {
//                    this.customerNameList.push(items[i].CustomerName);
//                }
//            }
//            if ((items[i].Status === 'Incomplete' || items[i].Status === 'Complete' || items[i].Status === 'Authorized' || items[i].Status === 'In Progress' || items[i].Status === 'Rejected') && items[i].DisposalDate == null) {
//                items[i].Cssclass = 'data-list received col-md-12';
//                items[i].SecondCssClass = 'data-list-status received row';
//                items[i].Status = 'Received';
//                this.refinedRecordList.push(items[i]);
//                if (items[i].CustomerName !== null && !this.customerNameList.find(x => x.toLowerCase() == items[i].CustomerName.toLowerCase())) {
//                    this.customerNameList.push(items[i].CustomerName);
//                }
//            }
//            if (items[i].DispositionMethod === 'RETURN' && items[i].DisposalDate != null) {
//                items[i].Cssclass = 'data-list destroyed col-md-12';
//                items[i].SecondCssClass = 'data-list-status destroyed row';
//                items[i].Status = 'Returned to Customer';
//                this.refinedRecordList.push(items[i]);
//                if (items[i].CustomerName !== null && !this.customerNameList.find(x => x.toLowerCase() == items[i].CustomerName.toLowerCase())) {
//                    this.customerNameList.push(items[i].CustomerName);
//                }
//            }
//            if (items[i].DispositionMethod === 'DESTROY' && items[i].DisposalDate != null) {
//                items[i].Cssclass = 'data-list destroyed col-md-12';
//                items[i].SecondCssClass = 'data-list-status destroyed row';
//                items[i].Status = 'Destroyed';
//                this.refinedRecordList.push(items[i]);
//                if (items[i].CustomerName !== null && !this.customerNameList.find(x => x.toLowerCase() == items[i].CustomerName.toLowerCase())) {
//                    this.customerNameList.push(items[i].CustomerName);
//                }
//            }
//            if (items[i].DispositionMethod === 'ARCHIVE' && items[i].DisposalDate != null) {
//                items[i].Cssclass = 'data-list destroyed col-md-12';
//                items[i].SecondCssClass = 'data-list-status destroyed row';
//                items[i].Status = 'Archived';
//                this.refinedRecordList.push(items[i]);
//                if (items[i].CustomerName !== null && !this.customerNameList.find(x => x.toLowerCase() == items[i].CustomerName.toLowerCase())) {
//                    this.customerNameList.push(items[i].CustomerName);
//                }
//            }
//            if (items[i].DispositionMethod === 'PICKUP' && items[i].DisposalDate != null) {
//                items[i].Cssclass = 'data-list destroyed col-md-12';
//                items[i].SecondCssClass = 'data-list-status destroyed row';
//                items[i].Status = 'Customer Picked Up';
//                this.refinedRecordList.push(items[i]);
//                if (items[i].CustomerName !== null && !this.customerNameList.find(x => x.toLowerCase() == items[i].CustomerName.toLowerCase())) {
//                    this.customerNameList.push(items[i].CustomerName);
//                }
//            }
//            items[i].StatusDisplaypurpose = items[i].Status;
//        }
//    }
//    /*Select All status*/
//    checkAllStatus(): void {
//        this.chkStatusList = [];
//        this.chkStatusList1 = [];
//        for (var i = 0; i < this.statusfilterlist.length; i++) {
//            this.chkStatusList.push(this.statusfilterlist[i].Name);
//            this.chkStatusList1.push(this.statusfilterlist[i].Name.toLowerCase());
//        }
//        this.enableAllstatus = false;
//        this.triggerFocus();
//    }
//    /* Status Filter Checkbox */
//    statusChecked(checked: boolean, value: string): void {
//        if (checked == true) {
//            this.chkStatusList.push(value);
//            this.chkStatusList1.push(value.toLowerCase());
//            // To make select All disable when all the status coming as selected
//            if (this.chkStatusList1.length === this.statusFilterList.length) {
//                this.enableAllstatus = false;
//            }
//        }
//        else {
//            for (var i = 0; i < this.chkStatusList.length; i++) {
//                if (this.chkStatusList[i] == value) {
//                    this.chkStatusList.splice(i, 1);
//                    this.chkStatusList1.splice(i, 1);
//                }
//            }
//            // To clear select All disable when any one of the status coming as not selected
//            this.enableAllstatus = true;
//        }
//        this.triggerFocus();
//    }
//    statuscount(): void {
//        /* count for Status */
//        for (var l = 0; l < this.statusFilterList.length; l++) {
//            this.chkStatusList.push(this.statusFilterList[l]);
//            this.chkStatusList1.push(this.statusFilterList[l].toLowerCase());
//            this.statusCount = 0;
//            this.status = this.statusFilterList[l];
//            for (var m = 0; m < this.finalList.length; m++) {
//                if (this.statusFilterList[l] == this.finalList[m].StatusDisplaypurpose) {
//                    this.statusCount = this.statusCount + 1;
//                }
//            }
//            this.statusfilterlist.push({ "Name": this.status, "Count": this.statusCount });
//        }
//    }
//    customerNameChecked(checked: boolean, name: string) {
//        if (checked == true) {
//            this.customerNameList.push(name);
//            if (this.customerNameList.length == this.customerFilterCount.length) {
//                this.enableAllcustomer = false;
//            }
//        }
//        else {
//            for (var i = 0; i < this.customerFilterCount.length; i++) {
//                if (this.customerNameList[i] == name) {
//                    this.customerNameList.splice(i, 1);
//                }
//            }
//            this.enableAllcustomer = true;
//        }
//        this.triggerFocus();
//    }
//    custommore(): void {
//        this.viewmore = this.customerFilterCount.length;
//        this.viewless = 0;
//        this.showstatus = false;
//    }
//    customless(): void {
//        this.viewmore = 5;
//        this.viewless = 0;
//        this.showstatus = true;
//    }
//    selectAllCustomer(): void {
//        this.customerNameList = [];
//        for (var i = 0; i < this.customerFilterCount.length; i++) {
//            this.customerNameList.push(this.customerFilterCount[i].Name);
//        }
//        this.enableAllcustomer = false;
//        this.filterPageChange(1, this.filteredCount.count);
//        this.triggerFocus();
//    }
//    /* PAGINATION   */
//    setPaginationProperties(filterCount?: number): void {
//        this.setPageValues(filterCount);
//        this.setPageIndexes();
//        this.setNavigationBtn();
//    }
//    setPageValues(filterCount?: number) {
//        this.totalItems = (filterCount == undefined ? this.totalCount : filterCount);
//        this.totalPages = Math.ceil(this.totalItems / this.itemsPerPage);
//        this.pagesArr = [];
//        for (let num = 1; num <= this.totalPages; num++) {
//            this.pagesArr.push(num);
//        }
//    }
//    setPageIndexes() {
//        this.startIndex = (this.currentPage - 1) * this.itemsPerPage;
//        let tempEndindex = this.startIndex + this.itemsPerPage
//        this.endIndex = (tempEndindex) > this.totalItems ? this.totalItems : tempEndindex;
//    }
//    setPage(pageNo: number) {
//        this.currentPage = pageNo;
//        this.setPageIndexes();
//        this.setNavigationBtn();
//    }
//    public filterPageChange(pageNo: any, filterCount: number): void {
//        this.currentPage = pageNo;
//        this.setPaginationProperties(filterCount);
//    };
//    pageNavigationBtnClick(changeType?: string) {
//        let _currentPage = this.currentPage;
//        if (changeType == "NEXT") {
//            _currentPage = Number(_currentPage.toString()) + 1;
//            _currentPage = _currentPage < this.totalPages ? _currentPage : this.totalPages;
//        }
//        else if (changeType == "PREVIOUS") {
//            _currentPage = _currentPage - 1 > 1 ? _currentPage - 1 : 1;
//        }
//        this.currentPage = _currentPage;
//        this.setPageIndexes();
//        this.setNavigationBtn();
//    }
//    setNavigationBtn(): void {
//        this.enableFwdBtn = this.currentPage > 1 ? true : false;
//        this.enableBackBtn = (this.totalPages > 0 && this.currentPage < this.totalPages) ? true : false;
//    }
//    // PBI- 2569 Dropdown Sorting
//    changeSelect(selectedOption: string) {
//        this.selectedSortOption.sortOptionName = selectedOption;
//        this.filterPageChange(1, this.filteredCount.count);
//    }
//    private ConfigurationURL() {
//        this._sampleService.GetConfiguration()
//            .subscribe(data => {
//                this.deepLinkUrl = <SampleService>data;
//                this.parentURL = this.deepLinkUrl.naftURL;
//            });
//    }
//    sampleLinkURL(sampleNumber: string) {
//        let sampleUrl = "Internal/Samples/SampleDetail/" + sampleNumber;
//        var _sampleInfo = this.search(sampleNumber);
//        Sampleinformation.SampleStatus = _sampleInfo.StatusDisplaypurpose.replace(/<\/?span[^>]*>/g, "");
//        parent.postMessage(sampleUrl, this.parentURL);
//    }
//    search(sampleNumber: string) {
//        for (var i = 0; i < this.sampleList.length; i++) {
//            if (this.sampleList[i].SampleNumber === sampleNumber) {
//                return this.sampleList[i];
//            }
//        }
//    }
//    //ToolTip State Change//
//    tooltipStateChanged(state: boolean): void {
//        this._logger.info(`Tooltip is open: ${state}`);
//    }
//    triggerFocus(): void {
//        setTimeout(() => this.filterPageChange(1, this.filteredCount.count), 5);
//    }
//}
//# sourceMappingURL=sample-list.component.js.map