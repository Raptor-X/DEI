"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var sample_service_1 = require("../shared/sample.service");
var core_2 = require("angular2-logger/core");
var SamplesDetailComponent = (function () {
    function SamplesDetailComponent(_route, _router, _logger, _sampleService) {
        this._route = _route;
        this._router = _router;
        this._logger = _logger;
        this._sampleService = _sampleService;
        this.loadingSpinnerURL = 'images/preload.gif';
        this.parentURL = "";
        this.errorState = false;
        this.noRecords = "No Records Found";
    }
    SamplesDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.sub = this._route.params.subscribe(function (params) {
            _this.sampleNumber = params['id'];
            _this.getSampleDetail(_this.sampleNumber);
        });
        this.ConfigurationURL();
    };
    SamplesDetailComponent.prototype.ngAfterViewInit = function () {
        this.loadingSpinnerURL = window.cdnURL + 'Global/images/preload.gif';
    };
    SamplesDetailComponent.prototype.ConfigurationURL = function () {
        var _this = this;
        this._sampleService.GetConfiguration()
            .subscribe(function (data) {
            _this.deepLinkUrl = data;
            _this.parentURL = _this.deepLinkUrl.naftURL;
        });
    };
    SamplesDetailComponent.prototype.getSampleDetail = function (sampleNumber) {
        var _this = this;
        document.getElementById('loadingSampleDetail').style.display = 'inline';
        this._sampleService.getSampleDetail(sampleNumber).subscribe(function (sample) {
            _this.sampleItem = sample.Items;
            if (sample.success != null && !sample.success) {
                _this.errormsg = sample.message;
                _this.handleError();
            }
            else if (_this.sampleItem === null || _this.sampleItem === undefined) {
                _this.errormsg = _this.noRecords;
                _this.handleError();
            }
            else {
                _this.errorState = false;
                //this.formatSampleData();
                _this.sampleItem[0].Status = _this.getStatus(_this.sampleItem[0].Status, _this.sampleItem[0].DispositionMethod, _this.sampleItem[0].DisposalDate);
                if (_this.sampleItem[0].Status.toUpperCase() == "RECEIVED") {
                    _this.statusColor = "green";
                }
                else if (_this.sampleItem[0].Status.toUpperCase() == "NOT RECEIVED") {
                    _this.statusColor = "blue";
                }
                else {
                    _this.statusColor = "grey";
                }
            }
            document.getElementById('loadingSampleDetail').style.display = 'none';
        }, function (error) {
            _this.handleError();
        }, function () { return _this._logger.info('Get all Items complete' + _this.sampleItem); });
    };
    SamplesDetailComponent.prototype.handleError = function () {
        document.getElementById('loadingSampleDetail').style.display = 'none';
        this.errorState = true;
    };
    SamplesDetailComponent.prototype.formatSampleData = function () {
        for (var _i = 0, _a = this.sampleItem; _i < _a.length; _i++) {
            var item = _a[_i];
            var status = this.getStatus(this.sampleItem[0].Status, this.sampleItem[0].DispositionMethod, this.sampleItem[0].DisposalDate);
            if (status.toUpperCase() == "RECEIVED") {
                this.statusColor = "green";
            }
            else if (status.toUpperCase() == "NOT RECEIVED") {
                this.statusColor = "blue";
            }
            else {
                this.statusColor = "grey";
            }
        }
    };
    SamplesDetailComponent.prototype.sampleLinkURL = function () {
        var sampleUrl = "List/Samples";
        parent.postMessage(sampleUrl, this.parentURL);
    };
    SamplesDetailComponent.prototype.getFormattedAddress = function (locationDetail) {
        var fullAddress = "";
        fullAddress += locationDetail.AddressLine1 ? locationDetail.AddressLine1 + ', ' : '';
        fullAddress += locationDetail.AddressLine2 ? locationDetail.AddressLine2 + ', ' : '';
        fullAddress += locationDetail.AddressLine3 ? locationDetail.AddressLine3 + ', ' : '';
        fullAddress += locationDetail.AddressLine4 ? locationDetail.AddressLine4 + ', ' : '';
        fullAddress += locationDetail.AddressLine5 ? locationDetail.AddressLine5 + ', ' : '';
        fullAddress += locationDetail.AddressLine6 ? locationDetail.AddressLine6 : '';
        fullAddress = fullAddress.replace(/,\s*$/, "");
        return fullAddress;
    };
    SamplesDetailComponent.prototype.getStatus = function (status, dispositionMethod, disposalDate) {
        if (status === 'Un-received' && disposalDate == null) {
            return 'Not Received';
        }
        if ((status === 'Incomplete' || status === 'Complete' || status === 'Authorized' || status === 'In Progress' || status === 'Rejected') && disposalDate == null) {
            return 'Received';
        }
        if (dispositionMethod === 'RETURN' && disposalDate != null) {
            return 'Returned to Customer';
        }
        if (dispositionMethod === 'DESTROY' && disposalDate != null) {
            return 'Destroyed';
        }
        if (dispositionMethod === 'ARCHIVE' && disposalDate != null) {
            return 'Archived';
        }
        if (dispositionMethod === 'PICKUP' && disposalDate != null) {
            return 'Customer Picked Up';
        }
        return dispositionMethod;
    };
    return SamplesDetailComponent;
}());
SamplesDetailComponent = __decorate([
    core_1.Component({
        templateUrl: '../../../app/samples/sample-detail/sample-detail.component.html',
        styleUrls: ['../../../app/samples/sample-detail/sample-detail.component.css']
    }),
    __metadata("design:paramtypes", [router_1.ActivatedRoute,
        router_1.Router, core_2.Logger, sample_service_1.SamplesService])
], SamplesDetailComponent);
exports.SamplesDetailComponent = SamplesDetailComponent;
//# sourceMappingURL=sample-detail.component.js.map