﻿export interface ISampleDetails {
    Items: SampleItem[];
    success: boolean;
    message: string;
}

export interface SampleItem {
    SampleNumber: string;
    AuroraProjectNumber: string;
    OrderNumber: string;
    ProjectNumber: string;
    Description: string;
    CustomerName: string;
    CustomerContactName: string;
    PartySiteNumber: string;
    DispositionMethod: string;
    QuantityExpected: number;
    QuantityReceived: number;
    ReadyToDisposalDate: string;
    DisposalDate: Date;
    Status: string;
    ModelNumber: string;
    Location: LocationDetail;
}

export interface LocationDetail {
    Name: string;
    AddressLine1: string;
    AddressLine2: string;
    AddressLine3: string;
    AddressLine4: string;
    AddressLine5: string;
    AddressLine6: string;
    ZipCode: string;
}

