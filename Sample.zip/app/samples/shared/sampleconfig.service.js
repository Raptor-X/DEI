"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/do");
require("rxjs/add/operator/map");
var core_2 = require("angular2-logger/core");
var appconfigservice_service_1 = require("ul_portal_components/app/services/appconfigservice.service");
var uidisplayfield_type_1 = require("ul_portal_components/app/content/types/uidisplayfield.type");
var SamplesConfigService = (function (_super) {
    __extends(SamplesConfigService, _super);
    function SamplesConfigService(_logger, _http) {
        var _this = _super.call(this) || this;
        _this._logger = _logger;
        _this._http = _http;
        console.log(' !!!Logging!!! ');
        return _this;
    }
    SamplesConfigService.prototype.getListParameters = function () {
        var listParameters = new Object();
        listParameters.headerNames = new Array();
        listParameters.fieldNames = new Array();
        var obj1 = new Object();
        obj1.columnName = "PSN";
        listParameters.headerNames.push(obj1);
        var obj2 = new Object();
        obj2.columnName = "Creation Date";
        listParameters.headerNames.push(obj2);
        var obj3 = new Object();
        obj3.columnName = "Quote Status";
        listParameters.headerNames.push(obj3);
        var obj4 = new Object();
        obj4.columnName = "Quote Number";
        listParameters.headerNames.push(obj4);
        var obj5 = new Object();
        obj5.fieldName = "PSN";
        listParameters.fieldNames.push(obj5);
        return listParameters;
    };
    SamplesConfigService.prototype.getDetailFields = function () {
        var detailFields = new Array();
        var detailField1 = new uidisplayfield_type_1.UIDisplayField();
        detailField1.fieldLabel = "Quote Number";
        detailField1.dataFieldName = "QuoteNumber";
        detailField1.type = "normal";
        detailFields.push(detailField1);
        var detailField2 = new uidisplayfield_type_1.UIDisplayField();
        detailField2.fieldLabel = "Created On";
        detailField2.dataFieldName = "CreationDate";
        detailField2.type = "normal";
        detailFields.push(detailField2);
        var detailField3 = new uidisplayfield_type_1.UIDisplayField();
        detailField3.fieldLabel = "Created By";
        detailField3.dataFieldName = "CreatedBy";
        detailField3.type = "normal";
        detailFields.push(detailField3);
        return detailFields;
    };
    SamplesConfigService.prototype.getAppName = function () {
        "Samples App";
    };
    SamplesConfigService.prototype.getSubHeaderStatusFieldName = function () {
        return "SampleStatus";
    };
    SamplesConfigService.prototype.getSubHeaderDescriptionFieldName = function () {
        return "Company";
    };
    SamplesConfigService.prototype.getSubHeaderStatusFieldLabel = function () {
        return "Status";
    };
    return SamplesConfigService;
}(appconfigservice_service_1.AppConfigService));
SamplesConfigService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [core_2.Logger, http_1.Http])
], SamplesConfigService);
exports.SamplesConfigService = SamplesConfigService;
//# sourceMappingURL=sampleconfig.service.js.map