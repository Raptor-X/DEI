"use strict";
var FilterCount = (function () {
    function FilterCount() {
        this.count = 0;
    }
    return FilterCount;
}());
exports.FilterCount = FilterCount;
//# sourceMappingURL=filterCount.js.map