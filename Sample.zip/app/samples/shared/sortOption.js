"use strict";
var sortOption = (function () {
    function sortOption(sortOptionName, value) {
        this.sortOptionName = sortOptionName;
        this.value = value;
    }
    return sortOption;
}());
exports.sortOption = sortOption;
//# sourceMappingURL=sortoption.js.map