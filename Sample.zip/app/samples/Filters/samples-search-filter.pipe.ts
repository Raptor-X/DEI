﻿import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name: 'samplesSearchFilter'

})

export class SamplesSearchFilterPipe implements PipeTransform {
    filteredList: any;
    transform(value: any, filterBy: string): any {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        if (value != undefined) {
            this.filteredList = filterBy ? value.filter((quote: any) =>
                quote[0].largeValue != undefined && quote[0].largeValue.toLocaleLowerCase().indexOf(filterBy) !== -1
                || quote[2].value != undefined && quote[2].value.toLocaleLowerCase().indexOf(filterBy) !== -1
                || quote[4].ContactName != undefined && quote[4].ContactName.toLocaleLowerCase().indexOf(filterBy) !== -1) : value;

            let filteredValue = new RegExp("(" + filterBy + ")", "gi");
            for (var item of this.filteredList) {
                if (item[0].largeValue) {
                    item[0].largeValue = item[0].largeValue.replace(filteredValue, "<span class='highlighted'>$1</span>");
                }
                if (item[2].value) {
                    item[2].value = item[2].value.replace(filteredValue, "<span class='highlighted'>$1</span>");
                }
                if (item[4].ContactName) {
                    item[4].ContactName = item[4].ContactName.replace(filteredValue, "<span class='highlighted'>$1</span>");
                }
            }
        }

        return this.filteredList;
    }
}