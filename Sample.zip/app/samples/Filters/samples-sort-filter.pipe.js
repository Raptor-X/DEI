"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var samplesSortFilterPipe = (function () {
    function samplesSortFilterPipe() {
    }
    samplesSortFilterPipe.prototype.transform = function (value, sortBy, sortType) {
        if (value !== undefined) {
            switch (sortBy) {
                case "Date Created: Newest First":
                case "Date Created: Oldest First":
                case "Creation Date":
                    value.sort(function (a, b) {
                        var dateA = (new Date(a[4].dateCreated));
                        var dateB = (new Date(b[4].dateCreated));
                        if ((sortBy === "Date Created: Newest First") || (sortBy === "Creation Date" && sortType === "DES"))
                            return dateB.getTime() - dateA.getTime();
                        else
                            return dateA.getTime() - dateB.getTime();
                    });
                    break;
                case "Price: Highest First":
                case "Price: Lowest First":
                case "Price":
                    value.sort(function (a, b) {
                        var priceA = a[3].price;
                        var priceB = b[3].price;
                        if ((sortBy === "Price: Highest First") || (sortBy === "Price" && sortType === "DES")) {
                            /*Moving invalid price at bottom of list*/
                            if (isNaN(priceA))
                                return 1;
                            else if (isNaN(priceB))
                                return -1;
                            else
                                return priceB - priceA;
                        }
                        else {
                            /*Moving invalid price at bottom of the  list*/
                            if (isNaN(priceA))
                                return 1;
                            else if (isNaN(priceB))
                                return -1;
                            else
                                return priceA - priceB;
                        }
                    });
                    break;
                case "Status: A-Z":
                    value.sort(function (a, b) {
                        if (a[4].QuoteStatus < b[4].QuoteStatus) {
                            return -1;
                        }
                        else if (a[4].QuoteStatus > b[4].QuoteStatus) {
                            return 1;
                        }
                    });
                    break;
                case "Status: Z-A":
                    value.sort(function (a, b) {
                        if (a[4].QuoteStatus > b[4].QuoteStatus) {
                            return -1;
                        }
                        else if (a[4].QuoteStatus < b[4].QuoteStatus) {
                            return 1;
                        }
                    });
                    break;
                case "Expiring: Soonest First":
                    value.sort(function (a, b) {
                        var dateA = (new Date(a[4].ExpirationDate));
                        var dateB = (new Date(b[4].ExpirationDate));
                        /*Moving invalid price at bottom of  list*/
                        var inValidDate = "Invalid Date";
                        if (dateA.toString() === inValidDate)
                            return 1;
                        else if (dateB.toString() === inValidDate)
                            return -1;
                        else
                            return dateA.getTime() - dateB.getTime();
                    });
                    break;
                case "Description":
                    value.sort(function (a, b) {
                        var QuoteNameA = a[4].QuoteName.toLowerCase();
                        var QuoteNameB = b[4].QuoteName.toLowerCase();
                        if (sortType === "ASC") {
                            if (QuoteNameA < QuoteNameB) {
                                return -1;
                            }
                            else if (QuoteNameA > QuoteNameB) {
                                return 1;
                            }
                        }
                        else {
                            if (QuoteNameA > QuoteNameB) {
                                return -1;
                            }
                            else if (QuoteNameA < QuoteNameB) {
                                return 1;
                            }
                        }
                    });
                    break;
                case "Sample Number : High to Low":
                    value.sort(function (a, b) {
                        var QuoteNumberA = a[2].value.toLowerCase();
                        var QuoteNumberB = b[2].value.toLowerCase();
                        if (sortType === "ASC") {
                            if (QuoteNumberA < QuoteNumberB) {
                                return -1;
                            }
                            else if (QuoteNumberA > QuoteNumberB) {
                                return 1;
                            }
                        }
                        else {
                            if (QuoteNumberA > QuoteNumberB) {
                                return -1;
                            }
                            else if (QuoteNumberA < QuoteNumberB) {
                                return 1;
                            }
                        }
                    });
                    break;
                default:
                    break;
            }
            return value;
        }
    };
    return samplesSortFilterPipe;
}());
samplesSortFilterPipe = __decorate([
    core_1.Pipe({
        name: 'samplesSortFilter'
    }),
    __metadata("design:paramtypes", [])
], samplesSortFilterPipe);
exports.samplesSortFilterPipe = samplesSortFilterPipe;
//# sourceMappingURL=samples-sort-filter.pipe.js.map