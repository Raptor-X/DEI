"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var SampleSortFilterPipe = (function () {
    function SampleSortFilterPipe() {
    }
    SampleSortFilterPipe.prototype.transform = function (value, sortBy) {
        if (value == undefined) {
            return value;
        }
        if (sortBy != null) {
            switch (sortBy) {
                case "Sample Number : High to Low":
                case "Sample Number : Low to High":
                    value.sort(function (a, b) {
                        var valueA = a.SampleNumber;
                        var valueB = b.SampleNumber;
                        if (sortBy === "Sample Number : High to Low") {
                            /*Moving invalid at bottom of list*/
                            if (isNaN(parseFloat(a.SampleNumber)))
                                return 1;
                            else if (isNaN(parseFloat(b.SampleNumber)))
                                return -1;
                            else
                                return valueB - valueA;
                        }
                        else {
                            /*Moving invalid at bottom of the  list*/
                            if (isNaN(parseFloat(a.SampleNumber)))
                                return 1;
                            else if (isNaN(parseFloat(b.SampleNumber)))
                                return -1;
                            else
                                return valueA - valueB;
                        }
                    });
                    break;
                case "Sample Description : A-Z":
                    value.sort(function (a, b) {
                        /* Moving null/empty values to the bottom of the list after that will do the sorting */
                        if (typeof a.Description === 'object') {
                            return 1;
                        }
                        else if (typeof b.Description === 'object') {
                            return -1;
                        }
                        else {
                            if (a.Description.toLowerCase() < b.Description.toLowerCase()) {
                                return -1;
                            }
                            else if (a.Description.toLowerCase() > b.Description.toLowerCase()) {
                                return 1;
                            }
                        }
                    });
                    break;
                case "Sample Description : Z-A":
                    value.sort(function (a, b) {
                        /* Moving null/empty values to the bottom of the list after that will do the sorting */
                        if (typeof a.Description === 'object') {
                            return 1;
                        }
                        else if (typeof b.Description === 'object') {
                            return -1;
                        }
                        else {
                            if (a.Description.toLowerCase() > b.Description.toLowerCase()) {
                                return -1;
                            }
                            else if (a.Description.toLowerCase() < b.Description.toLowerCase()) {
                                return 1;
                            }
                        }
                    });
                    break;
                case "Company Name : A-Z":
                    value.sort(function (a, b) {
                        /* Moving null/empty values to the bottom of the list after that will do the sorting */
                        if (typeof a.CustomerName === 'object') {
                            return 1;
                        }
                        else if (typeof b.CustomerName === 'object') {
                            return -1;
                        }
                        else {
                            if (a.CustomerName.toLowerCase() < b.CustomerName.toLowerCase()) {
                                return -1;
                            }
                            else if (a.CustomerName.toLowerCase() > b.CustomerName.toLowerCase()) {
                                return 1;
                            }
                        }
                    });
                    break;
                case "Company Name: Z-A":
                    value.sort(function (a, b) {
                        /* Moving null/empty values to the bottom of the list after that will do the sorting */
                        if (typeof a.CustomerName === 'object') {
                            return 1;
                        }
                        else if (typeof b.CustomerName === 'object') {
                            return -1;
                        }
                        else {
                            if (a.CustomerName.toLowerCase() > b.CustomerName.toLowerCase()) {
                                return -1;
                            }
                            else if (a.CustomerName.toLowerCase() < b.CustomerName.toLowerCase()) {
                                return 1;
                            }
                        }
                    });
                    break;
                case "Project Number: High to Low":
                case "Project Number: Low to High":
                    value.sort(function (a, b) {
                        var valueA = a.ProjectNumber;
                        var valueB = b.ProjectNumber;
                        if (sortBy === "Project Number: High to Low") {
                            /*Moving invalid at bottom of list*/
                            if (isNaN(parseFloat(a.ProjectNumber)))
                                return 1;
                            else if (isNaN(parseFloat(b.ProjectNumber)))
                                return -1;
                            else
                                return valueB - valueA;
                        }
                        else {
                            /*Moving invalid at bottom of the  list*/
                            if (isNaN(parseFloat(a.ProjectNumber)))
                                return 1;
                            else if (isNaN(parseFloat(b.ProjectNumber)))
                                return -1;
                            else
                                return valueA - valueB;
                        }
                    });
                    break;
                case "Order Number : High to Low":
                case "Order Number: Low to High":
                    value.sort(function (a, b) {
                        var valueA = a.OrderNumber;
                        var valueB = b.OrderNumber;
                        if (sortBy === "Order Number : High to Low") {
                            /*Moving invalid at bottom of list*/
                            if (isNaN(parseFloat(a.OrderNumber)))
                                return 1;
                            else if (isNaN(parseFloat(b.OrderNumber)))
                                return -1;
                            else
                                return valueB - valueA;
                        }
                        else {
                            /*Moving invalid at bottom of the  list*/
                            if (isNaN(parseFloat(a.OrderNumber)))
                                return 1;
                            else if (isNaN(parseFloat(b.OrderNumber)))
                                return -1;
                            else
                                return valueA - valueB;
                        }
                    });
                    break;
            }
            return value;
        }
    };
    return SampleSortFilterPipe;
}());
SampleSortFilterPipe = __decorate([
    core_1.Pipe({
        name: 'sampleSortFilter'
    }),
    __metadata("design:paramtypes", [])
], SampleSortFilterPipe);
exports.SampleSortFilterPipe = SampleSortFilterPipe;
//# sourceMappingURL=sample-sort-filter.pipe.js.map