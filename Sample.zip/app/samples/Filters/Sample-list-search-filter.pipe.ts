﻿
import { PipeTransform, Pipe } from '@angular/core';
import { SampleList } from '../shared/SampleList';
import { SampleListItem } from '../shared/samplelistitem';

import { FilterCount } from '../shared/filtercount';

@Pipe({
    name: 'SamplelistSearchFilter',
})

export class SampleListSearchFilterPipe implements PipeTransform {
    filterList: SampleListItem[];
    specials: any = ["-", "[", "]", "/", "{", "}", "(", ")", "*", "+", "?", ".", "\\", "^", "$", "|", "<", ">"]
    regex: any = RegExp('[' + this.specials.join('\\') + ']', 'g');
    transform(value: SampleListItem[], filterBy: string, filteredCount: FilterCount): SampleListItem[] {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        if (value != undefined) {
            this.filterList = filterBy ? value.filter((samplelist: SampleListItem) =>
                samplelist.Status != null && samplelist.Status != '' && samplelist.Status != undefined && samplelist.Status.toLowerCase().indexOf(filterBy) !== -1
                || samplelist.SampleNumber != null && samplelist.SampleNumber != '' && samplelist.SampleNumber != undefined && samplelist.SampleNumber.toLowerCase().indexOf(filterBy) !== -1
                || samplelist.Description != null && samplelist.Description != '' && samplelist.Description != undefined && samplelist.Description.toLowerCase().indexOf(filterBy) !== -1
                || samplelist.CustomerName != null && samplelist.CustomerName != '' && samplelist.CustomerName != undefined && samplelist.CustomerName.toLowerCase().indexOf(filterBy) !== -1
                || samplelist.ProjectNumber != null && samplelist.ProjectNumber != '' && samplelist.ProjectNumber != undefined && samplelist.ProjectNumber.toLowerCase().indexOf(filterBy) !== -1
                || samplelist.OrderNumber != null && samplelist.OrderNumber != '' && samplelist.OrderNumber != undefined && samplelist.OrderNumber.toLowerCase().indexOf(filterBy) !== -1
                || samplelist.PartySiteNumber != null && samplelist.PartySiteNumber != '' && samplelist.PartySiteNumber != undefined && samplelist.PartySiteNumber.toLowerCase() === filterBy
            ) : value
            filteredCount.count = this.filterList ? this.filterList.length : 0;
            this.filterList = this.LoadOriginalValues(this.filterList);
            if (filterBy !== null && this.filterList.length > 0) {
                this.filterList = this.formatList(this.filterList, filterBy);
            }
            return this.filterList;
        }
    }

    LoadOriginalValues(tempfilterList: SampleListItem[]): SampleListItem[] {
        var _filterList: SampleListItem[] = [];
        tempfilterList.forEach(function (value: SampleListItem) {
            var temp = value;
            temp.StatusDisplaypurpose = temp.Status;
            temp.SampleNumberDisplaypurpose = temp.SampleNumber;
            temp.DescriptionDisplaypurpose = temp.Description;
            temp.CustomerNameDisplaypurpose = temp.CustomerName;
            temp.ProjectNumberDisplaypurpose = temp.ProjectNumber;
            temp.OrderNumberDisplaypurpose = temp.OrderNumber;
            temp.PartySiteNumberDisplaypurpose = temp.PartySiteNumber;

            _filterList.push(value);
        });
        return _filterList;
    }

    escapeRegExp(value: string): string {
        return (value !== undefined && value !== null) ? value.replace(this.regex, "\\$&") : null;
    }
    formatList(tempfilterList: SampleListItem[], filterBy: string): SampleListItem[] {
        var _filterList: SampleListItem[] = [];
        tempfilterList.forEach((value: SampleListItem) => {
            var temp = value;
            var customername = temp.CustomerName;
            let pattern: string = this.escapeRegExp(filterBy);

            temp.StatusDisplaypurpose = (temp.Status != null) ? temp.Status.replace(new RegExp(pattern, 'i'), '<span style="background-color: #ffb31a">' + filterBy + '</span>') : "";
            temp.SampleNumberDisplaypurpose = (temp.SampleNumber !== null) ? temp.SampleNumber.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            temp.DescriptionDisplaypurpose = (temp.Description !== null) ? temp.Description.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            temp.CustomerNameDisplaypurpose = (temp.CustomerName !== null) ?
                ((temp.PartySiteNumber !== null && temp.PartySiteNumber.toLowerCase() === filterBy) ? '<span style="background-color:#ffb31a;">' + temp.CustomerName + '</span>' :
                    temp.CustomerName.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>')) : temp.CustomerName;
            temp.ProjectNumberDisplaypurpose = (temp.ProjectNumber !== null) ? temp.ProjectNumber.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            temp.OrderNumberDisplaypurpose = (temp.OrderNumber !== null) ? temp.OrderNumber.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            _filterList.push(temp);
        });
        return _filterList;
    }
}