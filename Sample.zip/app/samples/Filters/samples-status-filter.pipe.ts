﻿import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name: 'samplesStatusFilter',
    pure: false

})

export class SamplesStatusFilterPipe implements PipeTransform {
    checkedStatusList: any[];
    filteredValue: any[];
    transform(value: any, checkedList: any): any {
        this.checkedStatusList = checkedList;
        if (value != undefined && checkedList.length > 0) {
            for (var i = 0; i < checkedList.length; i++) {
                this.checkedStatusList = checkedList[i].label ? value.filter((quote: any) =>
                    quote[4].QuoteStatus == (checkedList[i].label)) : value; 

                this.filteredValue = (this.filteredValue != undefined) ? this.filteredValue.concat(this.checkedStatusList) : this.checkedStatusList;
            }
        }
        return this.filteredValue ? this.filteredValue : this.checkedStatusList;
    }
}