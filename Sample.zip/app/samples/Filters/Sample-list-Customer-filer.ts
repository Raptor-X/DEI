﻿import { PipeTransform, Pipe, EventEmitter, Output } from '@angular/core';
import { FilterCount } from '../shared/filterCount';
import { SampleListItem } from '../shared/samplelistitem';
import { Logger } from "angular2-logger/core";

@Pipe({
    name: 'CustomerFilter',
    pure: false
})

export class CustomerFilterPipe implements PipeTransform {
    constructor(private _logger: Logger) { }
    transform(value: SampleListItem[], filterByCountry: string[], filteredCount: FilterCount): SampleListItem[] {
        let filteredValue: any[] = [];
        let filteredValueTemp: any[] = [];
        if (filterByCountry.length > 0) {
            for (var i = 0; i < filterByCountry.length; i++) {
                if (value != undefined) {
                    filteredValue = filterByCountry[i] ? value.filter((sample: SampleListItem) =>
                        sample.CustomerName == filterByCountry[i]) : value;
                    if (filteredValueTemp == undefined) {
                        filteredValueTemp = filteredValue;
                    }
                    else {
                        filteredValueTemp = filteredValueTemp.concat(filteredValue);
                    }
                }
            }
        }
        filteredCount.count = filteredValueTemp ? filteredValueTemp.length : 0;
        return filteredValueTemp ? filteredValueTemp : value;
    }
}