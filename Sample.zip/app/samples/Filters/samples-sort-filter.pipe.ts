﻿import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name: 'samplesSortFilter'

})

export class samplesSortFilterPipe implements PipeTransform {
    transform(value: any, sortBy: string, sortType: string): any {

        if (value !== undefined) {
            switch (sortBy) {
                case "Date Created: Newest First":
                case "Date Created: Oldest First":
                case "Creation Date":
                    value.sort((a: any, b: any) => {
                        let dateA: Date = (new Date(a[4].dateCreated));
                        let dateB: Date = (new Date(b[4].dateCreated));
                        if ((sortBy === "Date Created: Newest First") || (sortBy === "Creation Date" && sortType === "DES"))
                            return dateB.getTime() - dateA.getTime();
                        else
                            return dateA.getTime() - dateB.getTime();
                    });
                    break;
                case "Price: Highest First":
                case "Price: Lowest First":
                case "Price":
                    value.sort((a: any, b: any) => {
                        let priceA: number = a[3].price;
                        let priceB: number = b[3].price;
                        if ((sortBy === "Price: Highest First") || (sortBy === "Price" && sortType === "DES")) {
                            /*Moving invalid price at bottom of list*/
                            if (isNaN(priceA))
                                return 1;
                            else if (isNaN(priceB))
                                return -1;
                            else
                                return priceB - priceA;
                        }
                        else {
                            /*Moving invalid price at bottom of the  list*/
                            if (isNaN(priceA))
                                return 1;
                            else if (isNaN(priceB))
                                return -1;
                            else
                                return priceA - priceB;
                        }
                    });
                    break;
                case "Status: A-Z":
                    value.sort((a: any, b: any) => {
                        if (a[4].QuoteStatus < b[4].QuoteStatus) {
                            return -1;
                        } else if (a[4].QuoteStatus > b[4].QuoteStatus) {
                            return 1;
                        }
                    });
                    break;
                case "Status: Z-A":
                    value.sort((a: any, b: any) => {
                        if (a[4].QuoteStatus > b[4].QuoteStatus) {
                            return -1;
                        } else if (a[4].QuoteStatus < b[4].QuoteStatus) {
                            return 1;
                        }
                    });
                    break;
                case "Expiring: Soonest First":
                    value.sort((a: any, b: any) => {
                        let dateA: Date = (new Date(a[4].ExpirationDate));
                        let dateB: Date = (new Date(b[4].ExpirationDate));
                        /*Moving invalid price at bottom of  list*/
                        let inValidDate: any = "Invalid Date";
                        if (dateA.toString() === inValidDate)
                            return 1;
                        else if (dateB.toString() === inValidDate)
                            return -1;
                        else
                            return dateA.getTime() - dateB.getTime();
                    });
                    break;
                case "Description":
                    value.sort((a: any, b: any) => {
                        let QuoteNameA = a[4].QuoteName.toLowerCase();
                        let QuoteNameB = b[4].QuoteName.toLowerCase();
                        if (sortType === "ASC") {
                            if (QuoteNameA < QuoteNameB) {
                                return -1;
                            } else if (QuoteNameA > QuoteNameB) {
                                return 1;
                            }
                        } else {
                            if (QuoteNameA > QuoteNameB) {
                                return -1;
                            } else if (QuoteNameA < QuoteNameB) {
                                return 1;
                            }
                        }
                    });
                    break;
                case "Sample Number : High to Low":
                    value.sort((a: any, b: any) => {
                        let QuoteNumberA = a[2].value.toLowerCase();
                        let QuoteNumberB = b[2].value.toLowerCase();
                        if (sortType === "ASC") {
                            if (QuoteNumberA < QuoteNumberB) {
                                return -1;
                            } else if (QuoteNumberA > QuoteNumberB) {
                                return 1;
                            }
                        } else {
                            if (QuoteNumberA > QuoteNumberB) {
                                return -1;
                            } else if (QuoteNumberA < QuoteNumberB) {
                                return 1;
                            }
                        }
                    });
                    break;
                default:
                    break;
            }
            return value;
        }
    }
}