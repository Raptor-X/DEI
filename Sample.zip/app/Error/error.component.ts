﻿import {Component,Input} from '@angular/core';
import {NgModule} from '@angular/core';
import {ErrorType} from './errorType';
import { Logger } from "angular2-logger/core";

@Component({
    selector: 'error-template',
    templateUrl: '../../app/Error/error-template.html',
    styleUrls: ['../../app/Error/error-template.css']
})

export class ErrorHandlerComponent {

    @Input() ErrorMesage: ErrorType;
    constructor(private _logger: Logger) { }
    public handleError(errorType: ErrorType,error?: string, methodName?: string): void {
        if ((<any>document).getElementById('loadingSample') !== undefined &&
            (<any>document).getElementById('loadingSample') !== null) {
            (<any>document).getElementById('loadingSample').style.visibility = "hidden";
        }
        if (errorType === ErrorType.error)
        this._logger.error("Error Occured: Description: " + error + "at Method - " + methodName);
    }
}

