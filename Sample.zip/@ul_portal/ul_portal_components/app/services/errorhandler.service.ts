﻿import {ErrorHandler, Injectable} from '@angular/core'
import { Logger } from "angular2-logger/core";
declare var appInsights: any;

@Injectable() 
export class CustomErrorHandler extends ErrorHandler {
    constructor(private _logger: Logger) {        
        // We rethrow exceptions, so operations like 'bootstrap' will result in an error
        // when an error happens. If we do not rethrow, bootstrap will always succeed.
        super(true);
        this._logger.info('App Opening');
    }

    handleError(error: any) {
        this._logger.error('Error Handled by Error Handler: ' + error);
        //appInsights.trackException(error);
        //super.handleError(error);
    }
}