﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Configuration } from './app.constants';
import { IAlert } from '../../app/models/alert';


@Injectable()
export class AlertService {

    private actionUrl: string;
    private headers: Headers;
    private _configuration: Configuration = new Configuration();
    private http: Http;

    constructor(_http: Http) {

        this.actionUrl = 'home/GetAlertList';
        this.http = _http;
        
    }

    public GetAlertSummary = (): any => {
        return this.http.get(this.actionUrl)
            .map((response: Response) => <any>response.json())
            .catch(this.handleError);
    }

    private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }
}
