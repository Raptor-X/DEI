﻿import { Injectable } from '@angular/core';

@Injectable()
export class Configuration {
    public Server: string = "/"; //This will have order service URL
    public ApiUrl: string = "Home/";
    public ServerWithApiUrl = this.Server + this.ApiUrl;
}