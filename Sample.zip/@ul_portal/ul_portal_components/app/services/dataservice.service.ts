import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';

@Injectable()
export class DataService  {

    getDataServiceName() : string {
        return 'Generic Data Service';   
    }

	getDataSetList() : Observable<any[]> {
		return undefined;
	} 
    getDetailDataObject(id:number) : Observable<any> {
        return undefined;
    }
}