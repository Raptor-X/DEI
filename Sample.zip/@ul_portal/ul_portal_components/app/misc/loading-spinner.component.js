"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var ulcomponent_component_1 = require('../../app/content/ulcomponent.component');
/* Decorator */
var LoadingSpinnerComponent = (function (_super) {
    __extends(LoadingSpinnerComponent, _super);
    function LoadingSpinnerComponent() {
        _super.apply(this, arguments);
    }
    LoadingSpinnerComponent.prototype.ngOnInit = function () {
    };
    LoadingSpinnerComponent = __decorate([
        core_1.Component({
            selector: 'loading-spinner',
            moduleId: '',
            template: "\n        <img src=\"images/preload.gif\" />\n    ",
            styles: ["\n        img {\n            margin: auto;\n            display: block;\n            position: relative;\n            top: 20px; \n        }\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], LoadingSpinnerComponent);
    return LoadingSpinnerComponent;
}(ulcomponent_component_1.ULComponent));
exports.LoadingSpinnerComponent = LoadingSpinnerComponent;
//# sourceMappingURL=loading-spinner.component.js.map