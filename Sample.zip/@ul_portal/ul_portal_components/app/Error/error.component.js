"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var errorType_1 = require('./errorType');
var core_2 = require("angular2-logger/core");
var ErrorHandlerComponent = (function () {
    function ErrorHandlerComponent(_logger) {
        this._logger = _logger;
    }
    ErrorHandlerComponent.prototype.handleError = function (errorType, error, methodName) {
        if (document.getElementById('loadingOrders') !== undefined &&
            document.getElementById('loadingOrders') !== null) {
            document.getElementById('loadingOrders').style.visibility = "hidden";
        }
        if (errorType === errorType_1.ErrorType.error)
            this._logger.error("Error Occured: Description: " + error + "at Method - " + methodName);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], ErrorHandlerComponent.prototype, "ErrorMesage", void 0);
    ErrorHandlerComponent = __decorate([
        core_1.Component({
            moduleId: '',
            selector: 'error-template',
            template: "\n\n        <div class=\"container\">\n            <div class=\"row has-error\" align=\"center\">\n            <label class=\"control-label h2 errorLabel\">\n                {{ErrorMesage}}\n            </label></div>\n        </div>\n            \n    ",
            styles: ["\n            .errorLabel {\n            color:red;\n            margin-top:7em;\n        }\n    "]
        }), 
        __metadata('design:paramtypes', [core_2.Logger])
    ], ErrorHandlerComponent);
    return ErrorHandlerComponent;
}());
exports.ErrorHandlerComponent = ErrorHandlerComponent;
//# sourceMappingURL=error.component.js.map