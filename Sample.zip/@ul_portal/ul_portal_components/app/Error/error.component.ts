﻿import {Component,Input} from '@angular/core';
import {NgModule} from '@angular/core';
import {ErrorType} from './errorType';
import { Logger } from "angular2-logger/core";
@Component({
    moduleId: '',
    selector: 'error-template',
    template: `

        <div class="container">
            <div class="row has-error" align="center">
            <label class="control-label h2 errorLabel">
                {{ErrorMesage}}
            </label></div>
        </div>
            
    `,
    styles: [`
            .errorLabel {
            color:red;
            margin-top:7em;
        }
    `]
})

export class ErrorHandlerComponent {

    constructor(private _logger:Logger) {
    }
    @Input() ErrorMesage: ErrorType;

    public handleError(errorType: ErrorType,error?: string, methodName?: string): void {
        if ((<any>document).getElementById('loadingOrders') !== undefined &&
            (<any>document).getElementById('loadingOrders') !== null) {
            (<any>document).getElementById('loadingOrders').style.visibility = "hidden";
        }
        if (errorType === ErrorType.error)
        this._logger.error("Error Occured: Description: " + error + "at Method - " + methodName);
    }
}

