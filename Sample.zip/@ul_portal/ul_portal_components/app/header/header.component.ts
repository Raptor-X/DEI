﻿import { Component, Input, OnInit } from '@angular/core';
import { ULComponent } from '../../app/content/ulcomponent.component';

/* Decorator */
@Component({
    selector: 'header',
    moduleId: '',
    template: `
<section class="row header-component">
    <div class="row header-breadcrumb">
        <h5 [innerHTML]="headerBreadCrumb"></h5>
    </div>
    <div class="row header-title-date">
        <div class="header-title">

            <h1>{{ headerSubTitle }}</h1>

            <h1>{{ headerTitle }}</h1>

        </div>
        <div [class]="getDateClass()" *ngIf="updateDate">
            <div class="header-date-text">			
                <div class="header-date-text-label"><h5>Last Updated</h5>  {{updateDate | date:'mediumDate' }} at {{updateHours |date:'shortTime'}}</div>
                <span style="cursor:pointer" class="glyphicon glyphicon-info-sign" [tooltipHtml]="toolTipTemplate" (tooltipStateChanged)="tooltipStateChanged($event)"></span>
            </div>
        </div>
    </div>
</section>
    <template #toolTipTemplate let-model="model" class="tooltip-template" style="color:gainsboro">
        <h5 class="h5-tooltip">Why am i seeing this?</h5>
        <h6 class="h6-tooltip">If you have a concern about this data, please contact the</h6>
        <h6 class="h6-tooltip"><u>UL Customer Support Center.</u></h6>
    </template>    
    `,
    styles: [`
    /* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
header {
  /*border: solid 10px red !important;*/ }

.header-date-icon-up {
  margin-top: -15px !important; }

.header-component {
  height: 74px;
  padding: 22px 27px; }

.header-breadcrumb {
  height: 35px; }
  .header-breadcrumb h5 {
    padding-left: 2px; }

.header-title {
  float: left; }

.header-date {
  margin-top: 19px;
  float: right; }
  .header-date * {
    display: inline; }

.header-date-text {
  vertical-align: bottom; }

.header-date-icon {
  cursor: pointer; }

.row {
  width: auto; }

    `]
})

export class HeaderComponent extends ULComponent implements OnInit {
    @Input() headerBreadCrumb: string = '';
    @Input() headerTitle: string = '';
    @Input() headerSubTitle: string = '';
    @Input() updateDate: any;
    @Input() updateHours: any;
    @Input() dateEvenWithBreadCrumbs: boolean = false;
    dateClass = "header-date";
    ngOnInit() {
        if (this.dateEvenWithBreadCrumbs) {
            this.dateClass = "header-date header-date-icon-up";            
        } 
    }
    getDateClass() {
        return this.dateClass;
    }
	 tooltipStateChanged(state: boolean): void {
        console.log(`Tooltip is opens: ${state}`);
    }
    
}
