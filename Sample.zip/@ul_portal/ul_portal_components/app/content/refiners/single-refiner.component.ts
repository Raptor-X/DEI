﻿/*  System Imports  */
import {  Component, Input, Output, EventEmitter, ElementRef, NgModule, trigger, state, style, animate, transition, OnInit, ViewChild } from '@angular/core';
declare var $:any;
/* Decorator */
@Component({
    selector: 'single-refiner',
    moduleId: '',
    template: `
<section class="refiner-component">
    
    <!--determines where the content actually goes.-->
    <!--<ng-content></ng-content>-->

    <div class="refiner-container">

        <div #turndownarrow class="refiner-turndown-container" (click)="toggleSlide()">
            <h4>{{refinerType}}</h4>
            <div  [class]="id + ' refiner-turndown-arrow'" ></div>
        </div>

        <div #datacontainer [class]="id + ' refiner-data-container'">

            <div class="refiner-line-item">
                <div class="refiner-checkbox">
                    <input type="radio" name="{{id}}" class="{{id}} radiobutton" (change)="checkboxSelected($event, refinerItem)" />
                </div>
                <div class="refiner-label">Today</div>
                
            </div>
			            <div class="refiner-line-item">
                <div class="refiner-checkbox">
                    <input type="radio" name="{{id}}" class="{{id}} radiobutton" (change)="checkboxSelected($event, refinerItem)" />
                </div>
                <div class="refiner-label">Last 7 Days</div>
                
            </div>
			
			            <div class="refiner-line-item">
                <div class="refiner-checkbox">
                    <input type="radio" name="{{id}}" class="{{id}} radiobutton" (change)="checkboxSelected($event, refinerItem)" />
                </div>
                <div class="refiner-label">Last 30 Days</div>
                
            </div>
			
			            <div class="refiner-line-item">
                <div class="refiner-checkbox">
                    <input type="radio" name="{{id}}" class="{{id}} radiobutton" (change)="checkboxSelected($event, refinerItem)" />
                </div>
                <div class="refiner-label">Last 90 Days</div>
                
            </div>
			
			            <div class="refiner-line-item">
                <div class="refiner-checkbox">
                    <input type="radio"  name="{{id}}" class="{{id}} radiobutton" (change)="checkboxSelected($event, refinerItem)" />
                </div>
                <div class="refiner-label">Last 365 Days</div>
                
            </div>
			
			<div class="refiner-line-item">
                <div class="refiner-checkbox">
                    <input type="radio"  name="{{id}}" class="{{id}} radiobutton" (change)="checkboxSelected($event, refinerItem)" />
                </div>
                <div class="refiner-label">Date Range</div>
                </div>
                <div class="refiner-line-item">
                <div class="list-group-item date-picker">
					<div class="row">
						<my-date-picker [options] = "myDatePickerOptions" #fromDate title="From" (dateChanged)="onFromDateChanged($event)"></my-date-picker>
					</div>
                    </div>
                </div>
                                <div class="refiner-line-item">
                <div class="list-group-item date-picker">
					<div class="row">
						<my-date-picker [options] = "myDatePickerOptions" #toDate title="To" (dateChanged)="onToDateChanged($event)"></my-date-picker>
					</div>
				</div>
            </div>



        </div>

    </div>

</section>

    
    `,
    styles: [`
/* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.submitted-text {
  color: #3c9b35; }

.sentCustomer-text {
  color: #55b9b7; }

.expired-text {
  color: red; }

.default-text {
  color: navy; }

.draft-text {
  color: #4a93e2; }

.offered-text {
  color: #55b9b7; }

.accepted-text {
  color: #3c9b35; }

.submitted {
  color: #3c9b35; }

.sentCustomer {
  color: #55b9b7; }

.expired {
  border-left-color: red; }

.default {
  border-left-color: turquoise; }

.draft {
  border-left-color: #4a93e2; }

.offered {
  border-left-color: #55b9b7; }

.accepted {
  border-left-color: #3c9b35; }

input.checkbox {
  display: none; }

.refiner-checkbox-on {
  cursor: pointer;
  padding-left: 15px;
  min-height: 14px;
  min-width: 14px;
  background: url("../../../images/checkbox-on.png") no-repeat center right; }

.refiner-checkbox-off {
  cursor: pointer;
  padding-left: 15px;
  min-height: 14px;
  min-width: 14px;
  background: url("../../../images/checkbox-off.png") no-repeat center right; }

.refiner-component {
  /*border-left: solid 0 transparent;
    border-right: solid 0 transparent;*/
  padding: 20px 0 0 20px;
  border-bottom: solid 1px #cbcdd1;
  /*min-height: 250px;*/ }
  .refiner-component .refiner-container {
    /*margin-bottom: 20px;*/ }
    .refiner-component .refiner-container .refiner-turndown-container {
      cursor: pointer;
      height: 40px;
      margin: 0 15px 0 0;
      /*padding-right: 3px;*/
      clear: both; }
      .refiner-component .refiner-container .refiner-turndown-container h4 {
        width: 80%;
        height: 100%;
        float: left;
        cursor: pointer; }
      .refiner-component .refiner-container .refiner-turndown-container .refiner-turndown-arrow {
        width: 20%;
        height: 24px;
        background: url("../../../images/turndown-arrow.png") no-repeat center right;
        float: left; }
    .refiner-component .refiner-container .refiner-data-container {
      margin: 0 5px 30px 0; }
      .refiner-component .refiner-container .refiner-data-container .refiner-line-item {
        height: 20px;
        float: none;
        clear: both;
        margin-bottom: 16px;
        max-width: 180px !important; }
        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .date-picker .row my-date-picker .mydp .selectiongroup {
          max-width: 170px !important; }
        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .date-picker {
          margin: 0 0 10px 0; }
        .refiner-component .refiner-container .refiner-data-container .refiner-line-item div {
          float: left;
          /*width: 50px;*/ }
        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .refiner-checkbox {
          width: 15%;
          /*float: left;*/ }
        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .refiner-label {
          width: 60%;
          margin-bottom: 10px;
          /*float: left;*/ }
        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .refiner-value {
          width: 20%;
          text-align: right;
          /*float: left;*/
          /*clear: both;*/ }
      .refiner-component .refiner-container .refiner-data-container .refiner-show-more {
        margin-bottom: 20px;
        width: 121px;
        height: 33px;
        background-color: #e6e9ed;
        background: url("../../../images/showmore-arrow.svg") #e6e9ed 100px 11px no-repeat;
        text-align: left;
        padding-top: 8px;
        padding-left: 8px; }
      .refiner-component .refiner-container .refiner-data-container .refiner-show-less {
        margin-bottom: 20px;
        width: 121px;
        height: 33px;
        background-color: #e6e9ed;
        background: url("../../../images/showless-arrow.png") #e6e9ed 100px 11px no-repeat;
        text-align: left;
        padding-top: 8px;
        padding-left: 8px;
        background-size: 8px 13px; }
      .refiner-component .refiner-container .refiner-data-container .refiner-select-all {
        /*text-align: left;*/
        font-size: .9em;
        margin-top: 5px;
        clear: both; }
        .refiner-component .refiner-container .refiner-data-container .refiner-select-all a {
          font-size: .9em; }

.datepicker-container {
  min-height: 350px; }
    
    `],
    animations: [
        trigger('shrinkOut', [
            state('in', style({ height: '*' })),
            transition('* => void', [
                style({ height: '*' }),
                animate(250, style({ height: 0 }))
            ])
        ])
    ]
})

export class SingleRefinerComponent implements OnInit   {
    pageTitle: string = '';
	@Input() id:string;
    @Input() refinerType: string;
	@ViewChild('turndownarrow') turndownarrow:ElementRef;
	@ViewChild('datacontainer') datacontainer:ElementRef;
    @Output() onChangeEvent = new EventEmitter<any>();
    from: Date;
    customtodate: Date;
    textFromDate: any = new ElementRef({ selectionDayTxt: "" })
    textToDate: any = new ElementRef({ selectionDayTxt: "" })
    @ViewChild('fromDate') dateFrom: ElementRef;
    @ViewChild('toDate') dateTo: ElementRef;
    dateRangeCheck: boolean = false;

	fromDate: Date;
	toDate: Date;

    //@Input() type: string;

    //selectItem(value: string) {
    //    this.state = (this.state === 'inactive' ? 'active' : 'inactive');
    //    this.select.emit(value);
    //}
	myDatePickerOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm/dd/yyyy',
        firstDayOfWeek: 'mo',
        sunHighlight: true,
        inline: false,
        selectionTxtFontSize: '12px',
		componentDisabled: true
    };

    OnDateRangeFilterSelection(value: string): void {
        let copy = this.getCopyOfOptions();
        if (value == "Today" || value == "Last 7 Days" || value == "Last 30 Days" || value == "Last 90 Days" || value == "Last 365 Days")
            this.dateRangeCheck = false;
        if (value == "Date Range") {
            this.dateRangeCheck = true;
            this.from = undefined;
            this.customtodate = undefined;
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
        }
        /* Date text box Empty */
        if (this.dateRangeCheck == true) {
            copy.componentDisabled = false;
            this.myDatePickerOptions = copy;

        }
        else {
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textToDate.selectionDayTxt = "";
            copy.componentDisabled = true;
            this.myDatePickerOptions = copy;
        }
        /* End  */
    }


	
	toggleSlide() {
              if ($(this.datacontainer.nativeElement).css('display')== 'none') {
              $(this.datacontainer.nativeElement).slideDown( "slow", function() {
                    // Animation complete.
                });
              } else {
              $(this.datacontainer.nativeElement).slideUp( "slow", function() {
                    // Animation complete.
                });
              }
	}
	
	    //Custom Date Filter- 2261/2387 
    /*onFromDateChanged(event: any) {
        this.fromDate = new Date(event.formatted);         
		var retObject:any = new Object();
		var finalElement = 'Date Range';
		retObject.typeOfFilter = 'Date Range';
		if (finalElement == 'Date Range') {
			retObject.fromDate = this.fromDate;
			retObject.toDate = this.toDate;	
		} else {
			retObject.fromDate = undefined;
			retObject.toDate = undefined;
		}
		this.checkValidRange(retObject);
        this.onChangeEvent.emit(retObject);
    }	
	checkValidRange(retObject:any) {
        
		if ( (retObject.fromDate != undefined)  && (retObject.toDate != undefined) ) {
			if (retObject.fromDate > retObject.toDate) {
				alert('From Date should be less than or equal To Date');
			}
		}
        if (retObject.toDate != undefined) {
            if (retObject.toDate > new Date()) {
                alert('To Date should be less than or equal to Current Date.');
            }
        }
	}

    onToDateChanged(event: any) {
        this.toDate = new Date(event.formatted);
		var retObject:any = new Object();
		var finalElement = 'Date Range';
		retObject.typeOfFilter = 'Date Range';
		if (finalElement == 'Date Range') {
			retObject.fromDate = this.fromDate;
			retObject.toDate = this.toDate;	
		} else {
			retObject.fromDate = undefined;
			retObject.toDate = undefined;
		}
		this.checkValidRange(retObject);
        this.onChangeEvent.emit(retObject);
        
    }*/

    //Custom Date Filter- 2261/2387 
    onFromDateChanged(event: any) {
        this.from = new Date(event.formatted);
        //Added 'FROM' text as typeOfdateSelection flag to show 'FROM' label when date validation fails
        this.dateRangValidation('FROM');
        var retObject:any = new Object();
		var finalElement = 'Date Range';
		retObject.typeOfFilter = 'Date Range';
		if (finalElement == 'Date Range') {
			retObject.fromDate = this.from;
			retObject.toDate = this.customtodate;	
		} else {
			retObject.fromDate = undefined;
			retObject.toDate = undefined;
		}
        this.onChangeEvent.emit(retObject);
        

    }

    onToDateChanged(event: any) {
        this.customtodate = new Date(event.formatted);
        //Added 'TO' text as typeOfdateSelection flag to show 'TO' label when date validation fails
        this.dateRangValidation('TO');
                var retObject:any = new Object();
		var finalElement = 'Date Range';
		retObject.typeOfFilter = 'Date Range';
		if (finalElement == 'Date Range') {
			retObject.fromDate = this.from;
			retObject.toDate = this.customtodate;	
		} else {
			retObject.fromDate = undefined;
			retObject.toDate = undefined;
		}
        this.onChangeEvent.emit(retObject);
        
    }
    //Added method Show From/To text when user selected date fails validation
    private OnDateValidationFails(typeOfDate: string): void {
        if (typeOfDate === 'FROM') {
            /* Empty Custom date textbox */
            this.textFromDate = this.dateFrom;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.from = undefined;
            /* End */
        }
        else if (typeOfDate === 'TO') {
            /* Empty Custom date textbox */
            this.textToDate = this.dateTo;
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.customtodate = undefined;

            /* End */
        }
        
    }

    //Validation for Date Filter
    dateRangValidation(typeOfDate: string) {
        let currentDate = new Date();
        let ToDate = new Date(this.customtodate);
        let fromDate = new Date(this.from);
        if (fromDate > ToDate) {
            alert('From Date should be less than or equal to To Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (ToDate < fromDate) {
            alert('To Date should be greater than or equal to From Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < fromDate) {
            alert('From Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < ToDate) {
            alert('To Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
    }



  

    ngOnInit() {

        $("." + this.id + '.refiner-turndown-arrow').click(function() {
              if ($("." + this.id + ".refiner-data-container").css('display')== 'none') {
              $( "." + this.id + ".refiner-data-container" ).slideDown( "slow", function() {
                    // Animation complete.
                });
              } else {
              $( "." + this.id + ".refiner-data-container" ).slideUp( "slow", function() {
                    // Animation complete.
                });
              }
        })

        
    }
	getCopyOfOptions() {
        return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    }

    checkboxSelected(event:any, refinerItem:any) {
        var target = event.target || event.srcElement || event.currentTarget;
        var finalElement = target.parentElement.parentElement.childNodes[3].innerText;
		var retObject:any = new Object();
		retObject.typeOfFilter = finalElement;
		if (finalElement == 'Date Range') {
			let copy = this.getCopyOfOptions();
			copy.componentDisabled = false;
			this.myDatePickerOptions = copy;
			retObject.fromDate = this.fromDate;
			retObject.toDate = this.toDate;	
		} else {


            
			let copy = this.getCopyOfOptions();
			copy.componentDisabled = true;
			this.myDatePickerOptions = copy;
			retObject.fromDate = undefined;
			retObject.toDate = undefined;

            /* Empty Custom date textbox */
            this.textFromDate = this.dateFrom;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.from = undefined;
            /* End */

            /* Empty Custom date textbox */
            this.textToDate = this.dateTo;
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.customtodate = undefined;

            /* End */

		}
        this.onChangeEvent.emit(retObject);
    }
}