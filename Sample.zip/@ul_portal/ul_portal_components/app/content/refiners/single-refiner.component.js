"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var SingleRefinerComponent = (function () {
    function SingleRefinerComponent() {
        this.pageTitle = '';
        this.onChangeEvent = new core_1.EventEmitter();
        this.textFromDate = new core_1.ElementRef({ selectionDayTxt: "" });
        this.textToDate = new core_1.ElementRef({ selectionDayTxt: "" });
        this.dateRangeCheck = false;
        //@Input() type: string;
        //selectItem(value: string) {
        //    this.state = (this.state === 'inactive' ? 'active' : 'inactive');
        //    this.select.emit(value);
        //}
        this.myDatePickerOptions = {
            todayBtnTxt: 'Today',
            dateFormat: 'mm/dd/yyyy',
            firstDayOfWeek: 'mo',
            sunHighlight: true,
            inline: false,
            selectionTxtFontSize: '12px',
            componentDisabled: true
        };
    }
    SingleRefinerComponent.prototype.OnDateRangeFilterSelection = function (value) {
        var copy = this.getCopyOfOptions();
        if (value == "Today" || value == "Last 7 Days" || value == "Last 30 Days" || value == "Last 90 Days" || value == "Last 365 Days")
            this.dateRangeCheck = false;
        if (value == "Date Range") {
            this.dateRangeCheck = true;
            this.from = undefined;
            this.customtodate = undefined;
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
        }
        /* Date text box Empty */
        if (this.dateRangeCheck == true) {
            copy.componentDisabled = false;
            this.myDatePickerOptions = copy;
        }
        else {
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textToDate.selectionDayTxt = "";
            copy.componentDisabled = true;
            this.myDatePickerOptions = copy;
        }
        /* End  */
    };
    SingleRefinerComponent.prototype.toggleSlide = function () {
        if ($(this.datacontainer.nativeElement).css('display') == 'none') {
            $(this.datacontainer.nativeElement).slideDown("slow", function () {
                // Animation complete.
            });
        }
        else {
            $(this.datacontainer.nativeElement).slideUp("slow", function () {
                // Animation complete.
            });
        }
    };
    //Custom Date Filter- 2261/2387 
    /*onFromDateChanged(event: any) {
        this.fromDate = new Date(event.formatted);
        var retObject:any = new Object();
        var finalElement = 'Date Range';
        retObject.typeOfFilter = 'Date Range';
        if (finalElement == 'Date Range') {
            retObject.fromDate = this.fromDate;
            retObject.toDate = this.toDate;
        } else {
            retObject.fromDate = undefined;
            retObject.toDate = undefined;
        }
        this.checkValidRange(retObject);
        this.onChangeEvent.emit(retObject);
    }
    checkValidRange(retObject:any) {
        
        if ( (retObject.fromDate != undefined)  && (retObject.toDate != undefined) ) {
            if (retObject.fromDate > retObject.toDate) {
                alert('From Date should be less than or equal To Date');
            }
        }
        if (retObject.toDate != undefined) {
            if (retObject.toDate > new Date()) {
                alert('To Date should be less than or equal to Current Date.');
            }
        }
    }

    onToDateChanged(event: any) {
        this.toDate = new Date(event.formatted);
        var retObject:any = new Object();
        var finalElement = 'Date Range';
        retObject.typeOfFilter = 'Date Range';
        if (finalElement == 'Date Range') {
            retObject.fromDate = this.fromDate;
            retObject.toDate = this.toDate;
        } else {
            retObject.fromDate = undefined;
            retObject.toDate = undefined;
        }
        this.checkValidRange(retObject);
        this.onChangeEvent.emit(retObject);
        
    }*/
    //Custom Date Filter- 2261/2387 
    SingleRefinerComponent.prototype.onFromDateChanged = function (event) {
        this.from = new Date(event.formatted);
        //Added 'FROM' text as typeOfdateSelection flag to show 'FROM' label when date validation fails
        this.dateRangValidation('FROM');
        var retObject = new Object();
        var finalElement = 'Date Range';
        retObject.typeOfFilter = 'Date Range';
        if (finalElement == 'Date Range') {
            retObject.fromDate = this.from;
            retObject.toDate = this.customtodate;
        }
        else {
            retObject.fromDate = undefined;
            retObject.toDate = undefined;
        }
        this.onChangeEvent.emit(retObject);
    };
    SingleRefinerComponent.prototype.onToDateChanged = function (event) {
        this.customtodate = new Date(event.formatted);
        //Added 'TO' text as typeOfdateSelection flag to show 'TO' label when date validation fails
        this.dateRangValidation('TO');
        var retObject = new Object();
        var finalElement = 'Date Range';
        retObject.typeOfFilter = 'Date Range';
        if (finalElement == 'Date Range') {
            retObject.fromDate = this.from;
            retObject.toDate = this.customtodate;
        }
        else {
            retObject.fromDate = undefined;
            retObject.toDate = undefined;
        }
        this.onChangeEvent.emit(retObject);
    };
    //Added method Show From/To text when user selected date fails validation
    SingleRefinerComponent.prototype.OnDateValidationFails = function (typeOfDate) {
        if (typeOfDate === 'FROM') {
            /* Empty Custom date textbox */
            this.textFromDate = this.dateFrom;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.from = undefined;
        }
        else if (typeOfDate === 'TO') {
            /* Empty Custom date textbox */
            this.textToDate = this.dateTo;
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.customtodate = undefined;
        }
    };
    //Validation for Date Filter
    SingleRefinerComponent.prototype.dateRangValidation = function (typeOfDate) {
        var currentDate = new Date();
        var ToDate = new Date(this.customtodate);
        var fromDate = new Date(this.from);
        if (fromDate > ToDate) {
            alert('From Date should be less than or equal to To Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (ToDate < fromDate) {
            alert('To Date should be greater than or equal to From Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < fromDate) {
            alert('From Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < ToDate) {
            alert('To Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
    };
    SingleRefinerComponent.prototype.ngOnInit = function () {
        $("." + this.id + '.refiner-turndown-arrow').click(function () {
            if ($("." + this.id + ".refiner-data-container").css('display') == 'none') {
                $("." + this.id + ".refiner-data-container").slideDown("slow", function () {
                    // Animation complete.
                });
            }
            else {
                $("." + this.id + ".refiner-data-container").slideUp("slow", function () {
                    // Animation complete.
                });
            }
        });
    };
    SingleRefinerComponent.prototype.getCopyOfOptions = function () {
        return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    };
    SingleRefinerComponent.prototype.checkboxSelected = function (event, refinerItem) {
        var target = event.target || event.srcElement || event.currentTarget;
        var finalElement = target.parentElement.parentElement.childNodes[3].innerText;
        var retObject = new Object();
        retObject.typeOfFilter = finalElement;
        if (finalElement == 'Date Range') {
            var copy = this.getCopyOfOptions();
            copy.componentDisabled = false;
            this.myDatePickerOptions = copy;
            retObject.fromDate = this.fromDate;
            retObject.toDate = this.toDate;
        }
        else {
            var copy = this.getCopyOfOptions();
            copy.componentDisabled = true;
            this.myDatePickerOptions = copy;
            retObject.fromDate = undefined;
            retObject.toDate = undefined;
            /* Empty Custom date textbox */
            this.textFromDate = this.dateFrom;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.from = undefined;
            /* End */
            /* Empty Custom date textbox */
            this.textToDate = this.dateTo;
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.customtodate = undefined;
        }
        this.onChangeEvent.emit(retObject);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], SingleRefinerComponent.prototype, "id", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], SingleRefinerComponent.prototype, "refinerType", void 0);
    __decorate([
        core_1.ViewChild('turndownarrow'), 
        __metadata('design:type', core_1.ElementRef)
    ], SingleRefinerComponent.prototype, "turndownarrow", void 0);
    __decorate([
        core_1.ViewChild('datacontainer'), 
        __metadata('design:type', core_1.ElementRef)
    ], SingleRefinerComponent.prototype, "datacontainer", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], SingleRefinerComponent.prototype, "onChangeEvent", void 0);
    __decorate([
        core_1.ViewChild('fromDate'), 
        __metadata('design:type', core_1.ElementRef)
    ], SingleRefinerComponent.prototype, "dateFrom", void 0);
    __decorate([
        core_1.ViewChild('toDate'), 
        __metadata('design:type', core_1.ElementRef)
    ], SingleRefinerComponent.prototype, "dateTo", void 0);
    SingleRefinerComponent = __decorate([
        core_1.Component({
            selector: 'single-refiner',
            moduleId: '',
            template: "\n<section class=\"refiner-component\">\n    \n    <!--determines where the content actually goes.-->\n    <!--<ng-content></ng-content>-->\n\n    <div class=\"refiner-container\">\n\n        <div #turndownarrow class=\"refiner-turndown-container\" (click)=\"toggleSlide()\">\n            <h4>{{refinerType}}</h4>\n            <div  [class]=\"id + ' refiner-turndown-arrow'\" ></div>\n        </div>\n\n        <div #datacontainer [class]=\"id + ' refiner-data-container'\">\n\n            <div class=\"refiner-line-item\">\n                <div class=\"refiner-checkbox\">\n                    <input type=\"radio\" name=\"{{id}}\" class=\"{{id}} radiobutton\" (change)=\"checkboxSelected($event, refinerItem)\" />\n                </div>\n                <div class=\"refiner-label\">Today</div>\n                \n            </div>\n\t\t\t            <div class=\"refiner-line-item\">\n                <div class=\"refiner-checkbox\">\n                    <input type=\"radio\" name=\"{{id}}\" class=\"{{id}} radiobutton\" (change)=\"checkboxSelected($event, refinerItem)\" />\n                </div>\n                <div class=\"refiner-label\">Last 7 Days</div>\n                \n            </div>\n\t\t\t\n\t\t\t            <div class=\"refiner-line-item\">\n                <div class=\"refiner-checkbox\">\n                    <input type=\"radio\" name=\"{{id}}\" class=\"{{id}} radiobutton\" (change)=\"checkboxSelected($event, refinerItem)\" />\n                </div>\n                <div class=\"refiner-label\">Last 30 Days</div>\n                \n            </div>\n\t\t\t\n\t\t\t            <div class=\"refiner-line-item\">\n                <div class=\"refiner-checkbox\">\n                    <input type=\"radio\" name=\"{{id}}\" class=\"{{id}} radiobutton\" (change)=\"checkboxSelected($event, refinerItem)\" />\n                </div>\n                <div class=\"refiner-label\">Last 90 Days</div>\n                \n            </div>\n\t\t\t\n\t\t\t            <div class=\"refiner-line-item\">\n                <div class=\"refiner-checkbox\">\n                    <input type=\"radio\"  name=\"{{id}}\" class=\"{{id}} radiobutton\" (change)=\"checkboxSelected($event, refinerItem)\" />\n                </div>\n                <div class=\"refiner-label\">Last 365 Days</div>\n                \n            </div>\n\t\t\t\n\t\t\t<div class=\"refiner-line-item\">\n                <div class=\"refiner-checkbox\">\n                    <input type=\"radio\"  name=\"{{id}}\" class=\"{{id}} radiobutton\" (change)=\"checkboxSelected($event, refinerItem)\" />\n                </div>\n                <div class=\"refiner-label\">Date Range</div>\n                </div>\n                <div class=\"refiner-line-item\">\n                <div class=\"list-group-item date-picker\">\n\t\t\t\t\t<div class=\"row\">\n\t\t\t\t\t\t<my-date-picker [options] = \"myDatePickerOptions\" #fromDate title=\"From\" (dateChanged)=\"onFromDateChanged($event)\"></my-date-picker>\n\t\t\t\t\t</div>\n                    </div>\n                </div>\n                                <div class=\"refiner-line-item\">\n                <div class=\"list-group-item date-picker\">\n\t\t\t\t\t<div class=\"row\">\n\t\t\t\t\t\t<my-date-picker [options] = \"myDatePickerOptions\" #toDate title=\"To\" (dateChanged)=\"onToDateChanged($event)\"></my-date-picker>\n\t\t\t\t\t</div>\n\t\t\t\t</div>\n            </div>\n\n\n\n        </div>\n\n    </div>\n\n</section>\n\n    \n    ",
            styles: ["\n/* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.submitted-text {\n  color: #3c9b35; }\n\n.sentCustomer-text {\n  color: #55b9b7; }\n\n.expired-text {\n  color: red; }\n\n.default-text {\n  color: navy; }\n\n.draft-text {\n  color: #4a93e2; }\n\n.offered-text {\n  color: #55b9b7; }\n\n.accepted-text {\n  color: #3c9b35; }\n\n.submitted {\n  color: #3c9b35; }\n\n.sentCustomer {\n  color: #55b9b7; }\n\n.expired {\n  border-left-color: red; }\n\n.default {\n  border-left-color: turquoise; }\n\n.draft {\n  border-left-color: #4a93e2; }\n\n.offered {\n  border-left-color: #55b9b7; }\n\n.accepted {\n  border-left-color: #3c9b35; }\n\ninput.checkbox {\n  display: none; }\n\n.refiner-checkbox-on {\n  cursor: pointer;\n  padding-left: 15px;\n  min-height: 14px;\n  min-width: 14px;\n  background: url(\"../../../images/checkbox-on.png\") no-repeat center right; }\n\n.refiner-checkbox-off {\n  cursor: pointer;\n  padding-left: 15px;\n  min-height: 14px;\n  min-width: 14px;\n  background: url(\"../../../images/checkbox-off.png\") no-repeat center right; }\n\n.refiner-component {\n  /*border-left: solid 0 transparent;\n    border-right: solid 0 transparent;*/\n  padding: 20px 0 0 20px;\n  border-bottom: solid 1px #cbcdd1;\n  /*min-height: 250px;*/ }\n  .refiner-component .refiner-container {\n    /*margin-bottom: 20px;*/ }\n    .refiner-component .refiner-container .refiner-turndown-container {\n      cursor: pointer;\n      height: 40px;\n      margin: 0 15px 0 0;\n      /*padding-right: 3px;*/\n      clear: both; }\n      .refiner-component .refiner-container .refiner-turndown-container h4 {\n        width: 80%;\n        height: 100%;\n        float: left;\n        cursor: pointer; }\n      .refiner-component .refiner-container .refiner-turndown-container .refiner-turndown-arrow {\n        width: 20%;\n        height: 24px;\n        background: url(\"../../../images/turndown-arrow.png\") no-repeat center right;\n        float: left; }\n    .refiner-component .refiner-container .refiner-data-container {\n      margin: 0 5px 30px 0; }\n      .refiner-component .refiner-container .refiner-data-container .refiner-line-item {\n        height: 20px;\n        float: none;\n        clear: both;\n        margin-bottom: 16px;\n        max-width: 180px !important; }\n        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .date-picker .row my-date-picker .mydp .selectiongroup {\n          max-width: 170px !important; }\n        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .date-picker {\n          margin: 0 0 10px 0; }\n        .refiner-component .refiner-container .refiner-data-container .refiner-line-item div {\n          float: left;\n          /*width: 50px;*/ }\n        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .refiner-checkbox {\n          width: 15%;\n          /*float: left;*/ }\n        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .refiner-label {\n          width: 60%;\n          margin-bottom: 10px;\n          /*float: left;*/ }\n        .refiner-component .refiner-container .refiner-data-container .refiner-line-item .refiner-value {\n          width: 20%;\n          text-align: right;\n          /*float: left;*/\n          /*clear: both;*/ }\n      .refiner-component .refiner-container .refiner-data-container .refiner-show-more {\n        margin-bottom: 20px;\n        width: 121px;\n        height: 33px;\n        background-color: #e6e9ed;\n        background: url(\"../../../images/showmore-arrow.svg\") #e6e9ed 100px 11px no-repeat;\n        text-align: left;\n        padding-top: 8px;\n        padding-left: 8px; }\n      .refiner-component .refiner-container .refiner-data-container .refiner-show-less {\n        margin-bottom: 20px;\n        width: 121px;\n        height: 33px;\n        background-color: #e6e9ed;\n        background: url(\"../../../images/showless-arrow.png\") #e6e9ed 100px 11px no-repeat;\n        text-align: left;\n        padding-top: 8px;\n        padding-left: 8px;\n        background-size: 8px 13px; }\n      .refiner-component .refiner-container .refiner-data-container .refiner-select-all {\n        /*text-align: left;*/\n        font-size: .9em;\n        margin-top: 5px;\n        clear: both; }\n        .refiner-component .refiner-container .refiner-data-container .refiner-select-all a {\n          font-size: .9em; }\n\n.datepicker-container {\n  min-height: 350px; }\n    \n    "],
            animations: [
                core_1.trigger('shrinkOut', [
                    core_1.state('in', core_1.style({ height: '*' })),
                    core_1.transition('* => void', [
                        core_1.style({ height: '*' }),
                        core_1.animate(250, core_1.style({ height: 0 }))
                    ])
                ])
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], SingleRefinerComponent);
    return SingleRefinerComponent;
}());
exports.SingleRefinerComponent = SingleRefinerComponent;
//# sourceMappingURL=single-refiner.component.js.map