"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var RefinerComponent = (function () {
    function RefinerComponent() {
        this.pageTitle = '';
        this.defaultCheckboxStyle = 'refiner-checkbox-on';
        this.onChangeEvent = new core_1.EventEmitter();
        this.refinerUpdateButtonText = "Show More";
        this.refinerUpdateButtonTextLess = "Show Less";
    }
    //@Input() type: string;
    //selectItem(value: string) {
    //    this.state = (this.state === 'inactive' ? 'active' : 'inactive');
    //    this.select.emit(value);
    //}
    RefinerComponent.prototype.ngOnInit = function () {
        if (this.id == 'statusRefiner') {
            this.defaultCheckboxName = 'View All';
        }
        else if (this.id == 'companiesRefiner') {
            this.defaultCheckboxName = 'Select All';
        }
        for (var i = 0; i < this.refinerItems.length; i++) {
            this.refinerItems[i].CSSClass = 'refiner-checkbox-on';
        }
        this.selectedRefinerItems = new Array();
        this.selectedRefinerItems = this.refinerItems.slice();
        if (this.refinerItems.length < 5) {
            this.refinerItemCount = this.refinerItems.length;
        }
        else {
            this.refinerItemCount = 5;
        }
    };
    RefinerComponent.prototype.toggleSlide = function () {
        if ($(this.datacontainer.nativeElement).css('display') == 'none') {
            $(this.datacontainer.nativeElement).slideDown("slow", function () {
                // Animation complete.
            });
        }
        else {
            $(this.datacontainer.nativeElement).slideUp("slow", function () {
                // Animation complete.
            });
        }
    };
    RefinerComponent.prototype.updateRefinerItemCount = function () {
        this.refinerItemCount = this.refinerItems.length;
    };
    RefinerComponent.prototype.subtractRefinerItemCount = function () {
        if (this.refinerItems.length > 4) {
            this.refinerItemCount = 5;
        }
        else {
            this.refinerItemCount = this.refinerItems.length;
        }
    };
    RefinerComponent.prototype.checkboxSelected = function (event, refinerItem) {
        console.log("Before:" + JSON.stringify(this.selectedRefinerItems));
        refinerItem.CSSClass = (refinerItem.CSSClass == 'refiner-checkbox-off' ? 'refiner-checkbox-on' : 'refiner-checkbox-off');
        var target = event.target || event.srcElement || event.currentTarget;
        target = target.nextElementSibling;
        if (target.checked) {
            target.checked = false;
        }
        else {
            target.checked = true;
        }
        if (target.checked) {
            this.selectedRefinerItems.push(refinerItem);
        }
        else {
            this.removeByAttr(this.selectedRefinerItems, "label", refinerItem.label);
        }
        console.log("After: " + JSON.stringify(this.selectedRefinerItems));
        this.onChangeEvent.emit(this.selectedRefinerItems);
        if (this.selectedRefinerItems.length < this.refinerItems.length && this.selectedRefinerItems.length != 0) {
            this.defaultCheckboxStyle = 'refiner-checkbox-moderate';
        }
        else if (this.selectedRefinerItems.length >= this.refinerItems.length && this.selectedRefinerItems.length != 0) {
            this.defaultCheckboxStyle = 'refiner-checkbox-on';
        }
        else {
            this.defaultCheckboxStyle = 'refiner-checkbox-off';
        }
    };
    RefinerComponent.prototype.removeByAttr = function (arr, attr, value) {
        var i = arr.length;
        while (i--) {
            if (arr[i]
                && arr[i].hasOwnProperty(attr)
                && (arguments.length > 2 && arr[i][attr] === value)) {
                arr.splice(i, 1);
            }
        }
        return arr;
    };
    RefinerComponent.prototype.toggleCheckbox = function () {
        if (this.selectedRefinerItems.length == 0 || this.defaultCheckboxStyle == 'refiner-checkbox-moderate') {
            this.selectAll();
            this.defaultCheckboxStyle = 'refiner-checkbox-on';
        }
        else if (this.selectedRefinerItems.length == this.refinerItems.length) {
            this.selectNone();
            this.defaultCheckboxStyle = 'refiner-checkbox-off';
        }
    };
    RefinerComponent.prototype.selectAll = function () {
        for (var i = 0; i < this.refinerItems.length; i++) {
            this.refinerItems[i].CSSClass = 'refiner-checkbox-on';
        }
        var checkboxes = document.getElementsByTagName('input');
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].type == 'checkbox' && checkboxes[i].className.indexOf(this.id) > -1) {
                checkboxes[i].checked = true;
            }
        }
        this.selectedRefinerItems = this.refinerItems.slice();
        this.onChangeEvent.emit(this.selectedRefinerItems);
        return false;
    };
    RefinerComponent.prototype.selectNone = function () {
        for (var i = 0; i < this.refinerItems.length; i++) {
            this.refinerItems[i].CSSClass = 'refiner-checkbox-off';
        }
        var checkboxes = document.getElementsByTagName('input');
        for (var i = 0; i < checkboxes.length; i++) {
            if (checkboxes[i].type == 'checkbox' && checkboxes[i].className.indexOf(this.id) > -1) {
                checkboxes[i].checked = false;
            }
        }
        this.selectedRefinerItems = new Array();
        this.onChangeEvent.emit(this.selectedRefinerItems);
        return false;
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], RefinerComponent.prototype, "id", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], RefinerComponent.prototype, "refinerType", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], RefinerComponent.prototype, "refinerItems", void 0);
    __decorate([
        core_1.ViewChild('turndownarrow'), 
        __metadata('design:type', core_1.ElementRef)
    ], RefinerComponent.prototype, "turndown", void 0);
    __decorate([
        core_1.ViewChild('datacontainer'), 
        __metadata('design:type', core_1.ElementRef)
    ], RefinerComponent.prototype, "datacontainer", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], RefinerComponent.prototype, "onChangeEvent", void 0);
    RefinerComponent = __decorate([
        core_1.Component({
            selector: 'refiner',
            moduleId: '',
            templateUrl: '../../../app/content/refiners/refiner.component.html',
            styleUrls: ['../../../app/content/refiners/refiner.component.css'],
            animations: [
                core_1.trigger('shrinkOut', [
                    core_1.state('in', core_1.style({ height: '*' })),
                    core_1.transition('* => void', [
                        core_1.style({ height: '*' }),
                        core_1.animate(250, core_1.style({ height: 0 }))
                    ])
                ])
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], RefinerComponent);
    return RefinerComponent;
}());
exports.RefinerComponent = RefinerComponent;
//# sourceMappingURL=refiner.component.js.map