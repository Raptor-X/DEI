﻿/*  System Imports  */
import { Component, Input, Output, EventEmitter, ElementRef, NgModule, trigger, state, style, animate, transition, OnInit, OnDestroy } from '@angular/core';
import {Observable} from 'rxjs/Observable';
import 'rxjs/add/observable/fromEvent';
import 'rxjs/add/operator/delay';
import 'rxjs/add/operator/do';

export class DropdownValue {
    value: string;
    label: string;

    constructor(value: string, label: string) {
        this.value = value;
        this.label = label;
    }
}

@Component({
    moduleId: '',
    host: {
        '(document:click)': 'handleClick($event)',
    },
    selector: 'dropdown',
    template: `
    <div (click)="openDropDown()" class="selected-box">{{selectedValue.label}}</div>
    <div [@heroState]="state" *ngIf="values">
          <div *ngFor="let value of values" (click)="selectItem(value)">{{value.label}}</div>
    </div>
    `,
    styles: [`
/* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.selected-box {
  margin: 0 0 10px 0;
  padding: 1px 0 0 0;
  font-weight: bold;
  width: inherit;
  min-width: 28px;
  overflow: hidden;
  background-image: url("../../../images/dropdown_chevron.svg");
  background-repeat: no-repeat;
  background-position: 90% 8px;
  background-size: 9px 6px;
  background-color: transparent;
  vertical-align: text-bottom;
  position: relative;
  top: 4.5px; }

div {
  margin: 0;
  padding: 0;
  width: 100%;
  vertical-align: text-top;
  float: left;
  cursor: pointer;
  font-size: .95em;
  /*background-color: transparent;
    background-image: url("../../../images/dropdown_chevron.svg");
    background-repeat: no-repeat;
    background-position: 90% 12px;
    background-size: 9px 6px;
    background-color: red;*/ }
  div :hover {
    background-color: #e4ebf5; }
  div div {
    width: 100%;
    margin: 0 0 0 0;
    padding: 7px 0 5px 5px;
    /*background-color: blue;*/
    /*background-image: none;*/
    /*background-color: transparent;
        background: url("../../../images/dropdown_chevron.svg") no-repeat;
        background-position: 95% 12px;
        background-size: 9px 6px;*/ }
    
    `],
    animations: [
        trigger('heroState', [
            state('inactive', style({
                width: '100%',
                display: 'none',
                overflow: 'hidden',
                
                backgroundPosition: '90% 12px',
                backgroundSize: '9px 6px',
                backgroundColor: '#fff'
            })),
            state('active', style({
                width: '100%',
                overflow: 'visible',
                
                backgroundPosition: '90% 12px',
                backgroundSize: '9px 6px',
                backgroundColor: '#fff',
                boxShadow: '0 0 5px 3px #ddd' 
            })),
            transition('inactive => active', animate('100ms ease-in')),
            transition('active => inactive', animate('100ms ease-out'))
        ])
    ]
})

export class DropdownComponent implements OnInit {
    state: string = "inactive";
    @Input()
    values: DropdownValue[];

    @Input() type: string;
    @Output()
    select: any;
    @Input() selectedValue:any;
    elementRef:ElementRef;
 
    constructor(myElement: ElementRef) {
        this.elementRef = myElement;
       this.select = new EventEmitter();
    }

    selectItem(value: any, isTopLevel:boolean) {
        this.state = (this.state === 'inactive' ? 'active' : 'inactive');
        this.selectedValue = value;
        this.select.emit(value);
        
    }
    openDropDown() {
        this.state = (this.state === 'inactive' ? 'active' : 'inactive');
    }    
    handleClick(event:Event){
       var clickedComponent:any = event.target;
       var inside = false;
       do {
           if (clickedComponent === this.elementRef.nativeElement) {
               inside = true;
           }
           clickedComponent = clickedComponent.parentNode;
       } while (clickedComponent);
       if(inside){
           console.log('inside');
       }else{
           console.log('clicked outside');
            this.state = 'inactive';
       }
    }

    ngOnInit() {

        if (!this.selectedValue) {
            this.selectedValue = this.values[0];
        }
    }

}