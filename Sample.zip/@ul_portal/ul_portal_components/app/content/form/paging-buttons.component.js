"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
var PagingButtonsComponent = (function () {
    function PagingButtonsComponent() {
        this.pageTitle = '';
        this.onLeftPage = new core_1.EventEmitter();
        this.onRightPage = new core_1.EventEmitter();
    }
    PagingButtonsComponent.prototype.ngOnInit = function () {
    };
    PagingButtonsComponent.prototype.onLeftPageEvent = function (data) {
        this.onLeftPage.emit(data);
    };
    PagingButtonsComponent.prototype.onRightPageEvent = function (data) {
        this.onRightPage.emit(data);
    };
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], PagingButtonsComponent.prototype, "onLeftPage", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], PagingButtonsComponent.prototype, "onRightPage", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], PagingButtonsComponent.prototype, "pages", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], PagingButtonsComponent.prototype, "selectedPage", void 0);
    PagingButtonsComponent = __decorate([
        core_1.Component({
            moduleId: '',
            selector: 'paging-buttons',
            template: "\n<section class=\"paging-buttons-component\">\n    <div class=\"paging-buttons-container\">\n        <button [disabled]=\"selectedPage.label == 1\" type=\"button\" class=\"paging-button paging-button-left\"\n                 (click)=\"onLeftPageEvent('PREVIOUS')\">\n            <span class=\"glyphicon glyphicon-triangle glyphicon-triangle-left\">\n            </span>\n        </button>\n        <button [disabled]=\"pages.length == selectedPage.label\" type=\"button\" class=\"paging-button paging-button-right\"\n                 (click)=\"onRightPageEvent('NEXT')\">\n            <span class=\"glyphicon glyphicon-triangle glyphicon-triangle-right\"></span>\n        </button>\n    </div>\n</section>    \n    ",
            styles: ["\n    /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.paging-buttons-component {\n  float: right;\n  width: 100%;\n  height: 100%; }\n  .paging-buttons-component .paging-buttons-container {\n    width: 100%;\n    height: 100%; }\n    .paging-buttons-component .paging-buttons-container button {\n      background-color: #fff; }\n    .paging-buttons-component .paging-buttons-container button:disabled span {\n      opacity: 0.5; }\n    .paging-buttons-component .paging-buttons-container button:disabled {\n      cursor: not-allowed; }\n    .paging-buttons-component .paging-buttons-container .paging-button {\n      /*padding: 7px 12px 10px 10px;*/\n      width: 50%;\n      height: 100%;\n      float: left;\n      border-right: solid 1px #cbcdd1; }\n    .paging-buttons-component .paging-buttons-container .paging-button-left {\n      /*margin-left: 0;\n            border-top-right-radius: 0;\n            border-bottom-right-radius: 0;*/ }\n      .paging-buttons-component .paging-buttons-container .paging-button-left span {\n        padding-top: 0px;\n        padding-right: 0px;\n        padding-bottom: 0px;\n        border-top-width: 3px; }\n    .paging-buttons-component .paging-buttons-container .paging-button-right {\n      /*margin-left: -5px;\n            border-top-left-radius: 0;\n            border-bottom-left-radius: 0;*/\n      border-right: solid 0 transparent; }\n      .paging-buttons-component .paging-buttons-container .paging-button-right span {\n        padding-top: 0;\n        padding-left: 4px;\n        border-top-width: 5px;\n        border-bottom-width: 5px; }\n\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], PagingButtonsComponent);
    return PagingButtonsComponent;
}());
exports.PagingButtonsComponent = PagingButtonsComponent;
//# sourceMappingURL=paging-buttons.component.js.map