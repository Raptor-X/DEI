﻿/*  System Imports  */
import { Component, OnInit, Input } from '@angular/core';

/* Decorator */
@Component({
    selector: 'list-container',
    moduleId: '',
    template: `
<section [class]="fullWidth ? 'list-container-component-worefiner' : 'list-container-component'">

    <!--determines where the content actually goes.-->
    <ng-content></ng-content>


</section>    
    `,
    styles: [`
    .list-container-component {
  width: 83%;
  height: 100%;
  min-height: 945px;
  float: left; }

    `]
})

export class ListContainerComponent implements OnInit {
    pageTitle: string = '';
    @Input() fullWidth: boolean = false;
    ngOnInit() {

    }

}