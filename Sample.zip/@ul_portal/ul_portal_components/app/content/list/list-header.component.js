"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
var ulcomponent_component_1 = require('../../../app/content/ulcomponent.component');
/* Decorator */
var ListHeaderComponent = (function (_super) {
    __extends(ListHeaderComponent, _super);
    function ListHeaderComponent() {
        _super.call(this);
        this.onSortHeaderEvent = new core_1.EventEmitter();
        this.headerClass = '';
    }
    ListHeaderComponent.prototype.onSortHeader = function (event, data) {
        // Adds turndown arrow up/down toggle.
        var target = event.target || event.srcElement || event.currentTarget;
        $(target).toggleClass("h6-toggle");
        var obj = new Object();
        obj.event = event;
        obj.data = data;
        this.onSortHeaderEvent.emit(obj);
    };
    ListHeaderComponent.prototype.getHeaderClass = function (index) {
        return 'header-col' + ' ' + 'header-col-' + (index + 2);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], ListHeaderComponent.prototype, "columns", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ListHeaderComponent.prototype, "onSortHeaderEvent", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], ListHeaderComponent.prototype, "headerClass", void 0);
    ListHeaderComponent = __decorate([
        core_1.Component({
            selector: 'list-header',
            moduleId: '',
            template: "\n<section class=\"list-header-component flex-container\">\n\n    <div class=\"list-header flex-container\">\n\n        <div class=\"header-col header-col-1\">\n            <div>\n                <h6></h6>\n            </div>\n        </div>\n\n        <div *ngFor=\"let column of columns; let i = index\" [class]=\"getHeaderClass(i)\">\n            <div class=\"arrow-toggle\">\n                <h6 (click)=\"onSortHeader($event, column)\">{{ column }}</h6>\n            </div>\n        </div>\n\n        <div [class]=\"'header-col' + ' ' + 'header-col-' + (columns.length+2)\">\n            <div>\n                <h6></h6>\n            </div>\n        </div>\n\n    </div>\n\n\n</section>    \n    ",
            styles: ["\n/* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.list-header-component {\n  width: 100%;\n  height: 50px;\n  background-color: #e6e9ed;\n  border: solid 1px #cbcdd1;\n  border-top: solid 0 transparent;\n  border-left: solid 0 transparent;\n  border-right: solid 0 transparent; }\n  .list-header-component .list-header {\n    /*width: 95%;*/\n    /*width: 100%;*/\n    height: 50px;\n    /*margin: 0 20px 4px 20px;*/\n    padding: 0 20px;\n    color: #9ea6ba;\n    background-color: transparent; }\n    .list-header-component .list-header .header-col {\n      height: 50px;\n      float: left;\n      border-right: solid 1px #cbcdd1;\n      color: #9ea6ba;\n      text-align: center;\n      cursor: pointer; }\n      .list-header-component .list-header .header-col div {\n        padding: 10px 0 0 0;\n        text-align: center; }\n        .list-header-component .list-header .header-col div :hover {\n          /*background: url('../../../content/images/turndown-arrow.png') 95% 50% no-repeat $myul-button-hover;*/\n          background-color: #d3d6db; }\n        .list-header-component .list-header .header-col div :active {\n          /*background: url('../../../content/images/turndown-arrow.png') 95% 50% no-repeat $myul-button-hover;*/\n          background-color: #d3d6db; }\n        .list-header-component .list-header .header-col div h6 {\n          text-transform: capitalize;\n          color: #303741;\n          width: auto;\n          display: inline-block;\n          background: url(\"../../../content/images/turndown-arrow-down.png\") 95% 50% no-repeat transparent;\n          padding: 8px 20px 8px 8px;\n          border-radius: 3px;\n          z-index: 9999; }\n        .list-header-component .list-header .header-col div .h6-toggle {\n          background: url(\"../../../content/images/turndown-arrow-up.png\") 95% 50% no-repeat #d3d6db; }\n    .list-header-component .list-header .header-col-1 {\n      display: none; }\n    .list-header-component .list-header .header-col-2 {\n      width: 55%;\n      /*padding-left: 20px;*/ }\n      .list-header-component .list-header .header-col-2 div {\n        text-align: left; }\n    .list-header-component .list-header .header-col-3 {\n      width: 15%; }\n    .list-header-component .list-header .header-col-4 {\n      width: 15%; }\n    .list-header-component .list-header .header-col-5 {\n      width: 15%;\n      border-right: solid 0 transparent; }\n    .list-header-component .list-header .header-col-6 {\n      display: none; }\n    \n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], ListHeaderComponent);
    return ListHeaderComponent;
}(ulcomponent_component_1.ULComponent));
exports.ListHeaderComponent = ListHeaderComponent;
//# sourceMappingURL=list-header.component.js.map