"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var ListItemComponent = (function () {
    function ListItemComponent() {
        this.pageTitle = '';
        this.linkEvent = new core_1.EventEmitter();
    }
    ListItemComponent.prototype.ngAfterViewInit = function () {
    };
    ListItemComponent.prototype.getColumnClasses = function (i) {
        return ('list-item-col list-item-col-' + (i + 2));
    };
    ListItemComponent.prototype.largeValueLink = function (data) {
        console.log(data);
        this.linkEvent.emit(data);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], ListItemComponent.prototype, "borderColorClass", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], ListItemComponent.prototype, "columns", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], ListItemComponent.prototype, "fieldNames", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], ListItemComponent.prototype, "linkEvent", void 0);
    ListItemComponent = __decorate([
        core_1.Component({
            selector: 'list-item',
            moduleId: '',
            template: "\n<section class=\"list-item-component\">\n    \n    <div class=\"list-item flex-container {{borderColorClass}}\">\n\n        <div class=\"list-item-col list-item-col-1\">\n            <div>\n                <p></p>\n            </div>\n        </div>\n\n            <div *ngFor=\"let column of columns; let i=index;\" [class]=\"getColumnClasses(i)\">\n               <div *ngIf=\"column.type=='normal'\">\n                <p *ngIf=\"column.linkdata\" [routerLink]=\"column.routerlink\" (click)=\"largeValueLink(column.linkdata)\" [innerHTML] = \"column.value\"></p>\n                <p *ngIf=\"!column.linkdata\" [innerHTML] = \"column.value\"></p>\n                </div>\n\n\n\n\n                    <div *ngIf=\"column.type == 'large'\"class=\"list-item-description\">\n                        <h4 *ngIf=\"column.linkdata\" [routerLink]=\"column.routerlink\" (click)=\"largeValueLink(column.linkdata)\" [tooltipHtml]=\"column.largeValue\" [innerHTML] = \"column.largeValue\"></h4>\n                        <h4 *ngIf=\"!column.linkdata\" [tooltipHtml]=\"column.largeValue\" [innerHTML] = \"column.largeValue\"></h4>\n                        \n                    </div>\n\n                    <div *ngIf=\"column.type == 'large'\"class=\"list-item-status\">\n                        <h6 [innerHTML] = \"column.underValue\" >\n                            <span [innerHTML] = \"column.statusValue\" class=\"list-item-status-draft\"></span>\n                            <span class=\"middot\">&#183;</span>\n                            \n                        </h6>\n                    </div>\n\n\n\n            </div>\n\n           \n\n\n\n    </div>\n\n</section>    \n    ",
            styles: ["\n/* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.highlighted {\n  color: yellow; }\n\n.list-item-component {\n  /*width: 100%;*/\n  height: 100%;\n  padding: 0 25px;\n  background-color: #f0f3f7;\n  border: solid 0 transparent; }\n  .list-item-component .list-item {\n    /*width: 100%;*/\n    min-height: 95px;\n    margin: 0 0 4px -4px;\n    border: solid 1px #cbcdd1;\n    border-left: solid 4px #4a92e2;\n    color: #9ea6ba;\n    background-color: #fff; }\n    .list-item-component .list-item .list-item-col {\n      border-right: solid 1px #cbcdd1; }\n      .list-item-component .list-item .list-item-col div {\n        padding: 0;\n        text-align: center; }\n        .list-item-component .list-item .list-item-col div h4 {\n          min-height: 30px;\n          margin-right: 20px;\n          padding-bottom: 5px;\n          cursor: pointer !important; }\n          .list-item-component .list-item .list-item-col div h4:hover {\n            color: #23527c;\n            text-decoration: underline !important; }\n        .list-item-component .list-item .list-item-col div h6 {\n          text-transform: capitalize;\n          color: #303741;\n          padding: 0 20px 12px 0;\n          border-top: solid 1px #cbcdd1; }\n        .list-item-component .list-item .list-item-col div p {\n          text-transform: capitalize;\n          color: #303741;\n          margin-top: 38px;\n          text-align: center; }\n    .list-item-component .list-item .list-item-col-1 {\n      display: none; }\n    .list-item-component .list-item .list-item-col-2 {\n      width: 55%;\n      /*padding: 15px 0 0 20px;*/ }\n      .list-item-component .list-item .list-item-col-2 div {\n        text-align: left;\n        padding-left: 20px; }\n      .list-item-component .list-item .list-item-col-2 .list-item-description {\n        padding-top: 18px; }\n      .list-item-component .list-item .list-item-col-2 .list-item-status {\n        padding-top: 0; }\n        .list-item-component .list-item .list-item-col-2 .list-item-status h6 {\n          padding-top: 10px;\n          color: #98a8bc; }\n    .list-item-component .list-item .list-item-col-3 {\n      width: 15%; }\n    .list-item-component .list-item .list-item-col-4 {\n      width: 15%; }\n      .list-item-component .list-item .list-item-col-4 div p {\n        color: #337ab7;\n        cursor: pointer; }\n        .list-item-component .list-item .list-item-col-4 div p:hover {\n          text-decoration: underline; }\n    .list-item-component .list-item .list-item-col-5 {\n      width: 15%;\n      border-right: solid 0 #cbcdd1; }\n    .list-item-component .list-item .list-item-col-6 {\n      display: none; }\n    .list-item-component .list-item .highlighted {\n      background-color: yellow; }\n    \n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], ListItemComponent);
    return ListItemComponent;
}());
exports.ListItemComponent = ListItemComponent;
//# sourceMappingURL=list-item.component.js.map