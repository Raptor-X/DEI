import { NgModule } from '@angular/core';
import { RouterModule} from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';


// import { ProductDetailGuard } from './product-guard.service';
import { HeaderComponent} from '../../app/header/header.component';
//import { HeaderComponent} from 'ul_portal_components/components/header/header.component';

import { ErrorHandlerModule } from '../Error/error.module';
//import { ComponentsModule } from 'ul_portal_components/components/components.module';
import { ContentComponent} from '../../app/content/content.component';
import { GenericListComponent } from '../content/generic-list.component';
import { RefinerContainerComponent } from '../content/refiners/refiner-container.component';
import { RefinerComponent } from '../content/refiners/refiner.component';
import { SearchComponent } from '../content/search/search.component'; 
import { ListContainerComponent } from '../content/list/list-container.component';
import { ListHeaderComponent } from '../content/list/list-header.component';
import { ListItemContainerComponent } from '../content/list/list-item-container.component';
import { ListItemComponent } from '../content/list/list-item.component'; 
import { GenericDetailComponent } from '../content/generic-detail.component';
import { SubheaderComponent } from '../content/detail/subheader.component';
import { DetailsComponent } from '../content/detail/detail.component';
import { TabsComponent } from '../content/detail/tabs.component';
import { DetailListViewContainerComponent } from '../content/detail/detail-listview-container.component';
import { DetailListViewHeaderComponent } from '../content/detail/detail-listview-header.component';
import { DetailTabViewPeopleComponent } from '../content/detail/detail-tabview-people.component';
import { DetailListItemComponent } from '../content/detail/detail-list-item.component';
import { DropdownComponent} from '../content/form/dropdown.component';
import { PagingButtonsComponent } from '../content/form/paging-buttons.component';
import { AppConfigService} from '../services/appconfigservice.service';
import { DataService} from '../services/dataservice.service';
import { SingleRefinerComponent } from '../content/refiners/single-refiner.component';
import { MyDatePickerModule } from 'mydatepicker/dist/my-date-picker.module';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { LoadingSpinnerComponent } from '../misc/loading-spinner.component';
import { TooltipModule } from '../content/tooltip/tooltip.module';

@NgModule({  imports: [
    CommonModule,
    FormsModule,
    ErrorHandlerModule,
	MyDatePickerModule,
	ChartsModule,
	TooltipModule,
	RouterModule
  ],
  declarations: [
    HeaderComponent, 
    ContentComponent,
    GenericListComponent,
    RefinerContainerComponent,
    RefinerComponent,
    SearchComponent,
    ListContainerComponent,
    ListHeaderComponent,
    ListItemContainerComponent,
    ListItemComponent,
    GenericDetailComponent,
    SubheaderComponent,
    DetailsComponent,
    TabsComponent,
    DetailListViewContainerComponent,
    DetailListViewHeaderComponent,
    DetailListItemComponent,
    DropdownComponent,
    PagingButtonsComponent,
	DetailTabViewPeopleComponent,
	SingleRefinerComponent,
  LoadingSpinnerComponent
	
  ],
  exports: [
    HeaderComponent, 
    ContentComponent,
    GenericListComponent,
    RefinerContainerComponent,
    RefinerComponent,
    SearchComponent,
    ListContainerComponent,
    ListHeaderComponent,
    ListItemContainerComponent,
    ListItemComponent,
    GenericDetailComponent,
    SubheaderComponent,
    DetailsComponent,
    TabsComponent,
    DetailListViewContainerComponent,
    DetailListViewHeaderComponent,
    DetailListItemComponent,
    DropdownComponent,
    PagingButtonsComponent,
    DetailTabViewPeopleComponent,
	SingleRefinerComponent,
  LoadingSpinnerComponent
  ]
})
export class ComponentsModule {}
