"use strict";
var ULComponent = (function () {
    function ULComponent() {
    }
    return ULComponent;
}());
exports.ULComponent = ULComponent;
//# sourceMappingURL=ulcomponent.component.js.map