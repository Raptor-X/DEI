"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var core_2 = require("angular2-logger/core");
var appconfigservice_service_1 = require('../services/appconfigservice.service');
var dataservice_service_1 = require('../services/dataservice.service');
/*  Decorator  */
var GenericDetailComponent = (function () {
    /*  Functions  */
    function GenericDetailComponent(_route, _logger, _appConfigService, _dataService) {
        this._route = _route;
        this._logger = _logger;
        this._appConfigService = _appConfigService;
        this._dataService = _dataService;
        this.pageTitle = '';
        this.imageWidth = 50;
        this.imageMargin = 2;
        this.showMoreCompany = false;
        this.selectAllcompay = false;
        this.showMorePlaceholder = 0;
        //totalPageCount = { count: 0 };
        this.companyNameList = [];
        this.contactNameCount = 0;
        this.totalCount = 0;
        this.statusFilterList = [];
        this.nameFilterCount = [];
        this.statusFilterCount = [];
        this.statusCount = 0;
        this.changeGlyph = false;
        this.chkStatusList = [];
        this.chkStatusList1 = [];
        this.statusSlelectAll = [];
        /* checkbox company name */
        this.companyNameListFilter = [];
        this.chkNameListTemp = [];
        this.chkNameList = [];
        this.visibleMore = false;
        this.dateFilterOptions = [
            'Today',
            'Last 7 Days',
            'Last 30 Days',
            'Last 90 Days',
            'Last 365 Days',
            'Date Range'
        ];
        /* deep link url */
        this.parentURL = "";
        //statusFilter: string[] = [
        //    "Draft",
        //    "Offered",
        //    "Accepted",
        //    "Expired",
        //    "ORDER SUBMITTED"      
        //];
        this.columSortOptions = ["Description", "Creation Date", "Quote Number", "Price"];
        /*  PBI - 2261 Quote List - Date filter*/
        this.myDatePickerOptions = {
            todayBtnTxt: 'Today',
            dateFormat: 'mm/dd/yyyy',
            firstDayOfWeek: 'mo',
            sunHighlight: true,
            inline: false,
            selectionTxtFontSize: '12px',
            componentDisabled: true,
            editableDateField: false
        };
        this.totalItems = 0;
        this.currentPage = 1;
        this.itemsPerPage = 15;
        this.startIndex = 0;
        this.endIndex = 0;
        this.totalPages = 1;
        this.pagesArr = [];
        this.maxSize = 0;
        this.enableFwdBtn = false;
        this.enableBackBtn = false;
        /* Date text box Empty */
        this.textFromDate = new core_1.ElementRef({ selectionDayTxt: "" });
        this.textToDate = new core_1.ElementRef({ selectionDayTxt: "" });
        this.dateRangeCheck = false;
        /*Select All Atatus */
        this.checkAllSwitch = false;
        /* Select All Company */
        this.nameSelectAll = [];
        this.chkNameAll = false;
    }
    GenericDetailComponent.prototype.onFiltered = function (Count) {
        this.totalCount = Count;
        // this.totalPages = (this.totalItems / this.itemsPerPage);
    };
    GenericDetailComponent.prototype.filterSelected = function () {
        this.totalCount = 7;
    };
    GenericDetailComponent.prototype.Configuration = function () {
    };
    GenericDetailComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.sub = this._route.params.subscribe(function (params) {
            var id = +params['id'];
            _this.detailFields = _this._appConfigService.getDetailFields();
            _this.subHeaderFields = _this._appConfigService.getSubHeaderFields();
            _this._dataService.getDetailDataObject(id)
                .subscribe(function (data) {
                _this.dataObject = data;
                _this.setSubHeaderFields();
            }, function (error) { return _this.errorMessage = error; });
        });
    };
    GenericDetailComponent.prototype.setSubHeaderFields = function () {
        this.subHeaderStatusFieldName = this._appConfigService.getSubHeaderStatusFieldName();
        this.subHeaderStatusValue = this.dataObject[0][this._appConfigService.getSubHeaderStatusFieldName()];
        this.subHeaderStatusDescription = this.dataObject[0][this._appConfigService.getSubHeaderDescriptionFieldName()];
        this.subHeaderStatusFieldLabel = this._appConfigService.getSubHeaderStatusFieldLabel();
    };
    /* PAGINATION   */
    GenericDetailComponent.prototype.setPaginationProperties = function (filterCount) {
        this.setPageValues(filterCount);
        this.setPageIndexes();
        this.setNavigationBtn();
    };
    GenericDetailComponent.prototype.setPageValues = function (filterCount) {
        this.totalItems = (filterCount == undefined ? this.totalCount : filterCount);
        this.totalPages = Math.ceil(this.totalItems / this.itemsPerPage);
        this.pagesArr = [];
        for (var num = 1; num <= this.totalPages; num++) {
            this.pagesArr.push(num);
        }
    };
    GenericDetailComponent.prototype.setPageIndexes = function () {
        this.startIndex = (this.currentPage - 1) * this.itemsPerPage;
        var tempEndindex = this.startIndex + this.itemsPerPage;
        this.endIndex = (tempEndindex) > this.totalItems ? this.totalItems : tempEndindex;
    };
    GenericDetailComponent.prototype.filterPageChange = function (pageNo, filterCount) {
        this.currentPage = pageNo;
        this.setPaginationProperties(filterCount);
    };
    ;
    GenericDetailComponent.prototype.pageNavigationBtnClick = function (changeType) {
        var _currentPage = this.currentPage;
        if (changeType == "NEXT") {
            _currentPage = Number(_currentPage.toString()) + 1;
            _currentPage = _currentPage < this.totalPages ? _currentPage : this.totalPages;
        }
        else if (changeType == "PREVIOUS") {
            _currentPage = _currentPage - 1 > 1 ? _currentPage - 1 : 1;
        }
        this.currentPage = _currentPage;
        this.setPageIndexes();
        this.setNavigationBtn();
    };
    GenericDetailComponent.prototype.setPage = function (pageNo) {
        this.currentPage = pageNo;
        this.setPageIndexes();
        this.setNavigationBtn();
    };
    GenericDetailComponent.prototype.setNavigationBtn = function () {
        this.enableFwdBtn = this.currentPage > 1 ? true : false;
        this.enableBackBtn = (this.totalPages > 0 && this.currentPage < this.totalPages) ? true : false;
    };
    GenericDetailComponent.prototype.trigger = function () {
        this._logger.info('trigger');
        this.filterCountEl.nativeElement.focus();
    };
    /*End */
    GenericDetailComponent.prototype.OnDateRangeFilterSelection = function (value) {
        var copy = this.getCopyOfOptions();
        if (value == "Today" || value == "Last 7 Days" || value == "Last 30 Days" || value == "Last 90 Days" || value == "Last 365 Days")
            this.dateRangeCheck = false;
        if (value == "Date Range") {
            this.dateRangeCheck = true;
            this.from = undefined;
            this.customtodate = undefined;
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
        }
        /* Date text box Empty */
        if (this.dateRangeCheck == true) {
            copy.componentDisabled = false;
            this.myDatePickerOptions = copy;
        }
        else {
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textToDate.selectionDayTxt = "";
            copy.componentDisabled = true;
            this.myDatePickerOptions = copy;
        }
        this.triggerFocus();
        /* End  */
    };
    GenericDetailComponent.prototype.checkAllStatus = function () {
        this.checkAllSwitch = !this.checkAllSwitch;
        this.statusSlelectAll = [];
        for (var i = 0; i < this.statusFilterList.length; i++) {
            this.statusSlelectAll.push(this.statusFilterList[i].toLowerCase());
        }
        this.chkStatusList1 = this.statusSlelectAll;
        this.chkStatusList = this.chkStatusList1;
        this.triggerFocus();
    };
    GenericDetailComponent.prototype.selectAllCompay = function () {
        this.chkNameAll = !this.chkNameAll;
        this.nameSelectAll = [];
        for (var i = 0; i < this.companyNameList.length; i++) {
            this.nameSelectAll.push(this.companyNameList[i].toLowerCase());
        }
        this.chkNameListTemp = this.nameSelectAll;
        this.chkNameList = this.chkNameListTemp;
        this.triggerFocus();
    };
    /* Status Filter Checkbox */
    GenericDetailComponent.prototype.statusChecked = function (checked, value) {
        if (checked == true) {
            this.chkStatusList.push(value.toLowerCase());
            this.chkStatusList1 = this.chkStatusList;
        }
        else {
            for (var i = 0; i < this.chkStatusList.length; i++) {
                if (this.chkStatusList[i] == value.toLowerCase()) {
                    this.chkStatusList.splice(i, 1);
                }
            }
            this.chkStatusList1 = this.chkStatusList;
        }
        this.triggerFocus();
    };
    /*Company Name Filtered Checkbox */
    GenericDetailComponent.prototype.companyNameChecked = function (checked, name) {
        if (checked == true) {
            this.chkNameList.push(name.toLowerCase());
            this.chkNameListTemp = this.chkNameList;
        }
        else {
            for (var i = 0; i < this.chkNameList.length; i++) {
                if (this.chkNameList[i] == name.toLowerCase()) {
                    this.chkNameList.splice(i, 1);
                }
            }
            this.chkNameListTemp = this.chkNameList;
        }
        this.triggerFocus();
    };
    GenericDetailComponent.prototype.filterList = function () {
        for (var i = 0; i < this.quotes.length; i++) {
            /*get the Distinct Company name */
            if (this.companyNameList.indexOf(this.quotes[i].CompanyName) === -1) {
                this.companyNameList.push(this.quotes[i].CompanyName);
                this.chkNameList.push(this.quotes[i].CompanyName.toLowerCase());
                this.chkNameListTemp = this.chkNameList;
            }
            /* get the Distinct Status Name */
            if (this.statusFilterList.indexOf(this.quotes[i].QuoteStatus) === -1) {
                this.statusFilterList.push(this.quotes[i].QuoteStatus);
                this.chkStatusList.push(this.quotes[i].QuoteStatus.toLowerCase());
                this.chkStatusList1 = this.chkStatusList;
            }
        }
        if (this.companyNameList !== null && this.companyNameList.length > 5) {
            this.companyClass = "companyContainer";
            this.visibleMore = true;
        }
        /* count for Status */
        for (var l = 0; l < this.statusFilterList.length; l++) {
            this.statusCount = 0;
            var displayText = void 0;
            var displayCode = void 0;
            for (var m = 0; m < this.quotes.length; m++) {
                if (this.statusFilterList[l] == this.quotes[m].QuoteStatus) {
                    this.statusCount = this.statusCount + 1;
                    this.status = this.quotes[m].QuoteStatus;
                    displayText = this.quotes[m].QuoteStatus;
                }
            }
            /* Assigning the status display code based on the status */
            if (displayText == "Draft") {
                displayCode = 0;
            }
            else if (displayText == "Offered") {
                displayCode = 1;
            }
            else if (displayText == "Accepted") {
                displayCode = 2;
            }
            else {
                displayCode = 3;
            }
            this.statusFilterCount.push({ "Name": this.status, "displayText": displayText, "QuotesStatusCode": displayCode, "Count": this.statusCount });
            /* sorting the status based on the display status code */
            this.statusFilterCount.sort(function (a, b) {
                return a.QuotesStatusCode - b.QuotesStatusCode;
            });
        }
        /* count for customer Name */
        for (var j = 0; j < this.companyNameList.length; j++) {
            this.contactNameCount = 0;
            for (var k = 0; k < this.quotes.length; k++) {
                if (this.companyNameList[j] == this.quotes[k].CompanyName) {
                    this.contactNameCount = this.contactNameCount + 1;
                    this.name = this.quotes[k].CompanyName;
                }
            }
            this.nameFilterCount.push({ "Name": this.name, "Count": this.contactNameCount });
        }
    };
    //Custom Date Filter- 2261/2387 
    GenericDetailComponent.prototype.onFromDateChanged = function (event) {
        this.from = new Date(event.formatted);
        //Added 'FROM' text as typeOfdateSelection flag to show 'FROM' label when date validation fails
        this.dateRangValidation('FROM');
        this.triggerFocus();
    };
    GenericDetailComponent.prototype.onToDateChanged = function (event) {
        this.customtodate = new Date(event.formatted);
        //Added 'TO' text as typeOfdateSelection flag to show 'TO' label when date validation fails
        this.dateRangValidation('TO');
        this.triggerFocus();
    };
    //Added method Show From/To text when user selected date fails validation
    GenericDetailComponent.prototype.OnDateValidationFails = function (typeOfDate) {
        if (typeOfDate === 'FROM') {
            /* Empty Custom date textbox */
            this.textFromDate = this.dateFrom;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.from = undefined;
        }
        else if (typeOfDate === 'TO') {
            /* Empty Custom date textbox */
            this.textToDate = this.dateTo;
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.customtodate = undefined;
        }
    };
    //Validation for Date Filter
    GenericDetailComponent.prototype.dateRangValidation = function (typeOfDate) {
        var currentDate = new Date();
        var ToDate = new Date(this.customtodate);
        var fromDate = new Date(this.from);
        if (fromDate > ToDate) {
            alert('From Date should be less than or equal to To Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (ToDate < fromDate) {
            alert('To Date should be greater than or equal to From Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < fromDate) {
            alert('From Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < ToDate) {
            alert('To Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
    };
    // PBI- 2638 Column Sorting 
    GenericDetailComponent.prototype.changeSorting = function (value, selectedOption) {
        this.columnSort = value;
        this.columnSortOptionsValue = selectedOption;
    };
    // PBI- 2569 Dropdown Sorting
    GenericDetailComponent.prototype.changeSelect = function (selectedOption) {
        this.selectedSortOption.sortOptionName = selectedOption;
        this.columnSortOptionsValue = null;
        this.filterPageChange(1, this.filterCountEl.nativeElement.value);
    };
    //Change background color on div click
    GenericDetailComponent.prototype.toggleHighlight = function (newValue) {
        if (this.highlightedDiv === newValue) {
            this.highlightedDiv = 4;
            this.changeSorting('DES', this.columSortOptions[newValue]);
        }
        else {
            this.highlightedDiv = newValue;
            this.changeSorting('ASC', this.columSortOptions[newValue]);
        }
    };
    //ToolTip State Change//
    GenericDetailComponent.prototype.tooltipStateChanged = function (state) {
        this._logger.info("Tooltip is open: " + state);
    };
    /*Enable diseabled date */
    GenericDetailComponent.prototype.getCopyOfOptions = function () {
        return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    };
    /*Page reset on the event trigger*/
    GenericDetailComponent.prototype.triggerFocus = function () {
        var _this = this;
        setTimeout(function () { return _this.filterCountEl.nativeElement.focus(); }, 5);
    };
    /*Deep Linking order  */
    GenericDetailComponent.prototype.deepLinkURL = function (orderNo, psn) {
        var details = "URL/Orders/OrderDetail/" + orderNo + "-" + psn;
        parent.postMessage(details, this.parentURL);
    };
    GenericDetailComponent.prototype.quoteLinkURL = function (quote) {
        var quotes = "Internal/Quotes/QuotesDetail/" + quote;
        parent.postMessage(quotes, this.parentURL);
    };
    __decorate([
        core_1.ViewChild('filterCount'), 
        __metadata('design:type', core_1.ElementRef)
    ], GenericDetailComponent.prototype, "filterCountEl", void 0);
    __decorate([
        core_1.ViewChild('PageEl'), 
        __metadata('design:type', core_1.ElementRef)
    ], GenericDetailComponent.prototype, "PageElemt", void 0);
    __decorate([
        core_1.ViewChild('fromDate'), 
        __metadata('design:type', core_1.ElementRef)
    ], GenericDetailComponent.prototype, "dateFrom", void 0);
    __decorate([
        core_1.ViewChild('toDate'), 
        __metadata('design:type', core_1.ElementRef)
    ], GenericDetailComponent.prototype, "dateTo", void 0);
    GenericDetailComponent = __decorate([
        core_1.Component({
            moduleId: '',
            template: "\n\n\n    <header [headerTitle]=\"headerTitle\"></header>\n\n    <subheader [subHeaderStatusFieldLabel]=\"subHeaderStatusFieldLabel\" [subHeaderStatusFieldName]=\"subHeaderStatusFieldName\" [subHeaderStatusValue]=\"subHeaderStatusValue\" [subHeaderStatusDescription]=\"subHeaderStatusDescription\"></subheader>\n    <detail [detailFields]=\"detailFields\" [detailDataObject]=\"dataObject\"></detail>\n    <detail-listview-container>\n        <tabs></tabs>\n        <search></search>\n            <detail-listview-header></detail-listview-header>\n            <detail-list-item></detail-list-item>\n    </detail-listview-container>\n    \n    ",
        }), 
        __metadata('design:paramtypes', [router_1.ActivatedRoute, core_2.Logger, appconfigservice_service_1.AppConfigService, dataservice_service_1.DataService])
    ], GenericDetailComponent);
    return GenericDetailComponent;
}());
exports.GenericDetailComponent = GenericDetailComponent;
//# sourceMappingURL=generic-detail.component.js.map