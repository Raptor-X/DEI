import { Component, OnInit, ViewChild, ViewChildren, ElementRef } from '@angular/core';

export class ULComponent {
	
}