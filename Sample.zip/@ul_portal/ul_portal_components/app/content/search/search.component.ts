﻿/*  System Imports  */
import { Component, EventEmitter, Output, Input, OnInit } from '@angular/core';
import { DropdownComponent } from '../form/dropdown.component';
import { PagingButtonsComponent } from '../form/paging-buttons.component';


/* Decorator */
@Component({
    selector: 'search',
    moduleId: '',
    template: `

<section [class]="'search-component flex-container'">

    <div class="search flex-container">

        <div  [class]="'search-col' + showRefiners ? ' search-col search-col-1' : ''">
            <button *ngIf="showRefiners" type="button" class="refine-button refineButton"
                 (click)="toggleRefiners($event)">Refine
            </button>
        </div>
        <div  [class]="'search-col' + showSearch ? ' search-col search-col-2' : ''">
            <div *ngIf="showSearch" class="search-box-container">
                <input (keyup)="search()" class="input-value" type="text" placeholder="Search Within" [(ngModel)]="searchValue" />
            </div>
        </div>

        <div  [class]="'search-col' + showSort ? 'search-col search-col-3' : ''">
            <div *ngIf="showSort" class="search-col-container-sort">
                <div class="search-col-sort">
                    <h6>Sort:</h6>
                </div>
                <div class="search-col-sort-dropdown">
                    <dropdown [type]="sort" [values]="sortValues" (select)="onSort($event)"></dropdown>
                </div>
            </div>
        </div>

        <div class="search-col search-col-4">
            <div>
                <p>{{resultCount}} Results</p>
            </div>
        </div>

        <div class="search-col search-col-5">
            <div class="search-col-container-page">
                <div class="search-col-page">
                    <h6>Page:</h6>
                </div>
                <div class="search-col-page-dropdown">
                    <dropdown [type]="page" [values]="pages" (select)="onPage($event)" [selectedValue]="selectedPage"></dropdown>
                </div>
            </div>
        </div>

        <div class="search-col search-col-6">
            <paging-buttons *ngIf="selectedPage" [selectedPage]="selectedPage" [pages]="pages" (onLeftPage)="onLeftPage($event)" (onRightPage)="onRightPage($event)" ></paging-buttons>
        </div>
    </div>

</section>    
    
    `,
    styles: [`
    /* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }


.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.highlighted {
  background-color: yellow !important; }

.search-component {
  width: 100%;
  /*height: 60px;*/
  background-color: #fff;
  border: solid 1px #cbcdd1;
  border-top: solid 0 transparent;
  border-left: solid 0 transparent;
  border-right: solid 0 transparent; }
  .search-component .search {
    color: #9ea6ba;
    background-color: transparent;
    /*box-shadow: 0 10px 0px 0 $black;*/ }
    .search-component .search .search-col {
      /*height: 60px;*/
      /*float: left;*/
      border-right: solid 1px #cbcdd1;
      color: #98a8bc; }
      .search-component .search .search-col div {
        padding: 16px 0 0 25px;
        text-align: left;
        background-color: #fff; }
        .search-component .search .search-col div h5 {
          font-size: 1.0em;
          font-weight: normal; }
        .search-component .search .search-col div h6 {
          font-size: .9em;
          font-weight: normal;
          text-transform: capitalize;
          margin-top: 1px; }
        .search-component .search .search-col div p {
          margin-top: 1px;
          color: #303741;
          font-size: .95em; }
      .search-component .search .search-col .search-col-container-sort {
        padding: 0;
        /*background: url("../../../images/dropdown_chevron.svg") no-repeat;
                background-position: 95% 12px;
                background-size: 9px 6px;
                background-color: $white;*/ }
        .search-component .search .search-col .search-col-container-sort .search-col-sort {
          width: 20%;
          padding: 0;
          float: left; }
          .search-component .search .search-col .search-col-container-sort .search-col-sort h6 {
            margin: 17px 5px 15px 15px; }
        .search-component .search .search-col .search-col-container-sort .search-col-sort-dropdown {
          width: 80%;
          position: relative;
          padding: 0;
          float: left; }
          .search-component .search .search-col .search-col-container-sort .search-col-sort-dropdown dropdown {
            width: 100%;
            position: absolute;
            padding-top: 11px; }
      .search-component .search .search-col .search-col-container-page {
        padding: 0;
        /*width: 100%;*/ }
        .search-component .search .search-col .search-col-container-page .search-col-page {
          width: 60%;
          padding: 0;
          float: left; }
          .search-component .search .search-col .search-col-container-page .search-col-page h6 {
            margin: 18px 10px; }
        .search-component .search .search-col .search-col-container-page .search-col-page-dropdown {
          width: 40%;
          position: relative;
          padding: 0;
          float: right; }
          .search-component .search .search-col .search-col-container-page .search-col-page-dropdown dropdown {
            width: auto;
            position: absolute;
            /*left: -5px;*/
            padding-top: 11px;
            text-align: left; }
      .search-component .search .search-col .search-box-container input {
        font-size: .95em;
        background: url("../../../app/content/images/mag-glass.png") 95% 50% no-repeat;
        /*margin: 0 10px 0 0;*/ }
    .search-component .search .search-col-0 {
      width: 58%; }
    .search-component .search .search-col-1 {
      width: 8%;
      padding: 0;
      display: none; }
      .search-component .search .search-col-1 .refine-button {
        width: 100%;
        height: 100%;
        text-align: center;
        float: left;
        /*border-right: solid 1px #cbcdd1;*/
        background-color: white;
        color: black; }
    .search-component .search .search-col-2 {
      width: 25%; }
      .search-component .search .search-col-2 div {
        padding: 0; }
    .search-component .search .search-col-3 {
      width: 32%; }
    .search-component .search .search-col-4 {
      width: 15%; }
    .search-component .search .search-col-5 {
      width: 13%;
      /*border-right: solid 0 transparent;*/ }
    .search-component .search .search-col-6 {
      width: 15%;
      border-right: solid 0 transparent; }

    
    `]
})

export class SearchComponent implements OnInit {
    sort: string = "sort";
    page: string = "page";
    pageTitle: string = '';
    searchValue: string;
	leftPageDisabled:boolean;
    rightPageDisabled:boolean;
    @Input() fullWidth: boolean = false;
    @Input() showFiller:boolean = false;
	@Input() showSearch:boolean = true;
	@Input() showRefiners:boolean = true;
	@Input() showSort:boolean = true;
    @Input() selectedPage:any;
    @Input() pages:any[];
    @Input() sortValues:any[];
    @Input() resultCount:number = 0;
    @Output() onSearch = new EventEmitter<any>();
    @Output() onSortEvent = new EventEmitter<any>();
    @Output() onPageEvent = new EventEmitter<any>();
    @Output() onLeftPageEvent = new EventEmitter<any>();
    @Output() onRightPageEvent = new EventEmitter<any>();
    @Output() onRefinerToggle = new EventEmitter<any>();
    
    ngOnInit() {
        
    }

    search() {
        this.onSearch.emit(this.searchValue);
    }
    onLeftPage(data:any) {
        this.onLeftPageEvent.emit(data);
        
    }
    onRightPage(data:any){
        this.onRightPageEvent.emit(data);
        
    }
    onSort(data:any) {
        this.onSortEvent.emit(data);
    }
    onPage(data:any) {
        this.onPageEvent.emit(data);
    }
    toggleRefiners(data:any) {
        this.onRefinerToggle.emit(data);
    }
}