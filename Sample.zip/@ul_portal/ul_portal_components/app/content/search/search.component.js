"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var SearchComponent = (function () {
    function SearchComponent() {
        this.sort = "sort";
        this.page = "page";
        this.pageTitle = '';
        this.fullWidth = false;
        this.showFiller = false;
        this.showSearch = true;
        this.showRefiners = true;
        this.showSort = true;
        this.resultCount = 0;
        this.onSearch = new core_1.EventEmitter();
        this.onSortEvent = new core_1.EventEmitter();
        this.onPageEvent = new core_1.EventEmitter();
        this.onLeftPageEvent = new core_1.EventEmitter();
        this.onRightPageEvent = new core_1.EventEmitter();
        this.onRefinerToggle = new core_1.EventEmitter();
    }
    SearchComponent.prototype.ngOnInit = function () {
    };
    SearchComponent.prototype.search = function () {
        this.onSearch.emit(this.searchValue);
    };
    SearchComponent.prototype.onLeftPage = function (data) {
        this.onLeftPageEvent.emit(data);
    };
    SearchComponent.prototype.onRightPage = function (data) {
        this.onRightPageEvent.emit(data);
    };
    SearchComponent.prototype.onSort = function (data) {
        this.onSortEvent.emit(data);
    };
    SearchComponent.prototype.onPage = function (data) {
        this.onPageEvent.emit(data);
    };
    SearchComponent.prototype.toggleRefiners = function (data) {
        this.onRefinerToggle.emit(data);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], SearchComponent.prototype, "fullWidth", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], SearchComponent.prototype, "showFiller", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], SearchComponent.prototype, "showSearch", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], SearchComponent.prototype, "showRefiners", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], SearchComponent.prototype, "showSort", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], SearchComponent.prototype, "selectedPage", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], SearchComponent.prototype, "pages", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], SearchComponent.prototype, "sortValues", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Number)
    ], SearchComponent.prototype, "resultCount", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], SearchComponent.prototype, "onSearch", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], SearchComponent.prototype, "onSortEvent", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], SearchComponent.prototype, "onPageEvent", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], SearchComponent.prototype, "onLeftPageEvent", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], SearchComponent.prototype, "onRightPageEvent", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], SearchComponent.prototype, "onRefinerToggle", void 0);
    SearchComponent = __decorate([
        core_1.Component({
            selector: 'search',
            moduleId: '',
            template: "\n\n<section [class]=\"'search-component flex-container'\">\n\n    <div class=\"search flex-container\">\n\n        <div  [class]=\"'search-col' + showRefiners ? ' search-col search-col-1' : ''\">\n            <button *ngIf=\"showRefiners\" type=\"button\" class=\"refine-button refineButton\"\n                 (click)=\"toggleRefiners($event)\">Refine\n            </button>\n        </div>\n        <div  [class]=\"'search-col' + showSearch ? ' search-col search-col-2' : ''\">\n            <div *ngIf=\"showSearch\" class=\"search-box-container\">\n                <input (keyup)=\"search()\" class=\"input-value\" type=\"text\" placeholder=\"Search Within\" [(ngModel)]=\"searchValue\" />\n            </div>\n        </div>\n\n        <div  [class]=\"'search-col' + showSort ? 'search-col search-col-3' : ''\">\n            <div *ngIf=\"showSort\" class=\"search-col-container-sort\">\n                <div class=\"search-col-sort\">\n                    <h6>Sort:</h6>\n                </div>\n                <div class=\"search-col-sort-dropdown\">\n                    <dropdown [type]=\"sort\" [values]=\"sortValues\" (select)=\"onSort($event)\"></dropdown>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"search-col search-col-4\">\n            <div>\n                <p>{{resultCount}} Results</p>\n            </div>\n        </div>\n\n        <div class=\"search-col search-col-5\">\n            <div class=\"search-col-container-page\">\n                <div class=\"search-col-page\">\n                    <h6>Page:</h6>\n                </div>\n                <div class=\"search-col-page-dropdown\">\n                    <dropdown [type]=\"page\" [values]=\"pages\" (select)=\"onPage($event)\" [selectedValue]=\"selectedPage\"></dropdown>\n                </div>\n            </div>\n        </div>\n\n        <div class=\"search-col search-col-6\">\n            <paging-buttons *ngIf=\"selectedPage\" [selectedPage]=\"selectedPage\" [pages]=\"pages\" (onLeftPage)=\"onLeftPage($event)\" (onRightPage)=\"onRightPage($event)\" ></paging-buttons>\n        </div>\n    </div>\n\n</section>    \n    \n    ",
            styles: ["\n    /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.highlighted {\n  background-color: yellow !important; }\n\n.search-component {\n  width: 100%;\n  /*height: 60px;*/\n  background-color: #fff;\n  border: solid 1px #cbcdd1;\n  border-top: solid 0 transparent;\n  border-left: solid 0 transparent;\n  border-right: solid 0 transparent; }\n  .search-component .search {\n    color: #9ea6ba;\n    background-color: transparent;\n    /*box-shadow: 0 10px 0px 0 $black;*/ }\n    .search-component .search .search-col {\n      /*height: 60px;*/\n      /*float: left;*/\n      border-right: solid 1px #cbcdd1;\n      color: #98a8bc; }\n      .search-component .search .search-col div {\n        padding: 16px 0 0 25px;\n        text-align: left;\n        background-color: #fff; }\n        .search-component .search .search-col div h5 {\n          font-size: 1.0em;\n          font-weight: normal; }\n        .search-component .search .search-col div h6 {\n          font-size: .9em;\n          font-weight: normal;\n          text-transform: capitalize;\n          margin-top: 1px; }\n        .search-component .search .search-col div p {\n          margin-top: 1px;\n          color: #303741;\n          font-size: .95em; }\n      .search-component .search .search-col .search-col-container-sort {\n        padding: 0;\n        /*background: url(\"../../../images/dropdown_chevron.svg\") no-repeat;\n                background-position: 95% 12px;\n                background-size: 9px 6px;\n                background-color: $white;*/ }\n        .search-component .search .search-col .search-col-container-sort .search-col-sort {\n          width: 20%;\n          padding: 0;\n          float: left; }\n          .search-component .search .search-col .search-col-container-sort .search-col-sort h6 {\n            margin: 17px 5px 15px 15px; }\n        .search-component .search .search-col .search-col-container-sort .search-col-sort-dropdown {\n          width: 80%;\n          position: relative;\n          padding: 0;\n          float: left; }\n          .search-component .search .search-col .search-col-container-sort .search-col-sort-dropdown dropdown {\n            width: 100%;\n            position: absolute;\n            padding-top: 11px; }\n      .search-component .search .search-col .search-col-container-page {\n        padding: 0;\n        /*width: 100%;*/ }\n        .search-component .search .search-col .search-col-container-page .search-col-page {\n          width: 60%;\n          padding: 0;\n          float: left; }\n          .search-component .search .search-col .search-col-container-page .search-col-page h6 {\n            margin: 18px 10px; }\n        .search-component .search .search-col .search-col-container-page .search-col-page-dropdown {\n          width: 40%;\n          position: relative;\n          padding: 0;\n          float: right; }\n          .search-component .search .search-col .search-col-container-page .search-col-page-dropdown dropdown {\n            width: auto;\n            position: absolute;\n            /*left: -5px;*/\n            padding-top: 11px;\n            text-align: left; }\n      .search-component .search .search-col .search-box-container input {\n        font-size: .95em;\n        background: url(\"../../../app/content/images/mag-glass.png\") 95% 50% no-repeat;\n        /*margin: 0 10px 0 0;*/ }\n    .search-component .search .search-col-0 {\n      width: 58%; }\n    .search-component .search .search-col-1 {\n      width: 8%;\n      padding: 0;\n      display: none; }\n      .search-component .search .search-col-1 .refine-button {\n        width: 100%;\n        height: 100%;\n        text-align: center;\n        float: left;\n        /*border-right: solid 1px #cbcdd1;*/\n        background-color: white;\n        color: black; }\n    .search-component .search .search-col-2 {\n      width: 25%; }\n      .search-component .search .search-col-2 div {\n        padding: 0; }\n    .search-component .search .search-col-3 {\n      width: 32%; }\n    .search-component .search .search-col-4 {\n      width: 15%; }\n    .search-component .search .search-col-5 {\n      width: 13%;\n      /*border-right: solid 0 transparent;*/ }\n    .search-component .search .search-col-6 {\n      width: 15%;\n      border-right: solid 0 transparent; }\n\n    \n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], SearchComponent);
    return SearchComponent;
}());
exports.SearchComponent = SearchComponent;
//# sourceMappingURL=search.component.js.map