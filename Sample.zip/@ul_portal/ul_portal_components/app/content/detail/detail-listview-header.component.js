"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var DetailListViewHeaderComponent = (function () {
    function DetailListViewHeaderComponent() {
        this.pageTitle = 'Quote Detail';
        this.onSortHeaderEvent = new core_1.EventEmitter();
    }
    DetailListViewHeaderComponent.prototype.ngAfterViewInit = function () {
        //var headerCol2Width = (<any>document).getElementsByClassName('header-col-2')[0];
        //console.log(headerCol2Width.getBoundingClientRect());
        //window.onresize = function () {
        //    console.log(headerCol2Width.getBoundingClientRect());
        //};
    };
    DetailListViewHeaderComponent.prototype.onSortHeader = function (event, data) {
        var obj = new Object();
        obj.data = data;
        obj.event = event;
        this.onSortHeaderEvent.emit(obj);
    };
    DetailListViewHeaderComponent.prototype.getHeaderClass = function (index) {
        return 'header-col' + ' ' + 'header-col-' + (index + 1);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], DetailListViewHeaderComponent.prototype, "columns", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], DetailListViewHeaderComponent.prototype, "onSortHeaderEvent", void 0);
    DetailListViewHeaderComponent = __decorate([
        core_1.Component({
            selector: 'detail-listview-header',
            moduleId: '',
            template: "\n        <section class=\"detail-listview-header-component flex-container\">\n\n            <div class=\"detail-listview-header flex-container\">\n\n                <div *ngFor=\"let column of columns; let i = index\" [class]=\"getHeaderClass(i)\">\n                    <div>\n                        <h6 (click)=\"onSortHeader($event, column)\">{{ column }}</h6>\n                    </div>\n                </div>\n                \n            </div>\n\n        </section>    \n    ",
            styles: ["\n    /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.detail-listview-header-component {\n  /*width: 100%;*/\n  height: 50px;\n  background-color: #e6e9ed;\n  margin-bottom: 25px !important;\n  border: solid 1px #cbcdd1;\n  border-top: solid 0 transparent;\n  border-left: solid 0 transparent;\n  border-right: solid 0 transparent; }\n  .detail-listview-header-component .detail-listview-header {\n    /*width: 95%;*/\n    /*width: 100%;*/\n    height: 50px;\n    /*margin: 0 20px 4px 20px;*/\n    padding: 0 20px;\n    color: #9ea6ba;\n    background-color: transparent; }\n    .detail-listview-header-component .detail-listview-header .header-col {\n      height: 50px;\n      float: left;\n      border-right: solid 1px #cbcdd1;\n      color: #9ea6ba; }\n      .detail-listview-header-component .detail-listview-header .header-col div {\n        padding: 15px 0 0 0;\n        text-align: center; }\n        .detail-listview-header-component .detail-listview-header .header-col div h6 {\n          text-transform: capitalize;\n          color: #303741; }\n    .detail-listview-header-component .detail-listview-header .header-col-1 {\n      /*display: none;*/\n      width: 10%; }\n    .detail-listview-header-component .detail-listview-header .header-col-2 {\n      width: 42%;\n      padding-left: 20px; }\n      .detail-listview-header-component .detail-listview-header .header-col-2 div {\n        text-align: left; }\n    .detail-listview-header-component .detail-listview-header .header-col-3 {\n      width: 18%; }\n    .detail-listview-header-component .detail-listview-header .header-col-4 {\n      width: 10%; }\n    .detail-listview-header-component .detail-listview-header .header-col-5 {\n      width: 20%;\n      border-right: solid 0 transparent; }\n    .detail-listview-header-component .detail-listview-header .header-col-6 {\n      display: none; }\n\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], DetailListViewHeaderComponent);
    return DetailListViewHeaderComponent;
}());
exports.DetailListViewHeaderComponent = DetailListViewHeaderComponent;
//# sourceMappingURL=detail-listview-header.component.js.map