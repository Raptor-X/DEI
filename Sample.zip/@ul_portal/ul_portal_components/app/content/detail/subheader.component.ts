﻿/*  System Imports  */
import { Component, Input } from '@angular/core';
import { UIDisplayField } from '../types/uidisplayfield.type';
import { ULComponent } from '../ulcomponent.component';
/* Decorator */
@Component({
    selector: 'subheader',
    moduleId: '',
    template: `
<section class="subheader-component flex-container">

    <!--determines where the content actually goes.-->
    <ng-content></ng-content>
    <div class="subheader-container">
        <div [class]="'subheader-status ' + subheaderStatusBorderClass">

            <div>
                <h6>{{ subHeaderStatusFieldLabel }}</h6>
                <h3 [class]="subheaderStatusTextClass">{{ subHeaderStatusValue }} </h3>
            </div>

        </div>

        <div class="subheader-description"><h1>{{ subHeaderStatusDescription }}</h1></div>
    </div>
</section>    
    `,
    styles: [`
    /* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }


.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.subheader-component {
  width: 100%;
  height: 95px;
  background-color: #fff; }
  .subheader-component .subheader-container {
    width: 100%;
    margin: 0 25px;
    border: solid 1px #cbcdd1;
    border-top: solid 0px transparent;
    border-right: solid 0px transparent;
    border-left: solid 0px transparent; }
    .subheader-component .subheader-container .subheader-status {
      width: 17%;
      height: 50%;
      float: left;
      border-left: solid 4px #4a92e2; }
      .subheader-component .subheader-container .subheader-status div {
        padding: 0 0 0 20px;
        margin-top: -5px; }
        .subheader-component .subheader-container .subheader-status div h3 {
          text-transform: capitalize;
          color: #4a92e2; }
        .subheader-component .subheader-container .subheader-status div h6 {
          text-transform: uppercase;
          margin-bottom: 10px; }
    .subheader-component .subheader-container .subheader-description {
      width: 82%;
      float: left;
      text-transform: capitalize;
      margin-top: -10px; }

    
    `]
})

export class SubheaderComponent extends ULComponent {
    
    @Input() subHeaderStatusFieldLabel :any;
    @Input() subHeaderStatusFieldName :any;
    @Input() subHeaderStatusValue : any;
    @Input() subHeaderStatusDescription :any
	@Input() subheaderStatusTextClass : string = '';
	@Input() subheaderStatusBorderClass : string = '';
    pageTitle: string = '';
}