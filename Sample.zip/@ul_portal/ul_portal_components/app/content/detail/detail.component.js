"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var DetailsComponent = (function () {
    function DetailsComponent() {
        this.detailFields = new Array();
    }
    DetailsComponent.prototype.ngAfterViewInit = function () {
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], DetailsComponent.prototype, "detailDataObject", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], DetailsComponent.prototype, "detailFields", void 0);
    DetailsComponent = __decorate([
        core_1.Component({
            selector: 'detail',
            moduleId: '',
            template: "\n<section class=\"detail-component flex-container\">\n\n    <!--determines where the content actually goes.-->\n    <ng-content></ng-content>\n\n    <div class=\"detail-container\" *ngIf=\"detailDataObject\">\n        <div *ngFor=\"let detailField of detailFields;let i = index;\" >\n\t\t\t<div class=\"detail-element-container\" *ngIf=\"i % 2 == 0\">\n\t\t\t\t<div class=\"detail-element\" >\n\t\t\t\t\t<h6>{{ detailField.fieldLabel }}</h6>\n\t\t\t\t\t<h3 [innerHTML]=\"detailDataObject[0][detailField.dataFieldName] \"></h3>\n\t\t\t\t\t\n\t\t\t\t</div>\n\t\t\t\t<div class=\"detail-element\" *ngIf=\"detailFields[i+1]\">\n\t\t\t\t\t<h6>{{ detailFields[i+1].fieldLabel }}</h6>\n\t\t\t\t\t<h3 [innerHTML]=\"detailDataObject[0][detailFields[i+1].dataFieldName]\"></h3>\n\t\t\t\t</div>\n\t\t\t</div>\n        </div>\n\t\t<div class=\"detail-element-container\">\n\t\t\t\t\t<div class=\"detail-element detail-element-tall\">\n\t\t\t\t\t\t<h6>UL CONTACT</h6>\n\t\t\t\t\t\t<h3>{{detailDataObject[0].SalesRepInfo.Name}}</h3>\n\t\t\t\t\t\t<p>\n\t\t\t\t\t\t\tSales Representative<br />\n\t\t\t\t\t\t\t{{detailDataObject[0].SalesRepInfo.Region1}}, {{detailDataObject[0].SalesRepInfo.Region2}}<br />\n\t\t\t\t\t\t\t<a href=\"mailto:{{detailDataObject[0].SalesRepInfo.Email}}\">{{detailDataObject[0].SalesRepInfo.Email}}</a>\n\t\t\t\t\t\t</p>\n\n\t\t\t\t\t</div>\n\n\t\t\t\t</div>\n    </div>\n</section>    \n    ",
            styles: ["\n    /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.detail-component {\n  width: 100%;\n  height: 240px;\n  margin-bottom: 2px;\n  background-color: #fff; }\n  .detail-component .detail-container {\n    width: 100%;\n    margin: 20px 30px; }\n    .detail-component .detail-container .detail-element-container {\n      width: 20%;\n      height: 100%;\n      float: left; }\n      .detail-component .detail-container .detail-element-container .detail-element {\n        padding: 0 0 45px 0; }\n        .detail-component .detail-container .detail-element-container .detail-element h3 {\n          color: #303741; }\n        .detail-component .detail-container .detail-element-container .detail-element h6 {\n          margin-bottom: 14px; }\n\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], DetailsComponent);
    return DetailsComponent;
}());
exports.DetailsComponent = DetailsComponent;
//# sourceMappingURL=detail.component.js.map