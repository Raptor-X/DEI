﻿/*  System Imports  */

import { Component, Input, Output, EventEmitter, OnInit } from '@angular/core';

/* Decorator */
@Component({
    selector: 'tabs',
    moduleId: '',
    template:`
    
<section class="tabs-component">

    <div (click)="onTabClick($event, tabName, i)" [class]="getTabClasses(i)" *ngFor="let tabName of tabNames; let i = index">
        <div>
            <h6>{{ tabName }}</h6>
        </div>
    </div>
    <ng-content></ng-content>

</section>

    `,
    styles: [`
/* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.tabs-component {
  width: 100%;
  height: 60px;
  background-color: #f0f3f7;
  border: solid 1px #cbcdd1;
  border-top: solid 0 transparent;
  border-left: solid 0 transparent;
  border-right: solid 0 transparent; }
  .tabs-component :first-child {
    /*border-left: solid 1px $neutral-gray-border;
    background-color: white;
    border-top: solid 4px $myul-dark-blue;
    height: 65px;
    margin: -3px 0 0 29px;*/ }
    .tabs-component :first-child div h6 {
      color: #303741 !important; }
  .tabs-component .tab {
    width: 15%;
    max-width: 180px;
    min-width: 100px;
    height: 60px;
    float: left;
    border-right: solid 1px #cbcdd1;
    color: #9ea6ba;
    cursor: pointer; }
    .tabs-component .tab :first-child {
      border-top: solid 0 transparent;
      border-left: solid 0 transparent;
      margin: 0;
      background-color: transparent;
      color: #303741; }
      .tabs-component .tab :first-child h6 {
        color: #9ea6ba; }
    .tabs-component .tab div {
      padding: 20px 0 0 0;
      text-align: center; }
      .tabs-component .tab div h6 {
        text-transform: uppercase;
        color: #303741; }
  .tabs-component .active-tab {
    width: 15%;
    max-width: 180px;
    min-width: 100px;
    height: 60px;
    float: left;
    background-color: white;
    border-right: solid 1px #cbcdd1;
    color: #9ea6ba;
    cursor: pointer; }
  .tabs-component .active-tab div h6 {
    color: #303741 !important;
    margin: -3px 0 0 0px; }

.activetab {
  background-color: white;
  border-top: solid 4px #303741;
  margin: -4px 0 0 0px; }

.activetab div h6 {
  color: #303741 !important; }
    
    `]
})

export class TabsComponent implements OnInit {
    @Input() tabNames:any;
	@Output() onTabClickEvent  = new EventEmitter<any>();
	selectedTabIndex:any;
	
	ngOnInit() {
		this.selectedTabIndex = 0;
	}
    getTabClasses(index:any) {
        if (index == this.selectedTabIndex) {
            return "tab activetab";
        } else {
            return "tab";
        }
    }
    onTabClick(event:any, name:any, index:any) {
        var obj:any = new Object();
        obj.event = event;
        obj.name = name;
		this.selectedTabIndex = index;
        this.onTabClickEvent.emit(obj);
    }
    pageTitle: string = '';
}