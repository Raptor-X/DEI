﻿/*  System Imports  */
import { Component, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';

/* Decorator */
@Component({
    selector: 'detail-listview-header',
    moduleId: '',
    template:`
        <section class="detail-listview-header-component flex-container">

            <div class="detail-listview-header flex-container">

                <div *ngFor="let column of columns; let i = index" [class]="getHeaderClass(i)">
                    <div>
                        <h6 (click)="onSortHeader($event, column)">{{ column }}</h6>
                    </div>
                </div>
                
            </div>

        </section>    
    `,
    styles: [`
    /* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.detail-listview-header-component {
  /*width: 100%;*/
  height: 50px;
  background-color: #e6e9ed;
  margin-bottom: 25px !important;
  border: solid 1px #cbcdd1;
  border-top: solid 0 transparent;
  border-left: solid 0 transparent;
  border-right: solid 0 transparent; }
  .detail-listview-header-component .detail-listview-header {
    /*width: 95%;*/
    /*width: 100%;*/
    height: 50px;
    /*margin: 0 20px 4px 20px;*/
    padding: 0 20px;
    color: #9ea6ba;
    background-color: transparent; }
    .detail-listview-header-component .detail-listview-header .header-col {
      height: 50px;
      float: left;
      border-right: solid 1px #cbcdd1;
      color: #9ea6ba; }
      .detail-listview-header-component .detail-listview-header .header-col div {
        padding: 15px 0 0 0;
        text-align: center; }
        .detail-listview-header-component .detail-listview-header .header-col div h6 {
          text-transform: capitalize;
          color: #303741; }
    .detail-listview-header-component .detail-listview-header .header-col-1 {
      /*display: none;*/
      width: 10%; }
    .detail-listview-header-component .detail-listview-header .header-col-2 {
      width: 42%;
      padding-left: 20px; }
      .detail-listview-header-component .detail-listview-header .header-col-2 div {
        text-align: left; }
    .detail-listview-header-component .detail-listview-header .header-col-3 {
      width: 18%; }
    .detail-listview-header-component .detail-listview-header .header-col-4 {
      width: 10%; }
    .detail-listview-header-component .detail-listview-header .header-col-5 {
      width: 20%;
      border-right: solid 0 transparent; }
    .detail-listview-header-component .detail-listview-header .header-col-6 {
      display: none; }

    `]
})

export class DetailListViewHeaderComponent implements AfterViewInit {
    pageTitle: string = 'Quote Detail';
    @Input() columns: any[];
	@Output() onSortHeaderEvent = new EventEmitter<any>();
    ngAfterViewInit() {
        //var headerCol2Width = (<any>document).getElementsByClassName('header-col-2')[0];
        //console.log(headerCol2Width.getBoundingClientRect());

        //window.onresize = function () {
        //    console.log(headerCol2Width.getBoundingClientRect());
        //};
    }
	onSortHeader(event:any, data:any) {
		var obj:any = new Object();
		obj.data = data;
		obj.event = event;
		this.onSortHeaderEvent.emit(obj);
	}
    getHeaderClass(index:number) {
        return 'header-col' + ' ' + 'header-col-' + (index + 1)
    }
}