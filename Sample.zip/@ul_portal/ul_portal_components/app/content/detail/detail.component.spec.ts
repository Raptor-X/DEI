/* tslint:disable:no-unused-variable */
import { DetailsComponent } from './detail.component';
import { TestBed }      from '@angular/core/testing';
import { By }           from '@angular/platform-browser';

////////  SPECS  /////////////

describe('Smoke test', () => {
  it('should run a passing test', () => {
    expect(true).toEqual(true, 'should pass');
  });
});

describe('AppComponent with TCB', function () {
  beforeEach(() => {
    TestBed.configureTestingModule({declarations: [DetailsComponent]});
  });

  it('should instantiate component', () => {
    let fixture = TestBed.createComponent(DetailsComponent);
    expect(fixture.componentInstance instanceof DetailsComponent).toBe(true, 'should create DetailComponent');
  });
});
