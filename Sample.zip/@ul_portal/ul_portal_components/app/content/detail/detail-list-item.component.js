"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var DetailListItemComponent = (function () {
    function DetailListItemComponent() {
        this.pageTitle = '';
    }
    DetailListItemComponent.prototype.getColumnClasses = function (i) {
        return ('list-item-col list-item-col-' + (i + 1));
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], DetailListItemComponent.prototype, "columns", void 0);
    DetailListItemComponent = __decorate([
        core_1.Component({
            selector: 'detail-list-item',
            moduleId: '',
            template: "\n            <section class=\"detail-list-item-component\">\n\n            <div class=\"detail-list-item flex-container\">\n                <div *ngFor=\"let column of columns; let i=index;\" [class]=\"getColumnClasses(i)\">\n                    <div class=\"list-item-quote\">\n                        <h5>{{ column.value }}</h5>\n                    </div>\n                </div>\n\n            </div>\n\n        </section>\n    ",
            styles: ["\n    /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.detail-list-item-component {\n  /*width: 100%;*/\n  height: 100%;\n  padding: 2px 25px;\n  background-color: #f0f3f7;\n  border: solid 0 transparent;\n  /*box-shadow: 3px 3px $myul-light-steel-gray inset;*/\n  /*:first-child {\n            margin-top: 25px;\n    }*/ }\n  .detail-list-item-component .detail-list-item {\n    /*width: 100%;*/\n    min-height: 80px;\n    /*margin: 0 0 4px -4px;*/\n    border: solid 1px #cbcdd1;\n    /*border-left: solid 4px $myul-action-blue;*/\n    color: #9ea6ba;\n    background-color: #fff; }\n    .detail-list-item-component .detail-list-item .list-item-col {\n      border-right: solid 1px #cbcdd1; }\n      .detail-list-item-component .detail-list-item .list-item-col div {\n        padding: 0;\n        text-align: center;\n        padding-top: 15px; }\n        .detail-list-item-component .detail-list-item .list-item-col div h5 {\n          min-height: 30px;\n          /*margin-right: 20px;*/\n          color: #303741; }\n        .detail-list-item-component .detail-list-item .list-item-col div h6 {\n          text-transform: capitalize;\n          color: #303741;\n          padding: 2px 20px 12px 0;\n          border-top: solid 1px #cbcdd1; }\n        .detail-list-item-component .detail-list-item .list-item-col div p {\n          text-transform: capitalize;\n          color: #303741;\n          margin-top: 38px; }\n    .detail-list-item-component .detail-list-item .list-item-col-1 {\n      width: 10%; }\n    .detail-list-item-component .detail-list-item .list-item-col-2 {\n      width: 42%;\n      /*padding-right: 30px;*/\n      /*padding: 15px 0 0 20px;*/\n      padding-left: 20px; }\n      .detail-list-item-component .detail-list-item .list-item-col-2 div {\n        text-align: left; }\n      .detail-list-item-component .detail-list-item .list-item-col-2 .list-item-description {\n        /*padding-top: 18px;*/ }\n      .detail-list-item-component .detail-list-item .list-item-col-2 .list-item-status {\n        padding-top: 5px; }\n        .detail-list-item-component .detail-list-item .list-item-col-2 .list-item-status h6 {\n          color: #98a8bc; }\n    .detail-list-item-component .detail-list-item .list-item-col-3 {\n      width: 18%; }\n    .detail-list-item-component .detail-list-item .list-item-col-4 {\n      width: 10%; }\n    .detail-list-item-component .detail-list-item .list-item-col-5 {\n      width: 20%;\n      border-right: solid 0 #cbcdd1; }\n    .detail-list-item-component .detail-list-item .list-item-col-6 {\n      display: none; }\n\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], DetailListItemComponent);
    return DetailListItemComponent;
}());
exports.DetailListItemComponent = DetailListItemComponent;
//# sourceMappingURL=detail-list-item.component.js.map