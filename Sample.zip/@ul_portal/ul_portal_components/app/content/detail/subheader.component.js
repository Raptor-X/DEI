"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
var ulcomponent_component_1 = require('../ulcomponent.component');
/* Decorator */
var SubheaderComponent = (function (_super) {
    __extends(SubheaderComponent, _super);
    function SubheaderComponent() {
        _super.apply(this, arguments);
        this.subheaderStatusTextClass = '';
        this.subheaderStatusBorderClass = '';
        this.pageTitle = '';
    }
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], SubheaderComponent.prototype, "subHeaderStatusFieldLabel", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], SubheaderComponent.prototype, "subHeaderStatusFieldName", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], SubheaderComponent.prototype, "subHeaderStatusValue", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], SubheaderComponent.prototype, "subHeaderStatusDescription", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], SubheaderComponent.prototype, "subheaderStatusTextClass", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], SubheaderComponent.prototype, "subheaderStatusBorderClass", void 0);
    SubheaderComponent = __decorate([
        core_1.Component({
            selector: 'subheader',
            moduleId: '',
            template: "\n<section class=\"subheader-component flex-container\">\n\n    <!--determines where the content actually goes.-->\n    <ng-content></ng-content>\n    <div class=\"subheader-container\">\n        <div [class]=\"'subheader-status ' + subheaderStatusBorderClass\">\n\n            <div>\n                <h6>{{ subHeaderStatusFieldLabel }}</h6>\n                <h3 [class]=\"subheaderStatusTextClass\">{{ subHeaderStatusValue }} </h3>\n            </div>\n\n        </div>\n\n        <div class=\"subheader-description\"><h1>{{ subHeaderStatusDescription }}</h1></div>\n    </div>\n</section>    \n    ",
            styles: ["\n    /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.subheader-component {\n  width: 100%;\n  height: 95px;\n  background-color: #fff; }\n  .subheader-component .subheader-container {\n    width: 100%;\n    margin: 0 25px;\n    border: solid 1px #cbcdd1;\n    border-top: solid 0px transparent;\n    border-right: solid 0px transparent;\n    border-left: solid 0px transparent; }\n    .subheader-component .subheader-container .subheader-status {\n      width: 17%;\n      height: 50%;\n      float: left;\n      border-left: solid 4px #4a92e2; }\n      .subheader-component .subheader-container .subheader-status div {\n        padding: 0 0 0 20px;\n        margin-top: -5px; }\n        .subheader-component .subheader-container .subheader-status div h3 {\n          text-transform: capitalize;\n          color: #4a92e2; }\n        .subheader-component .subheader-container .subheader-status div h6 {\n          text-transform: uppercase;\n          margin-bottom: 10px; }\n    .subheader-component .subheader-container .subheader-description {\n      width: 82%;\n      float: left;\n      text-transform: capitalize;\n      margin-top: -10px; }\n\n    \n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], SubheaderComponent);
    return SubheaderComponent;
}(ulcomponent_component_1.ULComponent));
exports.SubheaderComponent = SubheaderComponent;
//# sourceMappingURL=subheader.component.js.map