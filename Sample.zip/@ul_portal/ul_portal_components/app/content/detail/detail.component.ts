﻿/*  System Imports  */
import { Component, AfterViewInit, Input } from '@angular/core';
import { UIDisplayField } from '../types/uidisplayfield.type';
import { ULComponent } from '../ulcomponent.component';
import {AppConfigService} from '../../services/appconfigservice.service';
import {DataService} from '../../services/dataservice.service';

/* Decorator */
@Component({
    selector: 'detail',
    moduleId: '',
    template:`
<section class="detail-component flex-container">

    <!--determines where the content actually goes.-->
    <ng-content></ng-content>

    <div class="detail-container" *ngIf="detailDataObject">
        <div *ngFor="let detailField of detailFields;let i = index;" >
			<div class="detail-element-container" *ngIf="i % 2 == 0">
				<div class="detail-element" >
					<h6>{{ detailField.fieldLabel }}</h6>
					<h3 [innerHTML]="detailDataObject[0][detailField.dataFieldName] "></h3>
					
				</div>
				<div class="detail-element" *ngIf="detailFields[i+1]">
					<h6>{{ detailFields[i+1].fieldLabel }}</h6>
					<h3 [innerHTML]="detailDataObject[0][detailFields[i+1].dataFieldName]"></h3>
				</div>
			</div>
        </div>
		<div class="detail-element-container">
					<div class="detail-element detail-element-tall">
						<h6>UL CONTACT</h6>
						<h3>{{detailDataObject[0].SalesRepInfo.Name}}</h3>
						<p>
							Sales Representative<br />
							{{detailDataObject[0].SalesRepInfo.Region1}}, {{detailDataObject[0].SalesRepInfo.Region2}}<br />
							<a href="mailto:{{detailDataObject[0].SalesRepInfo.Email}}">{{detailDataObject[0].SalesRepInfo.Email}}</a>
						</p>

					</div>

				</div>
    </div>
</section>    
    `,
    styles: [`
    /* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }


.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.detail-component {
  width: 100%;
  height: 240px;
  margin-bottom: 2px;
  background-color: #fff; }
  .detail-component .detail-container {
    width: 100%;
    margin: 20px 30px; }
    .detail-component .detail-container .detail-element-container {
      width: 20%;
      height: 100%;
      float: left; }
      .detail-component .detail-container .detail-element-container .detail-element {
        padding: 0 0 45px 0; }
        .detail-component .detail-container .detail-element-container .detail-element h3 {
          color: #303741; }
        .detail-component .detail-container .detail-element-container .detail-element h6 {
          margin-bottom: 14px; }

    `]
})

export class DetailsComponent implements ULComponent, AfterViewInit {
    pageTitle: string;
    @Input() detailDataObject:any;
    @Input() detailFields:UIDisplayField[] = new Array<UIDisplayField>();

    ngAfterViewInit() {

        
    }

    constructor() {
        
    }


}