"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var DetailTabViewPeopleComponent = (function () {
    function DetailTabViewPeopleComponent() {
        this.pageTitle = '';
    }
    DetailTabViewPeopleComponent.prototype.ngAfterViewInit = function () {
        //var headerCol2Width = (<any>document).getElementsByClassName('header-col-2')[0];
        //console.log(headerCol2Width.getBoundingClientRect());
        //window.onresize = function () {
        //    console.log(headerCol2Width.getBoundingClientRect());
        //};
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], DetailTabViewPeopleComponent.prototype, "person", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], DetailTabViewPeopleComponent.prototype, "title", void 0);
    DetailTabViewPeopleComponent = __decorate([
        core_1.Component({
            selector: 'detail-tabview-people',
            moduleId: '',
            template: "\n    <div class=\"contact-container\" *ngIf=\"title != 'UL CONTACT'\">\n  <div class=\"contact-title\">\n      <h6>{{ title }}</h6>\n  </div>\n  <div class=\"contact-header\">\n    <p class=\"contact-header-name\">{{person.Contact}}</p>\n    <p class=\"contact-header-email\"><a href=\"mailto:{{person.ContactEmail}}\">{{person.ContactEmail}}</a></p>\n  </div>\n  <div class=\"contact-details\">\n    <p><strong>{{person.Company}}</strong></p>\n    <p>{{ person.AddressLine1}}</p>\n    <p>{{ person.AddressLine2}}</p>\n\t<p>{{ person.AddressLine3}}</p>\n    <p>{{ person.City }}<span *ngIf=\"person.City && person.State\">, </span> {{person.State}}</p>\n    <p>{{ person.Country}}<span *ngIf=\"person.Country && person.CountryCode\">, </span> {{person.CountryCode}} {{person.PostalCode}}</p>\n  </div>\n</div>\n\n<div class=\"contact-container\" *ngIf=\"title == 'UL CONTACT'\">\n  <div class=\"contact-title\">\n      <h6>{{ title }}</h6>\n  </div>\n  <div class=\"contact-header\">\n    <p class=\"contact-header-name\">{{person.Name}}</p>\n    <p class=\"contact-header-email\"><a href=\"mailto:{{person.Email}}\">{{person.Email}}</a></p>\n  </div>\n  <div class=\"contact-details\">\n    <p><strong>{{person.Company}}</strong></p>\n    <p>{{ person.AddressLine1}}</p>\n    <p>{{ person.AddressLine2}}</p>\n\t<p>{{ person.AddressLine3}}</p>\n    <p>{{ person.Region1 }}<span *ngIf=\"person.Region1 && person.Region2\">, </span> {{person.Region2}}</p>\n    <p>{{ person.Country}}<span *ngIf=\"person.Country && person.CountryCode\">, </span> {{person.CountryCode}} {{person.PostalCode}}</p>\n  </div>\n</div>\n    ",
            styles: ["\n   /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n/*.detail-tabview-people-component {*/\n/*width: 100%;*/\n/*background-color: $myul-medium-gray;\n    margin-bottom: 25px !important;\n    border: solid 1px $neutral-gray-border;\n    border-top: solid 0 transparent;\n    border-left: solid 0 transparent;\n    border-right: solid 0 transparent;*/\n/*}*/\n.contact-container {\n  min-height: 300px !important;\n  margin: 20px 0 0 20px;\n  border: solid 1px #cbcdd1;\n  width: 30%;\n  float: left; }\n  .contact-container div {\n    padding: 20px;\n    color: #000 !important; }\n  .contact-container div * {\n    color: #000; }\n  .contact-container .contact-title {\n    background-color: #fff;\n    border-bottom: solid 1px #cbcdd1; }\n    .contact-container .contact-title h6 {\n      font-size: .9em; }\n  .contact-container .contact-header {\n    min-height: 60px;\n    background-color: #fff;\n    border-bottom: solid 1px #cbcdd1; }\n    .contact-container .contact-header p {\n      margin-bottom: 5px !important; }\n    .contact-container .contact-header .contact-header-name {\n      font-size: 1.6em; }\n  .contact-container .contact-details {\n    background-color: #f0f3f7; }\n    .contact-container .contact-details p {\n      margin-bottom: 0 !important; }\n\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], DetailTabViewPeopleComponent);
    return DetailTabViewPeopleComponent;
}());
exports.DetailTabViewPeopleComponent = DetailTabViewPeopleComponent;
//# sourceMappingURL=detail-tabview-people.component.js.map