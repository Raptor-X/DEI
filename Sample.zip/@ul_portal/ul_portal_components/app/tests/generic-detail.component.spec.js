"use strict";
var testing_1 = require('@angular/core/testing');
var generic_detail_component_1 = require('../../app/content/generic-detail.component');
describe('GenericDetailComponent', function () {
    var comp;
    var fixture;
    var de;
    var el;
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [generic_detail_component_1.GenericDetailComponent],
        });
        testing_1.TestBed.compileComponents().then(function () {
            fixture = testing_1.TestBed.createComponent(generic_detail_component_1.GenericDetailComponent);
            comp = fixture.componentInstance; // GenericDetailComponent test instance
        });
    }));
    it('Component Exists in Current Context', function () {
        expect(comp).toBeDefined;
    });
});
//# sourceMappingURL=generic-detail.component.spec.js.map