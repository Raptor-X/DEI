import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from "@angular/platform-browser-dynamic/testing";
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By }              from '@angular/platform-browser';
import { DebugElement }    from '@angular/core';

import { ContentComponent } from '../../app/content/content.component';


describe('ContentComponent', () => {

  let comp:    ContentComponent;
  let fixture: ComponentFixture<ContentComponent>;
  let de:      DebugElement;
  let el:      HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ContentComponent ], // declare the test component
    });
    TestBed.compileComponents().then(() => {
        fixture = TestBed.createComponent(ContentComponent);
        comp = fixture.componentInstance; // ContentComponent test instance
        
        
    });
  }));

   it('Component Exists in Current Context', () => {
            expect(comp).toBeDefined
    });
});