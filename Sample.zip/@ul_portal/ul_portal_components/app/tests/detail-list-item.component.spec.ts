import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from "@angular/platform-browser-dynamic/testing";
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By }              from '@angular/platform-browser';
import { DebugElement }    from '@angular/core';

import { DetailListItemComponent } from '../../app/content/detail/detail-list-item.component';


describe('ContentComponent (inline template)', () => {

  let comp:    DetailListItemComponent;
  let fixture: ComponentFixture<DetailListItemComponent>;
  let de:      DebugElement;
  let el:      HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DetailListItemComponent ], // declare the test component
    });
    /*TestBed.compileComponents().then(() => {
        fixture = TestBed.createComponent(DetailListItemComponent);
        comp = fixture.componentInstance; // DetailListItemComponent test instance
        // query for the title <h1> by CSS element selector
        de = fixture.debugElement.query(By.css('h1'));
        el = de.nativeElement;
    });*/
  }));

   /* it('should display original title', () => {
            expect(el.textContent).toContain('Test Title');
    });*/
    describe('Meaningful Test', () => {
        it('1 + 1 => 2', () => {
            expect(1 + 1).toBe(2);
        });
    });
});