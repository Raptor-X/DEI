"use strict";
var Order = (function () {
    function Order(status, count) {
        this.Status = status;
        this.Count = count;
    }
    return Order;
}());
exports.Order = Order;
//# sourceMappingURL=Order.js.map