﻿export class Order {

	public Status: string;
	public Count: number;

	constructor(status: string, count: number) {
		this.Status = status;
		this.Count = count;
	}

}