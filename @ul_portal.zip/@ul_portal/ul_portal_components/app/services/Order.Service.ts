﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import { Configuration } from './app.constants';
import { Order } from '../../app/models/Order';


@Injectable()
export class OrderService {

	private actionUrl: string;
    private headers: Headers;
    private _configuration: Configuration = new Configuration();
    private http: Http;
    private deepLinkUrls: string;
    private AppAccessUrl: string;
    private AlertAccessUrl: string;


	constructor(_http: Http) {

        this.actionUrl = this._configuration.ServerWithApiUrl + 'GetOrdersSummary/';
        this.deepLinkUrls = this._configuration.ServerWithApiUrl + 'GetConfiguration/';
        this.AppAccessUrl = 'Home/GetAppAccess/';
        this.AlertAccessUrl = 'Home/GetAlertAccess/';
        this.http = _http;
        this.headers = new Headers();
        this.headers.append('Content-Type', 'application/json');
        this.headers.append('Accept', 'application/json, text/javascript');
        this.headers.append('x-requested-with', 'XMLHttpRequest');
    }

	public GetSummary = (): any => {
	return this.http.get(this.actionUrl)
        .map((response: Response) => <any[]>response.json())
          .catch(this.handleError);
	}

	private handleError(error: Response) {
        console.error(error);
        return Observable.throw(error.json().error || 'Server error');
    }
    // Getting deeplink URLs
    public GetConfiguration = (): Observable<OrderService> => {
        return this.http.get(this.deepLinkUrls)
            .map((res: Response) => <OrderService>res.json())
            .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    }
    public GetAppAccess = (): any => {
        return this.http.post(this.AppAccessUrl, {})
            .map((response: Response) => <any[]>response.json())
            .catch(this.handleError);
    }

    public GetAlertAccess = (): any => {
        return this.http.post(this.AlertAccessUrl, {})
            .map((response: Response) => <any[]>response.json())
            .catch(this.handleError);
    }
}
