import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { UIDisplayField } from '../content/types/uidisplayfield.type';

@Injectable()
export class AppConfigService  {

    getDataServiceName() : string {
        return 'Generic Data Service';   
    }

    getListParameters() : any {
        return undefined;
    }
    getDetailFields() : Array<UIDisplayField> {
        return undefined;
    }
    getSubHeaderFields() : Array<UIDisplayField> {
        return undefined;
    }
    getSubHeaderStatusFieldName() :any {
        return undefined;
    }
    getSubHeaderDescriptionFieldName() :any {
        return undefined;
    }
    getSubHeaderStatusFieldLabel() :any {
        return undefined;
    }  
    getHeaderTitle() : any {
        return undefined;
    }  
    getHeaderBreadCrumb() : any {
        return undefined;
    }
    

    
}