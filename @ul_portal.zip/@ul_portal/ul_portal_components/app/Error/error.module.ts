﻿import { NgModule } from '@angular/core';
import { ErrorHandlerComponent } from './error.component';


@NgModule({
   
    declarations: [
        ErrorHandlerComponent
    ],
    exports: [ErrorHandlerComponent]
})
export class ErrorHandlerModule { }
