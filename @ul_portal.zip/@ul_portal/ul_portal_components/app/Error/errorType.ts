﻿export enum ErrorType {
    error = <any>'Oops!! The information you are looking for could not be found',
    NoRecord = <any>'Oops!! The information you are looking for could not be found'
}