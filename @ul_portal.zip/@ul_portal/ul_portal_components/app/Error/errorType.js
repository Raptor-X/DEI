"use strict";
(function (ErrorType) {
    ErrorType[ErrorType["error"] = 'Oops!! The information you are looking for could not be found'] = "error";
    ErrorType[ErrorType["NoRecord"] = 'Oops!! The information you are looking for could not be found'] = "NoRecord";
})(exports.ErrorType || (exports.ErrorType = {}));
var ErrorType = exports.ErrorType;
//# sourceMappingURL=errorType.js.map