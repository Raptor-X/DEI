"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
require('rxjs/add/observable/fromEvent');
require('rxjs/add/operator/delay');
require('rxjs/add/operator/do');
var DropdownValue = (function () {
    function DropdownValue(value, label) {
        this.value = value;
        this.label = label;
    }
    return DropdownValue;
}());
exports.DropdownValue = DropdownValue;
var DropdownComponent = (function () {
    function DropdownComponent(myElement) {
        this.state = "inactive";
        this.elementRef = myElement;
        this.select = new core_1.EventEmitter();
    }
    DropdownComponent.prototype.selectItem = function (value, isTopLevel) {
        this.state = (this.state === 'inactive' ? 'active' : 'inactive');
        this.selectedValue = value;
        this.select.emit(value);
    };
    DropdownComponent.prototype.openDropDown = function () {
        this.state = (this.state === 'inactive' ? 'active' : 'inactive');
    };
    DropdownComponent.prototype.handleClick = function (event) {
        var clickedComponent = event.target;
        var inside = false;
        do {
            if (clickedComponent === this.elementRef.nativeElement) {
                inside = true;
            }
            clickedComponent = clickedComponent.parentNode;
        } while (clickedComponent);
        if (inside) {
            console.log('inside');
        }
        else {
            console.log('clicked outside');
            this.state = 'inactive';
        }
    };
    DropdownComponent.prototype.ngOnInit = function () {
        if (!this.selectedValue) {
            this.selectedValue = this.values[0];
        }
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Array)
    ], DropdownComponent.prototype, "values", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], DropdownComponent.prototype, "type", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], DropdownComponent.prototype, "select", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], DropdownComponent.prototype, "selectedValue", void 0);
    DropdownComponent = __decorate([
        core_1.Component({
            moduleId: '',
            host: {
                '(document:click)': 'handleClick($event)',
            },
            selector: 'dropdown',
            template: "\n    <div (click)=\"openDropDown()\" class=\"selected-box\">{{selectedValue.label}}</div>\n    <div [@heroState]=\"state\" *ngIf=\"values\">\n          <div *ngFor=\"let value of values\" (click)=\"selectItem(value)\">{{value.label}}</div>\n    </div>\n    ",
            styles: ["\n/* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.selected-box {\n  margin: 0 0 10px 0;\n  padding: 1px 0 0 0;\n  font-weight: bold;\n  width: inherit;\n  min-width: 28px;\n  overflow: hidden;\n  background-image: url(\"../../../images/dropdown_chevron.svg\");\n  background-repeat: no-repeat;\n  background-position: 90% 8px;\n  background-size: 9px 6px;\n  background-color: transparent;\n  vertical-align: text-bottom;\n  position: relative;\n  top: 4.5px; }\n\ndiv {\n  margin: 0;\n  padding: 0;\n  width: 100%;\n  vertical-align: text-top;\n  float: left;\n  cursor: pointer;\n  font-size: .95em;\n  /*background-color: transparent;\n    background-image: url(\"../../../images/dropdown_chevron.svg\");\n    background-repeat: no-repeat;\n    background-position: 90% 12px;\n    background-size: 9px 6px;\n    background-color: red;*/ }\n  div :hover {\n    background-color: #e4ebf5; }\n  div div {\n    width: 100%;\n    margin: 0 0 0 0;\n    padding: 7px 0 5px 5px;\n    /*background-color: blue;*/\n    /*background-image: none;*/\n    /*background-color: transparent;\n        background: url(\"../../../images/dropdown_chevron.svg\") no-repeat;\n        background-position: 95% 12px;\n        background-size: 9px 6px;*/ }\n    \n    "],
            animations: [
                core_1.trigger('heroState', [
                    core_1.state('inactive', core_1.style({
                        width: '100%',
                        display: 'none',
                        overflow: 'hidden',
                        backgroundPosition: '90% 12px',
                        backgroundSize: '9px 6px',
                        backgroundColor: '#fff'
                    })),
                    core_1.state('active', core_1.style({
                        width: '100%',
                        overflow: 'visible',
                        backgroundPosition: '90% 12px',
                        backgroundSize: '9px 6px',
                        backgroundColor: '#fff',
                        boxShadow: '0 0 5px 3px #ddd'
                    })),
                    core_1.transition('inactive => active', core_1.animate('100ms ease-in')),
                    core_1.transition('active => inactive', core_1.animate('100ms ease-out'))
                ])
            ]
        }), 
        __metadata('design:paramtypes', [core_1.ElementRef])
    ], DropdownComponent);
    return DropdownComponent;
}());
exports.DropdownComponent = DropdownComponent;
//# sourceMappingURL=dropdown.component.js.map