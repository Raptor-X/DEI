﻿/*  System Imports  */
import { Component, EventEmitter, Output, Input, OnInit } from '@angular/core';


@Component({
    moduleId: '',
    selector: 'paging-buttons',
    template: `
<section class="paging-buttons-component">
    <div class="paging-buttons-container">
        <button [disabled]="selectedPage.label == 1" type="button" class="paging-button paging-button-left"
                 (click)="onLeftPageEvent('PREVIOUS')">
            <span class="glyphicon glyphicon-triangle glyphicon-triangle-left">
            </span>
        </button>
        <button [disabled]="pages.length == selectedPage.label" type="button" class="paging-button paging-button-right"
                 (click)="onRightPageEvent('NEXT')">
            <span class="glyphicon glyphicon-triangle glyphicon-triangle-right"></span>
        </button>
    </div>
</section>    
    `,
    styles: [`
    /* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.paging-buttons-component {
  float: right;
  width: 100%;
  height: 100%; }
  .paging-buttons-component .paging-buttons-container {
    width: 100%;
    height: 100%; }
    .paging-buttons-component .paging-buttons-container button {
      background-color: #fff; }
    .paging-buttons-component .paging-buttons-container button:disabled span {
      opacity: 0.5; }
    .paging-buttons-component .paging-buttons-container button:disabled {
      cursor: not-allowed; }
    .paging-buttons-component .paging-buttons-container .paging-button {
      /*padding: 7px 12px 10px 10px;*/
      width: 50%;
      height: 100%;
      float: left;
      border-right: solid 1px #cbcdd1; }
    .paging-buttons-component .paging-buttons-container .paging-button-left {
      /*margin-left: 0;
            border-top-right-radius: 0;
            border-bottom-right-radius: 0;*/ }
      .paging-buttons-component .paging-buttons-container .paging-button-left span {
        padding-top: 0px;
        padding-right: 0px;
        padding-bottom: 0px;
        border-top-width: 3px; }
    .paging-buttons-component .paging-buttons-container .paging-button-right {
      /*margin-left: -5px;
            border-top-left-radius: 0;
            border-bottom-left-radius: 0;*/
      border-right: solid 0 transparent; }
      .paging-buttons-component .paging-buttons-container .paging-button-right span {
        padding-top: 0;
        padding-left: 4px;
        border-top-width: 5px;
        border-bottom-width: 5px; }

    `]
})

export class PagingButtonsComponent implements OnInit {
    pageTitle: string = '';
    @Output() onLeftPage = new EventEmitter<any>();
    @Output() onRightPage = new EventEmitter<any>();
    @Input() pages:any[];
    @Input() selectedPage:any;

    ngOnInit() {

    }

    onLeftPageEvent(data:any) {
        this.onLeftPage.emit(data);
    }
    onRightPageEvent(data:any) {
        this.onRightPage.emit(data);
    }
}