﻿/*  System Imports  */
import { Component, AfterViewInit, Input } from '@angular/core';

/* Decorator */
@Component({
    selector: 'detail-tabview-people',
    moduleId: '',
    template:`
    <div class="contact-container" *ngIf="title != 'UL CONTACT'">
  <div class="contact-title">
      <h6>{{ title }}</h6>
  </div>
  <div class="contact-header">
    <p class="contact-header-name">{{person.Contact}}</p>
    <p class="contact-header-email"><a href="mailto:{{person.ContactEmail}}">{{person.ContactEmail}}</a></p>
  </div>
  <div class="contact-details">
    <p><strong>{{person.Company}}</strong></p>
    <p>{{ person.AddressLine1}}</p>
    <p>{{ person.AddressLine2}}</p>
	<p>{{ person.AddressLine3}}</p>
    <p>{{ person.City }}<span *ngIf="person.City && person.State">, </span> {{person.State}}</p>
    <p>{{ person.Country}}<span *ngIf="person.Country && person.CountryCode">, </span> {{person.CountryCode}} {{person.PostalCode}}</p>
  </div>
</div>

<div class="contact-container" *ngIf="title == 'UL CONTACT'">
  <div class="contact-title">
      <h6>{{ title }}</h6>
  </div>
  <div class="contact-header">
    <p class="contact-header-name">{{person.Name}}</p>
    <p class="contact-header-email"><a href="mailto:{{person.Email}}">{{person.Email}}</a></p>
  </div>
  <div class="contact-details">
    <p><strong>{{person.Company}}</strong></p>
    <p>{{ person.AddressLine1}}</p>
    <p>{{ person.AddressLine2}}</p>
	<p>{{ person.AddressLine3}}</p>
    <p>{{ person.Region1 }}<span *ngIf="person.Region1 && person.Region2">, </span> {{person.Region2}}</p>
    <p>{{ person.Country}}<span *ngIf="person.Country && person.CountryCode">, </span> {{person.CountryCode}} {{person.PostalCode}}</p>
  </div>
</div>
    `,
    styles: [`
   /* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
/*.detail-tabview-people-component {*/
/*width: 100%;*/
/*background-color: $myul-medium-gray;
    margin-bottom: 25px !important;
    border: solid 1px $neutral-gray-border;
    border-top: solid 0 transparent;
    border-left: solid 0 transparent;
    border-right: solid 0 transparent;*/
/*}*/
.contact-container {
  min-height: 300px !important;
  margin: 20px 0 0 20px;
  border: solid 1px #cbcdd1;
  width: 30%;
  float: left; }
  .contact-container div {
    padding: 20px;
    color: #000 !important; }
  .contact-container div * {
    color: #000; }
  .contact-container .contact-title {
    background-color: #fff;
    border-bottom: solid 1px #cbcdd1; }
    .contact-container .contact-title h6 {
      font-size: .9em; }
  .contact-container .contact-header {
    min-height: 60px;
    background-color: #fff;
    border-bottom: solid 1px #cbcdd1; }
    .contact-container .contact-header p {
      margin-bottom: 5px !important; }
    .contact-container .contact-header .contact-header-name {
      font-size: 1.6em; }
  .contact-container .contact-details {
    background-color: #f0f3f7; }
    .contact-container .contact-details p {
      margin-bottom: 0 !important; }

    `]
})

export class DetailTabViewPeopleComponent implements AfterViewInit {
    pageTitle: string = '';
    @Input() person: any;
	@Input() title: any;
    ngAfterViewInit() {
        //var headerCol2Width = (<any>document).getElementsByClassName('header-col-2')[0];
        //console.log(headerCol2Width.getBoundingClientRect());

        //window.onresize = function () {
        //    console.log(headerCol2Width.getBoundingClientRect());
        //};
    }

    //getHeaderClass(index:number) {
    //    return 'header-col' + ' ' + 'header-col-' + (index + 1)
    //}
}