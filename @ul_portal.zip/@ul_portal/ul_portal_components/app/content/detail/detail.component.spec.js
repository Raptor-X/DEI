"use strict";
/* tslint:disable:no-unused-variable */
var detail_component_1 = require('./detail.component');
var testing_1 = require('@angular/core/testing');
////////  SPECS  /////////////
describe('Smoke test', function () {
    it('should run a passing test', function () {
        expect(true).toEqual(true, 'should pass');
    });
});
describe('AppComponent with TCB', function () {
    beforeEach(function () {
        testing_1.TestBed.configureTestingModule({ declarations: [detail_component_1.DetailsComponent] });
    });
    it('should instantiate component', function () {
        var fixture = testing_1.TestBed.createComponent(detail_component_1.DetailsComponent);
        expect(fixture.componentInstance instanceof detail_component_1.DetailsComponent).toBe(true, 'should create DetailComponent');
    });
});
//# sourceMappingURL=detail.component.spec.js.map