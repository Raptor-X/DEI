/*  System Imports  */
"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
/* Decorator */
var TabsComponent = (function () {
    function TabsComponent() {
        this.onTabClickEvent = new core_1.EventEmitter();
        this.pageTitle = '';
    }
    TabsComponent.prototype.ngOnInit = function () {
        this.selectedTabIndex = 0;
    };
    TabsComponent.prototype.getTabClasses = function (index) {
        if (index == this.selectedTabIndex) {
            return "tab activetab";
        }
        else {
            return "tab";
        }
    };
    TabsComponent.prototype.onTabClick = function (event, name, index) {
        var obj = new Object();
        obj.event = event;
        obj.name = name;
        this.selectedTabIndex = index;
        this.onTabClickEvent.emit(obj);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], TabsComponent.prototype, "tabNames", void 0);
    __decorate([
        core_1.Output(), 
        __metadata('design:type', Object)
    ], TabsComponent.prototype, "onTabClickEvent", void 0);
    TabsComponent = __decorate([
        core_1.Component({
            selector: 'tabs',
            moduleId: '',
            template: "\n    \n<section class=\"tabs-component\">\n\n    <div (click)=\"onTabClick($event, tabName, i)\" [class]=\"getTabClasses(i)\" *ngFor=\"let tabName of tabNames; let i = index\">\n        <div>\n            <h6>{{ tabName }}</h6>\n        </div>\n    </div>\n    <ng-content></ng-content>\n\n</section>\n\n    ",
            styles: ["\n/* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\n.tabs-component {\n  width: 100%;\n  height: 60px;\n  background-color: #f0f3f7;\n  border: solid 1px #cbcdd1;\n  border-top: solid 0 transparent;\n  border-left: solid 0 transparent;\n  border-right: solid 0 transparent; }\n  .tabs-component :first-child {\n    /*border-left: solid 1px $neutral-gray-border;\n    background-color: white;\n    border-top: solid 4px $myul-dark-blue;\n    height: 65px;\n    margin: -3px 0 0 29px;*/ }\n    .tabs-component :first-child div h6 {\n      color: #303741 !important; }\n  .tabs-component .tab {\n    width: 15%;\n    max-width: 180px;\n    min-width: 100px;\n    height: 60px;\n    float: left;\n    border-right: solid 1px #cbcdd1;\n    color: #9ea6ba;\n    cursor: pointer; }\n    .tabs-component .tab :first-child {\n      border-top: solid 0 transparent;\n      border-left: solid 0 transparent;\n      margin: 0;\n      background-color: transparent;\n      color: #303741; }\n      .tabs-component .tab :first-child h6 {\n        color: #9ea6ba; }\n    .tabs-component .tab div {\n      padding: 20px 0 0 0;\n      text-align: center; }\n      .tabs-component .tab div h6 {\n        text-transform: uppercase;\n        color: #303741; }\n  .tabs-component .active-tab {\n    width: 15%;\n    max-width: 180px;\n    min-width: 100px;\n    height: 60px;\n    float: left;\n    background-color: white;\n    border-right: solid 1px #cbcdd1;\n    color: #9ea6ba;\n    cursor: pointer; }\n  .tabs-component .active-tab div h6 {\n    color: #303741 !important;\n    margin: -3px 0 0 0px; }\n\n.activetab {\n  background-color: white;\n  border-top: solid 4px #303741;\n  margin: -4px 0 0 0px; }\n\n.activetab div h6 {\n  color: #303741 !important; }\n    \n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], TabsComponent);
    return TabsComponent;
}());
exports.TabsComponent = TabsComponent;
//# sourceMappingURL=tabs.component.js.map