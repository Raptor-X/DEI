"use strict";
var ListColumn = (function () {
    function ListColumn() {
    }
    return ListColumn;
}());
exports.ListColumn = ListColumn;
//# sourceMappingURL=listcolumn.type.js.map