export class UIDisplayField {
    fieldLabel:string;
    dataFieldName:string;
    type:string;
}
