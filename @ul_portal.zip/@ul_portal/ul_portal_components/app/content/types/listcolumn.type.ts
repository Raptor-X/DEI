export class ListColumn {
    columnName:string;
    dataFieldName:string;
}