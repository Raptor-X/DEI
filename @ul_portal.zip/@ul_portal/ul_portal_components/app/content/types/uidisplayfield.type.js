"use strict";
var UIDisplayField = (function () {
    function UIDisplayField() {
    }
    return UIDisplayField;
}());
exports.UIDisplayField = UIDisplayField;
//# sourceMappingURL=uidisplayfield.type.js.map