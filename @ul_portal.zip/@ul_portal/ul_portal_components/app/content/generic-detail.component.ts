﻿/*  System Imports  */
import { Component, OnInit, ViewChild, ViewChildren, ElementRef } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';

import { Logger } from "angular2-logger/core";
import { HeaderComponent } from '../header/header.component';
import { ContentComponent } from './content.component';
import { RefinerContainerComponent } from './refiners/refiner-container.component';
import { RefinerComponent } from './refiners/refiner.component';
import { SearchComponent } from './search/search.component';
import { ListContainerComponent } from './list/list-container.component';
import { ListHeaderComponent } from './list/list-header.component';
import { ListItemContainerComponent } from './list/list-item-container.component';
import { ListItemComponent } from './list/list-item.component';
import { SubheaderComponent } from './detail/subheader.component';
import { DetailsComponent } from './detail/detail.component';
import { DetailListViewContainerComponent } from './detail/detail-listview-container.component';
import { TabsComponent } from './detail/tabs.component';
import { DetailListViewHeaderComponent } from './detail/detail-listview-header.component';
import { DetailListItemComponent } from './detail/detail-list-item.component';


import { AfterViewInit, Input } from '@angular/core';
import { UIDisplayField } from '../content/types/uidisplayfield.type';
import { ULComponent } from '../content/ulcomponent.component';
import {AppConfigService} from '../services/appconfigservice.service';
import {DataService} from '../services/dataservice.service';

/*  Decorator  */
@Component({
    moduleId: '',
    template: `


    <header [headerTitle]="headerTitle"></header>

    <subheader [subHeaderStatusFieldLabel]="subHeaderStatusFieldLabel" [subHeaderStatusFieldName]="subHeaderStatusFieldName" [subHeaderStatusValue]="subHeaderStatusValue" [subHeaderStatusDescription]="subHeaderStatusDescription"></subheader>
    <detail [detailFields]="detailFields" [detailDataObject]="dataObject"></detail>
    <detail-listview-container>
        <tabs></tabs>
        <search></search>
            <detail-listview-header></detail-listview-header>
            <detail-list-item></detail-list-item>
    </detail-listview-container>
    
    `,
    


})

export class GenericDetailComponent implements OnInit {
    /*  Variables  */
    @ViewChild('filterCount') filterCountEl: ElementRef;
    @ViewChild('PageEl') PageElemt: ElementRef;
    pageTitle: string = '';
    dataList:any[];
    imageWidth: number = 50;
    imageMargin: number = 2;
    showMoreCompany: boolean = false;
    selectAllcompay: boolean = false;
    showMorePlaceholder: number = 0;
    listFilter: string;
    quotes: any[];
    errorMessage: string;
    from: Date;
    customtodate: Date;
    filteredCount : any;
    //totalPageCount = { count: 0 };
    companyNameList: any[] = [];
    contactNameCount: number = 0;
    name: string;
    totalCount: number = 0;
    statusFilterList: any[] = [];
    nameFilterCount: any[] = [];
    statusFilterCount: any[] = [];
    statusCount: number = 0;
    columnSort: string;
    columnSortOptionsValue: string;
    status: string;
    highlightedDiv: number;
    changeGlyph: boolean = false;
    /* check box Status */
    rdStatus: string;
    chkStatusList: any[] = [];
    chkStatusList1: any[] = [];
    statusSlelectAll: any[] = [];
    /* checkbox company name */
    companyNameListFilter: any[] = [];
    chkNameListTemp: any[] = [];
    chkNameList: any[] = [];
    visibleMore: boolean = false;
    dateFilterOptions: string[] = [
        'Today',
        'Last 7 Days',
        'Last 30 Days',
        'Last 90 Days',
        'Last 365 Days',
        'Date Range'
    ];
    /* deep link url */
    parentURL: string = "";
    deepLinkUrl: any;
 //statusFilter: string[] = [
    //    "Draft",
    //    "Offered",
    //    "Accepted",
    //    "Expired",
    //    "ORDER SUBMITTED"      
    //];
    columSortOptions: string[] = ["Description", "Creation Date", "Quote Number", "Price"];
    /*  PBI - 2261 Quote List - Date filter*/
    myDatePickerOptions = {
        todayBtnTxt: 'Today',
        dateFormat: 'mm/dd/yyyy',
        firstDayOfWeek: 'mo',
        sunHighlight: true,
        inline: false,
        selectionTxtFontSize: '12px',
        componentDisabled: true,
        editableDateField: false
    };
    /*  PBI - 2569 Quote List - Sorting */
    selectedSortOption: any;
    totalItems: number = 0;
    currentPage: number = 1;
    itemsPerPage: number = 15;
    startIndex: number = 0;
    endIndex: number = 0;
    totalPages: number = 1;
    pagesArr: number[] = [];
    maxSize: number = 0;
    enableFwdBtn: boolean = false;
    enableBackBtn: boolean = false;
    detailFields:any;
    dataObject:any;
    sub:Subscription;
    subHeaderFields:any;
    subHeaderStatusFieldName:any;
    subHeaderStatusValue:any;
    subHeaderStatusDescription:any;
    subHeaderStatusFieldLabel: any;
    headerTitle: any;

    /*  Functions  */
    constructor(private _route: ActivatedRoute, private _logger:Logger, private _appConfigService:AppConfigService, private _dataService:DataService) { }

    onFiltered(Count: number) {
        this.totalCount = Count;
        // this.totalPages = (this.totalItems / this.itemsPerPage);
    }
    filterSelected() {
        this.totalCount = 7;
    }
    private Configuration() {

    }
    updateDate: any;
    udateHours: any;
    ngOnInit(): void { 

        this.sub = this._route.params.subscribe(
            params => {
                let id = +params['id'];
                this.detailFields = this._appConfigService.getDetailFields();
                this.subHeaderFields = this._appConfigService.getSubHeaderFields();
                this._dataService.getDetailDataObject(id)
                    .subscribe(
                    (data:any) => {
                        this.dataObject = data;
                        this.setSubHeaderFields();
                    },
                    (error:any) => this.errorMessage = <any>error);
                    });



    }

    setSubHeaderFields() {
        this.subHeaderStatusFieldName = this._appConfigService.getSubHeaderStatusFieldName();
        this.subHeaderStatusValue = this.dataObject[0][this._appConfigService.getSubHeaderStatusFieldName()];
        this.subHeaderStatusDescription = this.dataObject[0][this._appConfigService.getSubHeaderDescriptionFieldName()];
        this.subHeaderStatusFieldLabel = this._appConfigService.getSubHeaderStatusFieldLabel();
    }
    /* PAGINATION   */
    setPaginationProperties(filterCount?: number): void {
        this.setPageValues(filterCount);
        this.setPageIndexes();
        this.setNavigationBtn();
    }

    setPageValues(filterCount?: number) {

        this.totalItems = (filterCount == undefined ? this.totalCount : filterCount);
        this.totalPages = Math.ceil(this.totalItems / this.itemsPerPage);
        this.pagesArr = [];

        for (let num = 1; num <= this.totalPages; num++) {
            this.pagesArr.push(num);
        }
    }
    setPageIndexes() {
        this.startIndex = (this.currentPage - 1) * this.itemsPerPage;
        let tempEndindex = this.startIndex + this.itemsPerPage
        this.endIndex = (tempEndindex) > this.totalItems ? this.totalItems : tempEndindex;
    }

    public filterPageChange(pageNo: any, filterCount: number): void {
        this.currentPage = pageNo;
        this.setPaginationProperties(filterCount);

    };
    pageNavigationBtnClick(changeType?: string) {

        let _currentPage = this.currentPage;

        if (changeType == "NEXT") {
             _currentPage = Number(_currentPage.toString()) + 1;
            _currentPage = _currentPage < this.totalPages ? _currentPage : this.totalPages;
        }
        else if (changeType == "PREVIOUS") {
            _currentPage = _currentPage - 1 > 1 ? _currentPage - 1 : 1;
        }
        this.currentPage = _currentPage;
        this.setPageIndexes();
        this.setNavigationBtn();

    }

    setPage(pageNo: number) {

        this.currentPage = pageNo;
        this.setPageIndexes();
        this.setNavigationBtn();

    }


    setNavigationBtn(): void {
        this.enableFwdBtn = this.currentPage > 1 ? true : false;
        this.enableBackBtn = (this.totalPages > 0 && this.currentPage < this.totalPages) ? true : false;
    }

    trigger(): void {
        this._logger.info('trigger');
        this.filterCountEl.nativeElement.focus()
    }
    /* Date text box Empty */
    textFromDate: any = new ElementRef({ selectionDayTxt: "" })
    textToDate: any = new ElementRef({ selectionDayTxt: "" })
    @ViewChild('fromDate') dateFrom: ElementRef ;
    @ViewChild('toDate') dateTo: ElementRef;
    dateRangeCheck: boolean = false;
    /*End */    
    OnDateRangeFilterSelection(value: string): void {
        let copy = this.getCopyOfOptions();
        if (value == "Today" || value == "Last 7 Days" || value == "Last 30 Days" || value == "Last 90 Days" || value == "Last 365 Days")
            this.dateRangeCheck = false;
        if (value == "Date Range") {
            this.dateRangeCheck = true;
            this.from = undefined;
            this.customtodate = undefined;
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
        }
        /* Date text box Empty */
        if (this.dateRangeCheck == true) {
            copy.componentDisabled = false;
            this.myDatePickerOptions = copy;
            
        }
        else {
            this.textFromDate = this.dateFrom;
            this.textToDate = this.dateTo;
            this.textFromDate.selectionDayTxt = "";
            this.textToDate.selectionDayTxt = "";
            copy.componentDisabled = true;
            this.myDatePickerOptions = copy;
        }
        this.triggerFocus();
        /* End  */
    }

    /*Select All Atatus */
    checkAllSwitch: boolean = false;
    checkAllStatus(): void {
        this.checkAllSwitch = !this.checkAllSwitch;

        this.statusSlelectAll = []
        for (var i = 0; i < this.statusFilterList.length; i++) {
            this.statusSlelectAll.push(this.statusFilterList[i].toLowerCase());
        }
        this.chkStatusList1 = this.statusSlelectAll
        this.chkStatusList = this.chkStatusList1
        this.triggerFocus();
    }
    /* Select All Company */
    nameSelectAll: any[] = [];
    chkNameAll: boolean = false;
    selectAllCompay(): void {
        this.chkNameAll = !this.chkNameAll;
        this.nameSelectAll = [];
        for (var i = 0; i < this.companyNameList.length; i++) {
            this.nameSelectAll.push(this.companyNameList[i].toLowerCase());
        }
        this.chkNameListTemp = this.nameSelectAll;
        this.chkNameList = this.chkNameListTemp;
        this.triggerFocus();
    }
    /* Status Filter Checkbox */
    statusChecked(checked: boolean, value: string): void {

        if (checked == true) {
            this.chkStatusList.push(value.toLowerCase());
            this.chkStatusList1 = this.chkStatusList;
        }
        else {
            for (var i = 0; i < this.chkStatusList.length; i++) {
                if (this.chkStatusList[i] == value.toLowerCase()) {
                    this.chkStatusList.splice(i, 1);
                }
            }
            this.chkStatusList1 = this.chkStatusList;
        }
        this.triggerFocus();
    }

    /*Company Name Filtered Checkbox */
    companyNameChecked(checked: boolean, name: string) {
        if (checked == true) {
            this.chkNameList.push(name.toLowerCase());
            this.chkNameListTemp = this.chkNameList;
        }
        else {
            for (var i = 0; i < this.chkNameList.length; i++) {
                if (this.chkNameList[i] == name.toLowerCase()) {
                    this.chkNameList.splice(i, 1);
                }
            }
            this.chkNameListTemp = this.chkNameList;
        }
        this.triggerFocus();
    }


    /* Filter List and count */
    companyClass: string;
    
    filterList(): void {
        for (var i = 0; i < this.quotes.length; i++) {
           

            /*get the Distinct Company name */

            if (this.companyNameList.indexOf(this.quotes[i].CompanyName) === -1) {
                this.companyNameList.push(this.quotes[i].CompanyName);
                this.chkNameList.push(this.quotes[i].CompanyName.toLowerCase());
                this.chkNameListTemp = this.chkNameList;
            }
           
            /* get the Distinct Status Name */

            if (this.statusFilterList.indexOf(this.quotes[i].QuoteStatus) === -1) {
                this.statusFilterList.push(this.quotes[i].QuoteStatus);
                this.chkStatusList.push(this.quotes[i].QuoteStatus.toLowerCase());
                this.chkStatusList1 = this.chkStatusList;                       
            }
        }
        if (this.companyNameList!== null && this.companyNameList.length > 5) {
            this.companyClass = "companyContainer";
            this.visibleMore = true;
        }
        /* count for Status */
        for (var l = 0; l < this.statusFilterList.length; l++) {
            this.statusCount = 0;
            let displayText: string;
            let displayCode: number;
            for (var m = 0; m < this.quotes.length; m++) {
                if (this.statusFilterList[l] == this.quotes[m].QuoteStatus) {
                    this.statusCount = this.statusCount + 1;
                    this.status = this.quotes[m].QuoteStatus;
                    displayText = this.quotes[m].QuoteStatus;
                }
            }
            /* Assigning the status display code based on the status */
            if (displayText == "Draft") {
                displayCode = 0;
            } else if (displayText == "Offered") {
                displayCode = 1;
            } else if (displayText == "Accepted") {
                displayCode = 2;
            } else {
                displayCode = 3;
            }
            this.statusFilterCount.push({ "Name": this.status, "displayText": displayText, "QuotesStatusCode": displayCode, "Count": this.statusCount })
            /* sorting the status based on the display status code */
            this.statusFilterCount.sort((a: any, b: any) => {
                return a.QuotesStatusCode - b.QuotesStatusCode;
            });
        }
        /* count for customer Name */
        for (var j = 0; j < this.companyNameList.length; j++) {
            this.contactNameCount = 0;
            for (var k = 0; k < this.quotes.length; k++) {
                if (this.companyNameList[j] == this.quotes[k].CompanyName) {
                    this.contactNameCount = this.contactNameCount + 1;
                    this.name = this.quotes[k].CompanyName;
                }
            }
            this.nameFilterCount.push({ "Name": this.name, "Count": this.contactNameCount })
        }
    }

    //Custom Date Filter- 2261/2387 
    onFromDateChanged(event: any) {
        this.from = new Date(event.formatted);
        //Added 'FROM' text as typeOfdateSelection flag to show 'FROM' label when date validation fails
        this.dateRangValidation('FROM');
        this.triggerFocus();
        
    }

    onToDateChanged(event: any) {
        this.customtodate = new Date(event.formatted);
        //Added 'TO' text as typeOfdateSelection flag to show 'TO' label when date validation fails
        this.dateRangValidation('TO');
        this.triggerFocus();
    }
    //Added method Show From/To text when user selected date fails validation
    private OnDateValidationFails(typeOfDate: string): void {
        if (typeOfDate === 'FROM') {
            /* Empty Custom date textbox */
            this.textFromDate = this.dateFrom;
            this.textFromDate.selectionDayTxt = "";
            this.textFromDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.from = undefined;
            /* End */
        }
        else if (typeOfDate === 'TO') {
            /* Empty Custom date textbox */
            this.textToDate = this.dateTo;
            this.textToDate.selectionDayTxt = "";
            this.textToDate.selectedDate = { year: 0, month: 0, day: 0 };
            this.customtodate = undefined;

            /* End */
        }
    }

    //Validation for Date Filter
    dateRangValidation(typeOfDate: string) {
        let currentDate = new Date();
        let ToDate = new Date(this.customtodate);
        let fromDate = new Date(this.from);
        if (fromDate > ToDate) {
            alert('From Date should be less than or equal to To Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (ToDate < fromDate) {
            alert('To Date should be greater than or equal to From Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < fromDate) {
            alert('From Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }
        else if (currentDate < ToDate) {
            alert('To Date should be less than or equal to Current Date');
            this.OnDateValidationFails(typeOfDate);
            return false;
        }               
    }
    // PBI- 2638 Column Sorting 
    changeSorting(value: string, selectedOption: string) {
        this.columnSort = value;
        this.columnSortOptionsValue = selectedOption;
    }
    // PBI- 2569 Dropdown Sorting
    changeSelect(selectedOption: string) {        
        this.selectedSortOption.sortOptionName = selectedOption;
        this.columnSortOptionsValue = null;
        this.filterPageChange(1, this.filterCountEl.nativeElement.value);         
    }

    //Change background color on div click
    toggleHighlight(newValue: number) {
        if (this.highlightedDiv === newValue) {
            this.highlightedDiv = 4;
            this.changeSorting('DES', this.columSortOptions[newValue])
        }
        else {
            this.highlightedDiv = newValue;
            this.changeSorting('ASC', this.columSortOptions[newValue])
        }
    }

    //ToolTip State Change//
    tooltipStateChanged(state: boolean): void {
        this._logger.info(`Tooltip is open: ${state}`);
    }
    /*Enable diseabled date */
    getCopyOfOptions() {
        return JSON.parse(JSON.stringify(this.myDatePickerOptions));
    }
    /*Page reset on the event trigger*/
    triggerFocus(): void {
        setTimeout(() => this.filterCountEl.nativeElement.focus(), 5);
    }
    /*Deep Linking order  */
    deepLinkURL(orderNo: number, psn: number): void   {
        let details = "URL/Orders/OrderDetail/" + orderNo + "-" + psn;
        parent.postMessage(details, this.parentURL);
    }
    quoteLinkURL(quote: number): void {
        let quotes = "Internal/Quotes/QuotesDetail/" + quote;
        parent.postMessage(quotes, this.parentURL);
    }
}
