"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require('@angular/core');
/* Decorator */
var ListContainerComponent = (function () {
    function ListContainerComponent() {
        this.pageTitle = '';
        this.fullWidth = false;
    }
    ListContainerComponent.prototype.ngOnInit = function () {
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], ListContainerComponent.prototype, "fullWidth", void 0);
    ListContainerComponent = __decorate([
        core_1.Component({
            selector: 'list-container',
            moduleId: '',
            template: "\n<section [class]=\"fullWidth ? 'list-container-component-worefiner' : 'list-container-component'\">\n\n    <!--determines where the content actually goes.-->\n    <ng-content></ng-content>\n\n\n</section>    \n    ",
            styles: ["\n    .list-container-component {\n  width: 83%;\n  height: 100%;\n  min-height: 945px;\n  float: left; }\n\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], ListContainerComponent);
    return ListContainerComponent;
}());
exports.ListContainerComponent = ListContainerComponent;
//# sourceMappingURL=list-container.component.js.map