﻿/*  System Imports  */
import { Component, AfterViewInit, Input, Output, EventEmitter } from '@angular/core';

/* Decorator */
@Component({
    selector: 'list-item',
    moduleId: '',
    template: `
<section class="list-item-component">
    
    <div class="list-item flex-container {{borderColorClass}}">

        <div class="list-item-col list-item-col-1">
            <div>
                <p></p>
            </div>
        </div>

            <div *ngFor="let column of columns; let i=index;" [class]="getColumnClasses(i)">
               <div *ngIf="column.type=='normal'">
                <p *ngIf="column.linkdata" [routerLink]="column.routerlink" (click)="largeValueLink(column.linkdata)" [innerHTML] = "column.value"></p>
                <p *ngIf="!column.linkdata" [innerHTML] = "column.value"></p>
                </div>




                    <div *ngIf="column.type == 'large'"class="list-item-description">
                        <h4 *ngIf="column.linkdata" [routerLink]="column.routerlink" (click)="largeValueLink(column.linkdata)" [tooltipHtml]="column.largeValue" [innerHTML] = "column.largeValue"></h4>
                        <h4 *ngIf="!column.linkdata" [tooltipHtml]="column.largeValue" [innerHTML] = "column.largeValue"></h4>
                        
                    </div>

                    <div *ngIf="column.type == 'large'"class="list-item-status">
                        <h6 [innerHTML] = "column.underValue" >
                            <span [innerHTML] = "column.statusValue" class="list-item-status-draft"></span>
                            <span class="middot">&#183;</span>
                            
                        </h6>
                    </div>



            </div>

           



    </div>

</section>    
    `,
    styles: [`
/* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.highlighted {
  color: yellow; }

.list-item-component {
  /*width: 100%;*/
  height: 100%;
  padding: 0 25px;
  background-color: #f0f3f7;
  border: solid 0 transparent; }
  .list-item-component .list-item {
    /*width: 100%;*/
    min-height: 95px;
    margin: 0 0 4px -4px;
    border: solid 1px #cbcdd1;
    border-left: solid 4px #4a92e2;
    color: #9ea6ba;
    background-color: #fff; }
    .list-item-component .list-item .list-item-col {
      border-right: solid 1px #cbcdd1; }
      .list-item-component .list-item .list-item-col div {
        padding: 0;
        text-align: center; }
        .list-item-component .list-item .list-item-col div h4 {
          min-height: 30px;
          margin-right: 20px;
          padding-bottom: 5px;
          cursor: pointer !important; }
          .list-item-component .list-item .list-item-col div h4:hover {
            color: #23527c;
            text-decoration: underline !important; }
        .list-item-component .list-item .list-item-col div h6 {
          text-transform: capitalize;
          color: #303741;
          padding: 0 20px 12px 0;
          border-top: solid 1px #cbcdd1; }
        .list-item-component .list-item .list-item-col div p {
          text-transform: capitalize;
          color: #303741;
          margin-top: 38px;
          text-align: center; }
    .list-item-component .list-item .list-item-col-1 {
      display: none; }
    .list-item-component .list-item .list-item-col-2 {
      width: 55%;
      /*padding: 15px 0 0 20px;*/ }
      .list-item-component .list-item .list-item-col-2 div {
        text-align: left;
        padding-left: 20px; }
      .list-item-component .list-item .list-item-col-2 .list-item-description {
        padding-top: 18px; }
      .list-item-component .list-item .list-item-col-2 .list-item-status {
        padding-top: 0; }
        .list-item-component .list-item .list-item-col-2 .list-item-status h6 {
          padding-top: 10px;
          color: #98a8bc; }
    .list-item-component .list-item .list-item-col-3 {
      width: 15%; }
    .list-item-component .list-item .list-item-col-4 {
      width: 15%; }
      .list-item-component .list-item .list-item-col-4 div p {
        color: #337ab7;
        cursor: pointer; }
        .list-item-component .list-item .list-item-col-4 div p:hover {
          text-decoration: underline; }
    .list-item-component .list-item .list-item-col-5 {
      width: 15%;
      border-right: solid 0 #cbcdd1; }
    .list-item-component .list-item .list-item-col-6 {
      display: none; }
    .list-item-component .list-item .highlighted {
      background-color: yellow; }
    
    `]
})

export class ListItemComponent implements AfterViewInit {

    pageTitle: string = '';
    @Input() borderColorClass:any;
    @Input() columns: any; 
    @Input() fieldNames: any[];
    @Output() linkEvent = new EventEmitter();
    ngAfterViewInit() {

    }
    getColumnClasses(i: number) {
        return ('list-item-col list-item-col-' + (i+2));
    }

    largeValueLink(data:any) {
        console.log(data);
        this.linkEvent.emit(data);
    }

    constructor() {

    }
}