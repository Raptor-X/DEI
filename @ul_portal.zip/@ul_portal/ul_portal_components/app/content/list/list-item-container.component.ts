﻿/*  System Imports  */
import { Component } from '@angular/core';

/* Decorator */
@Component({
    selector: 'list-item-container',
    moduleId: '',
    template: `
<section class="list-item-container-component">

    <!--determines where the content actually goes.-->
    <ng-content></ng-content>


</section>    
    `,
    styles: [`
/* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }


.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.highlighted {
  background-color: yellow !important; }

.list-item-container-component {
  width: 100%;
  height: 100%;
  min-height: 840px;
  padding: 25px 0;
  background-color: #f0f3f7; }
    
    `]
})

export class ListItemContainerComponent {
    pageTitle: string = '';
}