﻿/*  System Imports  */
import { Input, Component, Output, EventEmitter, OnChanges } from '@angular/core';
import { ULComponent } from '../../../app/content/ulcomponent.component';
declare var $: any;

/* Decorator */
@Component({
    selector: 'list-header',
    moduleId: '',
    template: `
<section class="list-header-component flex-container">

    <div class="list-header flex-container">

        <div class="header-col header-col-1">
            <div>
                <h6></h6>
            </div>
        </div>

        <div *ngFor="let column of columns; let i = index" [class]="getHeaderClass(i)">
            <div class="arrow-toggle">
                <h6 (click)="onSortHeader($event, column)">{{ column }}</h6>
            </div>
        </div>

        <div [class]="'header-col' + ' ' + 'header-col-' + (columns.length+2)">
            <div>
                <h6></h6>
            </div>
        </div>

    </div>


</section>    
    `,
    styles: [`
/* Color Variables */
/* UL Global Colors from the UL Brand Palette */
/* UL Global Colors for Specific Properties */
/* Colors Specific to myUL Portal */
/*NOT IN USE*/
/*Glyphicons*/
@font-face {
  font-family: 'Glyphicons Halflings';
  src: url("../content/fonts/glyphicons-halflings-regular.eot");
  src: url("../content/fonts/glyphicons-halflings-regular.eot?#iefix") format("embedded-opentype"), url("../content/fonts/glyphicons-halflings-regular.woff") format("woff"), url("../content/fonts/glyphicons-halflings-regular.ttf") format("truetype"), url("../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular") format("svg"); }

.glyphicon {
  position: relative;
  top: 1px;
  display: inline-block;
  font-family: 'Glyphicons Halflings';
  -webkit-font-smoothing: antialiased;
  font-style: normal;
  font-weight: normal;
  line-height: 1; }

.caret {
  display: inline-block;
  width: 0;
  height: 0;
  margin-left: 2px;
  vertical-align: middle;
  border-top: 4px solid #000000;
  border-right: 4px solid transparent;
  border-bottom: 0 dotted;
  border-left: 4px solid transparent;
  content: ""; }

/*$neutral-gray-border: #666;

.neutral-gray-border {
    border: solid 1px $neutral-gray-border;
}*/
.list-header-component {
  width: 100%;
  height: 50px;
  background-color: #e6e9ed;
  border: solid 1px #cbcdd1;
  border-top: solid 0 transparent;
  border-left: solid 0 transparent;
  border-right: solid 0 transparent; }
  .list-header-component .list-header {
    /*width: 95%;*/
    /*width: 100%;*/
    height: 50px;
    /*margin: 0 20px 4px 20px;*/
    padding: 0 20px;
    color: #9ea6ba;
    background-color: transparent; }
    .list-header-component .list-header .header-col {
      height: 50px;
      float: left;
      border-right: solid 1px #cbcdd1;
      color: #9ea6ba;
      text-align: center;
      cursor: pointer; }
      .list-header-component .list-header .header-col div {
        padding: 10px 0 0 0;
        text-align: center; }
        .list-header-component .list-header .header-col div :hover {
          /*background: url('../../../content/images/turndown-arrow.png') 95% 50% no-repeat $myul-button-hover;*/
          background-color: #d3d6db; }
        .list-header-component .list-header .header-col div :active {
          /*background: url('../../../content/images/turndown-arrow.png') 95% 50% no-repeat $myul-button-hover;*/
          background-color: #d3d6db; }
        .list-header-component .list-header .header-col div h6 {
          text-transform: capitalize;
          color: #303741;
          width: auto;
          display: inline-block;
          background: url("../../../content/images/turndown-arrow-down.png") 95% 50% no-repeat transparent;
          padding: 8px 20px 8px 8px;
          border-radius: 3px;
          z-index: 9999; }
        .list-header-component .list-header .header-col div .h6-toggle {
          background: url("../../../content/images/turndown-arrow-up.png") 95% 50% no-repeat #d3d6db; }
    .list-header-component .list-header .header-col-1 {
      display: none; }
    .list-header-component .list-header .header-col-2 {
      width: 55%;
      /*padding-left: 20px;*/ }
      .list-header-component .list-header .header-col-2 div {
        text-align: left; }
    .list-header-component .list-header .header-col-3 {
      width: 15%; }
    .list-header-component .list-header .header-col-4 {
      width: 15%; }
    .list-header-component .list-header .header-col-5 {
      width: 15%;
      border-right: solid 0 transparent; }
    .list-header-component .list-header .header-col-6 {
      display: none; }
    
    `]
})

export class ListHeaderComponent extends ULComponent {
    @Input() columns: any[];
    @Output() onSortHeaderEvent = new EventEmitter<any>();
    @Input() headerClass:any = '';
    constructor() {
        super();
    }
    onSortHeader(event: any, data: any) {

        // Adds turndown arrow up/down toggle.
        var target = event.target || event.srcElement || event.currentTarget;
        $(target).toggleClass("h6-toggle");


        var obj: any = new Object();
        obj.event = event;
        obj.data = data;
        this.onSortHeaderEvent.emit(obj);
    }
    getHeaderClass(index: number) {
        return 'header-col' + ' ' + 'header-col-' + (index + 2)
    }

}