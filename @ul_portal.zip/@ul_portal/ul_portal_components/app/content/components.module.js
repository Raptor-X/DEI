"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var router_1 = require('@angular/router');
var common_1 = require('@angular/common');
var forms_1 = require('@angular/forms');
// import { ProductDetailGuard } from './product-guard.service';
var header_component_1 = require('../../app/header/header.component');
//import { HeaderComponent} from 'ul_portal_components/components/header/header.component';
var error_module_1 = require('../Error/error.module');
//import { ComponentsModule } from 'ul_portal_components/components/components.module';
var content_component_1 = require('../../app/content/content.component');
var generic_list_component_1 = require('../content/generic-list.component');
var refiner_container_component_1 = require('../content/refiners/refiner-container.component');
var refiner_component_1 = require('../content/refiners/refiner.component');
var search_component_1 = require('../content/search/search.component');
var list_container_component_1 = require('../content/list/list-container.component');
var list_header_component_1 = require('../content/list/list-header.component');
var list_item_container_component_1 = require('../content/list/list-item-container.component');
var list_item_component_1 = require('../content/list/list-item.component');
var generic_detail_component_1 = require('../content/generic-detail.component');
var subheader_component_1 = require('../content/detail/subheader.component');
var detail_component_1 = require('../content/detail/detail.component');
var tabs_component_1 = require('../content/detail/tabs.component');
var detail_listview_container_component_1 = require('../content/detail/detail-listview-container.component');
var detail_listview_header_component_1 = require('../content/detail/detail-listview-header.component');
var detail_tabview_people_component_1 = require('../content/detail/detail-tabview-people.component');
var detail_list_item_component_1 = require('../content/detail/detail-list-item.component');
var dropdown_component_1 = require('../content/form/dropdown.component');
var paging_buttons_component_1 = require('../content/form/paging-buttons.component');
var single_refiner_component_1 = require('../content/refiners/single-refiner.component');
var my_date_picker_module_1 = require('mydatepicker/dist/my-date-picker.module');
var ng2_charts_1 = require('ng2-charts/ng2-charts');
var loading_spinner_component_1 = require('../misc/loading-spinner.component');
var tooltip_module_1 = require('../content/tooltip/tooltip.module');
var ComponentsModule = (function () {
    function ComponentsModule() {
    }
    ComponentsModule = __decorate([
        core_1.NgModule({ imports: [
                common_1.CommonModule,
                forms_1.FormsModule,
                error_module_1.ErrorHandlerModule,
                my_date_picker_module_1.MyDatePickerModule,
                ng2_charts_1.ChartsModule,
                tooltip_module_1.TooltipModule,
                router_1.RouterModule
            ],
            declarations: [
                header_component_1.HeaderComponent,
                content_component_1.ContentComponent,
                generic_list_component_1.GenericListComponent,
                refiner_container_component_1.RefinerContainerComponent,
                refiner_component_1.RefinerComponent,
                search_component_1.SearchComponent,
                list_container_component_1.ListContainerComponent,
                list_header_component_1.ListHeaderComponent,
                list_item_container_component_1.ListItemContainerComponent,
                list_item_component_1.ListItemComponent,
                generic_detail_component_1.GenericDetailComponent,
                subheader_component_1.SubheaderComponent,
                detail_component_1.DetailsComponent,
                tabs_component_1.TabsComponent,
                detail_listview_container_component_1.DetailListViewContainerComponent,
                detail_listview_header_component_1.DetailListViewHeaderComponent,
                detail_list_item_component_1.DetailListItemComponent,
                dropdown_component_1.DropdownComponent,
                paging_buttons_component_1.PagingButtonsComponent,
                detail_tabview_people_component_1.DetailTabViewPeopleComponent,
                single_refiner_component_1.SingleRefinerComponent,
                loading_spinner_component_1.LoadingSpinnerComponent
            ],
            exports: [
                header_component_1.HeaderComponent,
                content_component_1.ContentComponent,
                generic_list_component_1.GenericListComponent,
                refiner_container_component_1.RefinerContainerComponent,
                refiner_component_1.RefinerComponent,
                search_component_1.SearchComponent,
                list_container_component_1.ListContainerComponent,
                list_header_component_1.ListHeaderComponent,
                list_item_container_component_1.ListItemContainerComponent,
                list_item_component_1.ListItemComponent,
                generic_detail_component_1.GenericDetailComponent,
                subheader_component_1.SubheaderComponent,
                detail_component_1.DetailsComponent,
                tabs_component_1.TabsComponent,
                detail_listview_container_component_1.DetailListViewContainerComponent,
                detail_listview_header_component_1.DetailListViewHeaderComponent,
                detail_list_item_component_1.DetailListItemComponent,
                dropdown_component_1.DropdownComponent,
                paging_buttons_component_1.PagingButtonsComponent,
                detail_tabview_people_component_1.DetailTabViewPeopleComponent,
                single_refiner_component_1.SingleRefinerComponent,
                loading_spinner_component_1.LoadingSpinnerComponent
            ]
        }), 
        __metadata('design:paramtypes', [])
    ], ComponentsModule);
    return ComponentsModule;
}());
exports.ComponentsModule = ComponentsModule;
//# sourceMappingURL=components.module.js.map