﻿/*  System Imports  */
import {  Component, Input, Output, EventEmitter, ElementRef, NgModule, trigger, state, style, animate, transition, OnInit, ViewChild } from '@angular/core';
declare var $:any;
/* Decorator */
@Component({
    selector: 'refiner',
    moduleId: '',
    templateUrl: '../../../app/content/refiners/refiner.component.html',
    styleUrls: ['../../../app/content/refiners/refiner.component.css'],
    animations: [
        trigger('shrinkOut', [
            state('in', style({ height: '*' })),
            transition('* => void', [
                style({ height: '*' }),
                animate(250, style({ height: 0 }))
            ])
        ])
    ]
})

export class RefinerComponent implements OnInit   {
    pageTitle: string = '';
    defaultCheckboxStyle: string = 'refiner-checkbox-on';
    defaultCheckboxName: string;
	@Input() id:string;
    @Input() refinerType: string;
    @Input() refinerItems: any[];
	@ViewChild('turndownarrow') private turndown : ElementRef;
	@ViewChild('datacontainer') private datacontainer : ElementRef;
    selectedRefinerItems: any[];
    refinerItemCount:number;
    @Output() onChangeEvent = new EventEmitter<any>();
    refinerUpdateButtonText:string = "Show More";
    refinerUpdateButtonTextLess:string = "Show Less";
    //@Input() type: string;

    //selectItem(value: string) {
    //    this.state = (this.state === 'inactive' ? 'active' : 'inactive');
    //    this.select.emit(value);
    //}

    ngOnInit() {
        if (this.id == 'statusRefiner') {
            this.defaultCheckboxName = 'View All';
        } else if (this.id == 'companiesRefiner') {
            this.defaultCheckboxName = 'Select All';
        }

        for (var i=0; i<this.refinerItems.length; i++) {
                this.refinerItems[i].CSSClass = 'refiner-checkbox-on';
        }
        this.selectedRefinerItems = new Array();
		this.selectedRefinerItems = this.refinerItems.slice();
        if (this.refinerItems.length < 5) {
            this.refinerItemCount = this.refinerItems.length;
        } else {
            this.refinerItemCount = 5;
        }
        
    }
	toggleSlide() {
		if ($(this.datacontainer.nativeElement).css('display')== 'none') {
		  $(this.datacontainer.nativeElement).slideDown( "slow", function() {
				// Animation complete.
			});
		} else {
		  $(this.datacontainer.nativeElement).slideUp( "slow", function() {
				// Animation complete.
			});
		}
	}
    updateRefinerItemCount() {
        this.refinerItemCount = this.refinerItems.length;
    }
    subtractRefinerItemCount() {
        if (this.refinerItems.length > 4) {
            this.refinerItemCount = 5;
        } else {
            this.refinerItemCount = this.refinerItems.length;
        }
        
    }
    checkboxSelected(event:any, refinerItem:any) {
        console.log("Before:" + JSON.stringify(this.selectedRefinerItems));        
        refinerItem.CSSClass = (refinerItem.CSSClass == 'refiner-checkbox-off' ? 'refiner-checkbox-on' : 'refiner-checkbox-off');
        var target = event.target || event.srcElement || event.currentTarget;
        target = target.nextElementSibling;
        if (target.checked) {
            target.checked = false;
        } else {
            target.checked = true;
        }
        if (target.checked) { 
            this.selectedRefinerItems.push(refinerItem);
        } else {
            this.removeByAttr(this.selectedRefinerItems, "label", refinerItem.label);
        }
        console.log("After: " + JSON.stringify(this.selectedRefinerItems));
        this.onChangeEvent.emit(this.selectedRefinerItems);

        if (this.selectedRefinerItems.length < this.refinerItems.length && this.selectedRefinerItems.length != 0) {
            this.defaultCheckboxStyle = 'refiner-checkbox-moderate';
        } else if (this.selectedRefinerItems.length >= this.refinerItems.length && this.selectedRefinerItems.length != 0) {
            this.defaultCheckboxStyle = 'refiner-checkbox-on';
        } else {
            this.defaultCheckboxStyle = 'refiner-checkbox-off';
        }
    }

    removeByAttr(arr:any, attr:any, value:any){
            var i = arr.length;
            while(i--){
            if( arr[i] 
                && arr[i].hasOwnProperty(attr) 
                && (arguments.length > 2 && arr[i][attr] === value ) ){ 

                arr.splice(i, 1);                
            }
            }
            return arr;
    }    

    toggleCheckbox() {
        if (this.selectedRefinerItems.length == 0 || this.defaultCheckboxStyle == 'refiner-checkbox-moderate') {
            this.selectAll();
            this.defaultCheckboxStyle = 'refiner-checkbox-on';
        } else if (this.selectedRefinerItems.length == this.refinerItems.length) {
            this.selectNone();
            this.defaultCheckboxStyle = 'refiner-checkbox-off';
        }
    }

    selectAll() {
        for (var i=0; i<this.refinerItems.length; i++) {
                this.refinerItems[i].CSSClass = 'refiner-checkbox-on';
        }		
        var checkboxes = document.getElementsByTagName('input');
        for (var i = 0; i < checkboxes.length; i++) {
             if (checkboxes[i].type == 'checkbox' && checkboxes[i].className.indexOf(this.id) > -1) {
                 checkboxes[i].checked = true;
             }
         }
         this.selectedRefinerItems = this.refinerItems.slice();
         this.onChangeEvent.emit(this.selectedRefinerItems);
         return false;
    }
    selectNone() {
		for (var i=0; i<this.refinerItems.length; i++) {
                this.refinerItems[i].CSSClass = 'refiner-checkbox-off';
        }
        var checkboxes = document.getElementsByTagName('input');
        for (var i = 0; i < checkboxes.length; i++) {
             if (checkboxes[i].type == 'checkbox' && checkboxes[i].className.indexOf(this.id) > -1) {
                 checkboxes[i].checked = false;
             }
         }
         this.selectedRefinerItems = new Array();
         this.onChangeEvent.emit(this.selectedRefinerItems);
         return false;
    }	
}
