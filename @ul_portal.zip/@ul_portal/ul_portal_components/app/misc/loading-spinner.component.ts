import { Component, Input, OnInit } from '@angular/core';
import { ULComponent } from '../../app/content/ulcomponent.component';

/* Decorator */
@Component({
    selector: 'loading-spinner',
    moduleId: '',
    template: `
        <img src="images/preload.gif" />
    `,
    styles: [`
        img {
            margin: auto;
            display: block;
            position: relative;
            top: 20px; 
        }
    `]
})

export class LoadingSpinnerComponent extends ULComponent implements OnInit {

    ngOnInit() {
        
    }
}