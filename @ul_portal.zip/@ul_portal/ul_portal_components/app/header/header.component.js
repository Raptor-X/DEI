"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require('@angular/core');
var ulcomponent_component_1 = require('../../app/content/ulcomponent.component');
/* Decorator */
var HeaderComponent = (function (_super) {
    __extends(HeaderComponent, _super);
    function HeaderComponent() {
        _super.apply(this, arguments);
        this.headerBreadCrumb = '';
        this.headerTitle = '';
        this.headerSubTitle = '';
        this.dateEvenWithBreadCrumbs = false;
        this.dateClass = "header-date";
    }
    HeaderComponent.prototype.ngOnInit = function () {
        if (this.dateEvenWithBreadCrumbs) {
            this.dateClass = "header-date header-date-icon-up";
        }
    };
    HeaderComponent.prototype.getDateClass = function () {
        return this.dateClass;
    };
    HeaderComponent.prototype.tooltipStateChanged = function (state) {
        console.log("Tooltip is opens: " + state);
    };
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], HeaderComponent.prototype, "headerBreadCrumb", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], HeaderComponent.prototype, "headerTitle", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', String)
    ], HeaderComponent.prototype, "headerSubTitle", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], HeaderComponent.prototype, "updateDate", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Object)
    ], HeaderComponent.prototype, "updateHours", void 0);
    __decorate([
        core_1.Input(), 
        __metadata('design:type', Boolean)
    ], HeaderComponent.prototype, "dateEvenWithBreadCrumbs", void 0);
    HeaderComponent = __decorate([
        core_1.Component({
            selector: 'header',
            moduleId: '',
            template: "\n<section class=\"row header-component\">\n    <div class=\"row header-breadcrumb\">\n        <h5 [innerHTML]=\"headerBreadCrumb\"></h5>\n    </div>\n    <div class=\"row header-title-date\">\n        <div class=\"header-title\">\n\n            <h1>{{ headerSubTitle }}</h1>\n\n            <h1>{{ headerTitle }}</h1>\n\n        </div>\n        <div [class]=\"getDateClass()\" *ngIf=\"updateDate\">\n            <div class=\"header-date-text\">\t\t\t\n                <div class=\"header-date-text-label\"><h5>Last Updated</h5>  {{updateDate | date:'mediumDate' }} at {{updateHours |date:'shortTime'}}</div>\n                <span style=\"cursor:pointer\" class=\"glyphicon glyphicon-info-sign\" [tooltipHtml]=\"toolTipTemplate\" (tooltipStateChanged)=\"tooltipStateChanged($event)\"></span>\n            </div>\n        </div>\n    </div>\n</section>\n    <template #toolTipTemplate let-model=\"model\" class=\"tooltip-template\" style=\"color:gainsboro\">\n        <h5 class=\"h5-tooltip\">Why am i seeing this?</h5>\n        <h6 class=\"h6-tooltip\">If you have a concern about this data, please contact the</h6>\n        <h6 class=\"h6-tooltip\"><u>UL Customer Support Center.</u></h6>\n    </template>    \n    ",
            styles: ["\n    /* Color Variables */\n/* UL Global Colors from the UL Brand Palette */\n/* UL Global Colors for Specific Properties */\n/* Colors Specific to myUL Portal */\n/*NOT IN USE*/\n/*Glyphicons*/\n@font-face {\n  font-family: 'Glyphicons Halflings';\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot\");\n  src: url(\"../content/fonts/glyphicons-halflings-regular.eot?#iefix\") format(\"embedded-opentype\"), url(\"../content/fonts/glyphicons-halflings-regular.woff\") format(\"woff\"), url(\"../content/fonts/glyphicons-halflings-regular.ttf\") format(\"truetype\"), url(\"../content/fonts/glyphicons-halflings-regular.svg#glyphicons-halflingsregular\") format(\"svg\"); }\n\n.glyphicon {\n  position: relative;\n  top: 1px;\n  display: inline-block;\n  font-family: 'Glyphicons Halflings';\n  -webkit-font-smoothing: antialiased;\n  font-style: normal;\n  font-weight: normal;\n  line-height: 1; }\n\n.caret {\n  display: inline-block;\n  width: 0;\n  height: 0;\n  margin-left: 2px;\n  vertical-align: middle;\n  border-top: 4px solid #000000;\n  border-right: 4px solid transparent;\n  border-bottom: 0 dotted;\n  border-left: 4px solid transparent;\n  content: \"\"; }\n\n/*$neutral-gray-border: #666;\n\n.neutral-gray-border {\n    border: solid 1px $neutral-gray-border;\n}*/\nheader {\n  /*border: solid 10px red !important;*/ }\n\n.header-date-icon-up {\n  margin-top: -15px !important; }\n\n.header-component {\n  height: 74px;\n  padding: 22px 27px; }\n\n.header-breadcrumb {\n  height: 35px; }\n  .header-breadcrumb h5 {\n    padding-left: 2px; }\n\n.header-title {\n  float: left; }\n\n.header-date {\n  margin-top: 19px;\n  float: right; }\n  .header-date * {\n    display: inline; }\n\n.header-date-text {\n  vertical-align: bottom; }\n\n.header-date-icon {\n  cursor: pointer; }\n\n.row {\n  width: auto; }\n\n    "]
        }), 
        __metadata('design:paramtypes', [])
    ], HeaderComponent);
    return HeaderComponent;
}(ulcomponent_component_1.ULComponent));
exports.HeaderComponent = HeaderComponent;
//# sourceMappingURL=header.component.js.map