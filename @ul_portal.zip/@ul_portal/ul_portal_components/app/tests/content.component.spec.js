"use strict";
var testing_1 = require('@angular/core/testing');
var content_component_1 = require('../../app/content/content.component');
describe('ContentComponent', function () {
    var comp;
    var fixture;
    var de;
    var el;
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [content_component_1.ContentComponent],
        });
        testing_1.TestBed.compileComponents().then(function () {
            fixture = testing_1.TestBed.createComponent(content_component_1.ContentComponent);
            comp = fixture.componentInstance; // ContentComponent test instance
        });
    }));
    it('Component Exists in Current Context', function () {
        expect(comp).toBeDefined;
    });
});
//# sourceMappingURL=content.component.spec.js.map