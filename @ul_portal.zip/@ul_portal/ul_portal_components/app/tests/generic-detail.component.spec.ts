import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from "@angular/platform-browser-dynamic/testing";
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By }              from '@angular/platform-browser';
import { DebugElement }    from '@angular/core';

import { GenericDetailComponent } from '../../app/content/generic-detail.component';


describe('GenericDetailComponent', () => {

  let comp:    GenericDetailComponent;
  let fixture: ComponentFixture<GenericDetailComponent>;
  let de:      DebugElement;
  let el:      HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenericDetailComponent ], // declare the test component
    });
    TestBed.compileComponents().then(() => {
        fixture = TestBed.createComponent(GenericDetailComponent);
        comp = fixture.componentInstance; // GenericDetailComponent test instance
        
        
    });
  }));

   it('Component Exists in Current Context', () => {
            expect(comp).toBeDefined
    });
});