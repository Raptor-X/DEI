"use strict";
var testing_1 = require('@angular/core/testing');
var generic_list_component_1 = require('../../app/content/generic-list.component');
describe('GenericListComponent', function () {
    var comp;
    var fixture;
    var de;
    var el;
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [generic_list_component_1.GenericListComponent],
        });
        testing_1.TestBed.compileComponents().then(function () {
            fixture = testing_1.TestBed.createComponent(generic_list_component_1.GenericListComponent);
            comp = fixture.componentInstance; // GenericListComponent test instance
        });
    }));
    it('Component Exists in Current Context', function () {
        expect(comp).toBeDefined;
    });
});
//# sourceMappingURL=generic-list.component.spec.js.map