"use strict";
var testing_1 = require('@angular/core/testing');
var detail_list_item_component_1 = require('../../app/content/detail/detail-list-item.component');
describe('ContentComponent (inline template)', function () {
    var comp;
    var fixture;
    var de;
    var el;
    beforeEach(testing_1.async(function () {
        testing_1.TestBed.configureTestingModule({
            declarations: [detail_list_item_component_1.DetailListItemComponent],
        });
        /*TestBed.compileComponents().then(() => {
            fixture = TestBed.createComponent(DetailListItemComponent);
            comp = fixture.componentInstance; // DetailListItemComponent test instance
            // query for the title <h1> by CSS element selector
            de = fixture.debugElement.query(By.css('h1'));
            el = de.nativeElement;
        });*/
    }));
    /* it('should display original title', () => {
             expect(el.textContent).toContain('Test Title');
     });*/
    describe('Meaningful Test', function () {
        it('1 + 1 => 2', function () {
            expect(1 + 1).toBe(2);
        });
    });
});
//# sourceMappingURL=detail-list-item.component.spec.js.map