"use strict";
var testing_1 = require("@angular/platform-browser-dynamic/testing");
var testing_2 = require('@angular/core/testing');
testing_2.TestBed.initTestEnvironment(testing_1.BrowserDynamicTestingModule, testing_1.platformBrowserDynamicTesting());
//# sourceMappingURL=karmashim.js.map