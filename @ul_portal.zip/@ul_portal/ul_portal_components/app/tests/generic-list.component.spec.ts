import {BrowserDynamicTestingModule, platformBrowserDynamicTesting} from "@angular/platform-browser-dynamic/testing";
import { ComponentFixture, TestBed, async } from '@angular/core/testing';
import { By }              from '@angular/platform-browser';
import { DebugElement }    from '@angular/core';
import { GenericListComponent } from '../../app/content/generic-list.component';


describe('GenericListComponent', () => {

  let comp:    GenericListComponent;
  let fixture: ComponentFixture<GenericListComponent>;
  let de:      DebugElement;
  let el:      HTMLElement;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenericListComponent ], // declare the test component
    });
    TestBed.compileComponents().then(() => {
        fixture = TestBed.createComponent(GenericListComponent);
        comp = fixture.componentInstance; // GenericListComponent test instance
        
        
    });
  }));

   it('Component Exists in Current Context', () => {
            expect(comp).toBeDefined
    });
});