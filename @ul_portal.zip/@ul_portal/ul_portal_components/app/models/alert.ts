﻿
/**
  interface - Allow to display alert list
*/
export interface IAlert {
    Id: number;
    DisplayEventTypeText: string;
    DisplayEntityTypeText: string;
    EntityNumber: string;
    Description: string 
    Psn: string;
    TimeStamp: Date
}

