﻿$(document).ready(function () {

    $.postMessage(
        "Success",
        parentURL,
        parent
        );
})