﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Optimization;
using System.Web.Routing;
using UL.IO.Shared.Utilities;

namespace MyUL.Samples
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            FilterConfig.RegisterGlobalFilters(GlobalFilters.Filters);
            RouteConfig.RegisterRoutes(RouteTable.Routes);
            BundleConfig.RegisterBundles(BundleTable.Bundles);
            Microsoft.ApplicationInsights.Extensibility.TelemetryConfiguration.Active.InstrumentationKey = System.Web.Configuration.WebConfigurationManager.AppSettings["AIKey"];
			AppInsightsLogger.TelemetryConfigKeyName = "AIKey";
		}

        protected void Session_Start()
        {
            //  This session variable ensures that a session in generated so on the return result from a ASC a session is already in place.
            //  This could be anything but I thought this naming working well
            Session["ACS_Start"] = "ACS_START";
            //Thread.Sleep(1000);
        }
    }
}
