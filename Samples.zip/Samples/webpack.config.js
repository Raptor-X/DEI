var debug = false;
var webpack = require('webpack');
const ExtractTextPlugin = require("extract-text-webpack-plugin");

function isExternal(module) {
    var userRequest = module.userRequest;

    if (typeof userRequest !== 'string') {
        return false;
    }

    return userRequest.indexOf('bower_components') >= 0 ||
           userRequest.indexOf('node_modules') >= 0 ||
           userRequest.indexOf('libraries') >= 0;
}

module.exports = {
  context: __dirname,
  entry: "./app/main.ts",
  output: {
    path: __dirname + "/js",
    filename: "scripts.min.js"
  },
  plugins: debug ? [] : [
    new webpack.optimize.DedupePlugin(),
    new webpack.optimize.UglifyJsPlugin({ mangle: false, sourcemap: false }),
    new webpack.optimize.CommonsChunkPlugin({
        name: 'vendors',
        filename: "vendors.js",
        minChunks: function (module) {
            return isExternal(module);
        }
    })
  ],
  module: {
      rules: [
        {
            test: /\.ts$/,
            loaders: [{
                loader: 'awesome-typescript-loader'
            }, 'angular2-template-loader']
        },
        {
            test: /\.html$/,
            loader: 'html-loader'
        },
        { test: /\.css$/, loader: 'css-to-string-loader!css-loader' },
        {
              test: /\.(png|jpg|gif)$/,
              loader: "url-loader?limit=500000&name=img/img-[hash:6].[ext]"
         }

      ]
  }
};