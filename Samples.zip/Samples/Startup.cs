﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(MyUL.Samples.Startup))]
namespace MyUL.Samples
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
