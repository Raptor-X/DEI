﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MyUL.Samples.Controllers
{
    [SessionState(System.Web.SessionState.SessionStateBehavior.Disabled)]
    public class TrafficManagerController : Controller
    {
        // GET: TrafficManager
        [AllowAnonymous]
        [HttpGet]
        public ActionResult Index()
        {
            if (Session == null)
            {
                return Json(new { success = "true" }, JsonRequestBehavior.AllowGet);
            }
            else
            {
                return Json(new { success = "false" }, JsonRequestBehavior.AllowGet);
            }
        }
    }
}