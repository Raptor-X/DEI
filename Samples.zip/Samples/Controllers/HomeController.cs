﻿using MyUL.Data;
using MyUL.Data.Authorization;
using MyUL.Data.Domain;
using UL.IO.Domain;
using UL.IO.Shared.Utilities;
using System;
using System.Collections.Generic;
using System.Collections;
using System.Configuration;
using System.Security.Claims;
using System.Web.Mvc;
using System.Linq;

namespace MyUL.Samples.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private string tenantName;
        private string resourceUri;
        private string clientId;
        private string clientSecret;
        private string authority;
        private string subscriptionKey;

        private const string locale = "en-US";
        private const string partyNumberType = "PSN";
        private const string appName = "Samples";
        private const string serviceError = "Unable to connect to the service, please try again later";
        private const string permissionError = "You do not have access to view this information";
        private IUserEntitlement userEntitlement;
        private DAL dal;

        public HomeController()
        {
            tenantName = ConfigurationManager.AppSettings["TenantName"];
            resourceUri = ConfigurationManager.AppSettings["ResourceUri"];
            clientId = ConfigurationManager.AppSettings["ida:ClientId"];
            clientSecret = ConfigurationManager.AppSettings["ida:ClientSecret"];
            authority = ConfigurationManager.AppSettings["ida:AADInstance"] + ConfigurationManager.AppSettings["ida:Domain"];
            subscriptionKey = ConfigurationManager.AppSettings["SubscriptionKey"];
            userEntitlement = new UserEntitlement();
            dal = new DAL(tenantName, resourceUri, clientId, clientSecret, authority, subscriptionKey);

        }
        public ActionResult Index()
        {
            UserClaims user = null;
            try
            {
                IUserEntitlement CurrentUser = Session["userEntitlement"] as IUserEntitlement;
                user = new UserClaims(this.User as ClaimsPrincipal);

                if (CurrentUser == null)
                {
                    UlLogger.Log(string.Format("MyUL.Samples - Entering Home controller (Index) for user {0}", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress)), LoggingLevel.Debug);
                    userEntitlement.SetUserEntitlements(new UserClaims(this.User as ClaimsPrincipal), new DAL(tenantName, resourceUri, clientId, clientSecret, authority, subscriptionKey), Session);
                    UlLogger.Log(string.Format("MyUL.Samples - Exiting Home controller (Index) for user {0}", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress)), LoggingLevel.Debug);
                }
            }
            catch (Exception ex)
            {
                if (user == null)
                {
                    UlLogger.Log(string.Format("MyUL.Samples - Index. Error - {0}.", ex.Message), ex, LoggingLevel.Error);
                }
                else
                {
                    UlLogger.Log(string.Format("MyUL.Samples - Index. User - {0}; Error - {1}.", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress), ex.Message), ex, LoggingLevel.Error);
                }
                return this.Json(new { success = false, message = ex.Message });
            }
            return View();
        }
        public JsonResult GetSampleList()
        {
            UserClaims user = null;
            SampleList listofSamples = null;
            try
            {
                user = new UserClaims(this.User as ClaimsPrincipal);
                // Debug Log Event indicating entry into Action Method
                UlLogger.Log(string.Format("MyUL.Samples - Entering Home controller (GetSampleList) for user {0}", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress)), LoggingLevel.Debug);

                List<string> psnList = userEntitlement.getPSNList(appName, Session, ULClaimUserRoles.USER);

                List<SampleList> listofSamp = new List<SampleList>();
                //Get list of PSNs and retrieve list of Quote
                if (psnList.Count > 0)
                {
                    string psns = String.Empty;

                    foreach (var ent in psnList)
                    {
                        psns = psns + ent + ",";
                    }

                    string requestUrl = ConfigurationManager.AppSettings["SampleList"];
                    requestUrl = requestUrl + "?id=" + psns.Substring(0, psns.Length - 1);
                    listofSamples = this.dal.GetSampleList(requestUrl);
                }
                else
                {
                    return this.Json(new { success = false, message = permissionError }, JsonRequestBehavior.AllowGet);
                }

                // Debug Log Event indicating exit from Action Method
                UlLogger.Log(string.Format("MyUL.Samples - Exiting Home controller (GetSampleList) for user {0}", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress)), LoggingLevel.Debug);
                return Json(new { success = true, listofSamples }, JsonRequestBehavior.AllowGet);               
            }
            catch (Exception ex)
            {
                if (user == null)
                {
                    UlLogger.Log(string.Format("MyUL.Samples - GetSampleList. Error - {0}.", ex.Message), ex, LoggingLevel.Error);
                }
                else
                {
                    UlLogger.Log(string.Format("MyUL.Samples - GetSampleList. User - {0}; Error - {1}.", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress), ex.Message), ex, LoggingLevel.Error);
                }
                return this.Json(new { success = false, message = serviceError }, JsonRequestBehavior.AllowGet);
            }
        }

        public JsonResult GetSampleDetail(string sampleNumber)
        {
            UserClaims user = null;
            try
            {
                user = new UserClaims(this.User as ClaimsPrincipal);
                UlLogger.Log(string.Format("MyUL.Samples - Entering Home controller (GetSampleDetail) for user {0}", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress)), LoggingLevel.Debug);
                string requestUrl = ConfigurationManager.AppSettings["SampleDetail"];
                requestUrl = requestUrl + "?id=" + sampleNumber;
                Sample sampleDetail = dal.GetSampleDetail(requestUrl);

                UlLogger.Log(string.Format("MyUL.Samples - Exiting Home controller (GetSampleDetail) for user {0}", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress)), LoggingLevel.Debug);
                return Json(sampleDetail, JsonRequestBehavior.AllowGet);
            }
            catch (Exception ex)
            {
                if (user == null)
                {
                    UlLogger.Log(string.Format("MyUL.Samples - GetSampleDetail. Error - {0}.", ex.Message), ex, LoggingLevel.Error);
                }
                else
                {
                    UlLogger.Log(string.Format("MyUL.Samples - GetSampleDetail. User - {0}; Error - {1}.", (String.IsNullOrEmpty(user.EmailAddress) ? "not found" : user.EmailAddress), ex.Message), ex, LoggingLevel.Error);
                }
                return this.Json(new { success = false, message = serviceError }, JsonRequestBehavior.AllowGet);
            }

        }

        /// <summary>
        /// Get Configuration details related to deeplinking
        /// </summary>		
        /// <returns>Configuration URLs</returns>
        public JsonResult GetConfiguration()
        {
            var configObject = new
            {
                naftURL = ConfigurationManager.AppSettings["parentURL"],
            };
            return this.Json(configObject, JsonRequestBehavior.AllowGet);
        }
        /// <summary>
        /// This action was generated for proper configuration of Azure Traffic Manager
        /// </summary>
        /// <returns></returns>
        [AllowAnonymous]
        [HttpGet]
        public ActionResult TrafficManager()
        {
            return Json(new { success = "true" }, JsonRequestBehavior.AllowGet);
        }
    }
}