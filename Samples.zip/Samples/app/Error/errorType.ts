﻿export enum ErrorType {
    error = <any>' No Records Found',
    NoRecord = <any>'No Records Found'
}