"use strict";
var ErrorType;
(function (ErrorType) {
    ErrorType[ErrorType["error"] = ' No Records Found'] = "error";
    ErrorType[ErrorType["NoRecord"] = 'No Records Found'] = "NoRecord";
})(ErrorType = exports.ErrorType || (exports.ErrorType = {}));
//# sourceMappingURL=errorType.js.map