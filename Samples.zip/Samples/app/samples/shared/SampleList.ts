﻿import { SampleListItem } from '../shared/samplelistitem'; 

export class SampleList {    
    ItemList: SampleListItem[];
    success: boolean;
    message: string;
}