﻿import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { Logger } from "angular2-logger/core";
import { AppConfigService } from 'ul_portal_components/app/services/appconfigservice.service';
import { UIDisplayField } from 'ul_portal_components/app/content/types/uidisplayfield.type';
import { ListColumn } from 'ul_portal_components/app/content/types/listcolumn.type';

@Injectable()
export class SamplesConfigService extends AppConfigService {

    constructor(private _logger:Logger, private _http: Http) {
        super();
        console.log(' !!!Logging!!! ');

    }
	
	getListParameters():any {
		
		var listParameters:any = new Object();
		listParameters.headerNames = new Array<ListColumn>();
		listParameters.fieldNames = new Array<any>();
		
		var obj1:any = new Object();
        obj1.columnName = "PSN";
        listParameters.headerNames.push(obj1);

        var obj2: any = new Object();
        obj2.columnName = "Creation Date";
        listParameters.headerNames.push(obj2);

        var obj3: any = new Object();
        obj3.columnName = "Quote Status";
        listParameters.headerNames.push(obj3);

        var obj4: any = new Object();
        obj4.columnName = "Quote Number";
        listParameters.headerNames.push(obj4);


		var obj5: any = new Object();
		obj5.fieldName = "PSN";
		listParameters.fieldNames.push(obj5);

		return listParameters;
		
		
	}
	
	getDetailFields() : Array<UIDisplayField> {
		var detailFields = new Array<UIDisplayField>()
		
		var detailField1:any = new UIDisplayField();
		detailField1.fieldLabel = "Quote Number";
		detailField1.dataFieldName = "QuoteNumber";
		detailField1.type = "normal";
		detailFields.push(detailField1);
		
		var detailField2 = new UIDisplayField();
		detailField2.fieldLabel = "Created On";
		detailField2.dataFieldName = "CreationDate";
		detailField2.type = "normal";
		detailFields.push(detailField2);
		
		var detailField3 = new UIDisplayField();
		detailField3.fieldLabel = "Created By";
		detailField3.dataFieldName = "CreatedBy";
		detailField3.type = "normal";
		detailFields.push(detailField3);
		
		return detailFields;
		
	}
	getAppName() {
		"Samples App"
	}
	
	getSubHeaderStatusFieldName() :any {
        return "SampleStatus";
    }
    getSubHeaderDescriptionFieldName() :any {
        return "Company";
    }
	getSubHeaderStatusFieldLabel() :any {
        return "Status";
    }   
}

