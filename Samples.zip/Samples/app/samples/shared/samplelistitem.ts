﻿export interface SampleListItem {
    SampleNumber: string;
    Description: string;
    ProjectNumber: string;
    Status: string;
    OrderNumber: string;
    CustomerName: string;
    PartySiteNumber: string;
    DispositionFlag: string;
    DispositionMethod: string;
    SampleNumberDisplaypurpose: string;
    DescriptionDisplaypurpose: string;
    ProjectNumberDisplaypurpose: string;
    StatusDisplaypurpose: string;
    OrderNumberDisplaypurpose: string;
    CustomerNameDisplaypurpose: string;
    PartySiteNumberDisplaypurpose: string;
    Cssclass: string;
    SecondCssClass: string;
    DisposalDate: string;
     
}