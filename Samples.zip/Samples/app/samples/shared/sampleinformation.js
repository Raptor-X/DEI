"use strict";
var Sampleinformation = (function () {
    function Sampleinformation() {
    }
    return Sampleinformation;
}());
exports.Sampleinformation = Sampleinformation;
//# sourceMappingURL=sampleinformation.js.map