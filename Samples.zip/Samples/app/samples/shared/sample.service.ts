﻿import { Injectable } from '@angular/core';
import { Http, Response, Headers, RequestOptions, RequestMethod, Request, URLSearchParams } from '@angular/http'
import { Observable } from 'rxjs/Observable';
import 'rxjs/add/operator/catch';
import 'rxjs/add/operator/do';
import 'rxjs/add/operator/map';
import { Logger } from "angular2-logger/core";
import { DataService } from '@ul_portal/ul_portal_components/app/services/dataservice.service';
//import { DataService } from '@ul_portal/ul_portal_components/app/services/dataservice.service';
import {SampleList } from "../shared/SampleList"
import {ISampleDetails} from './sampleDetails';

@Injectable()
export class SamplesService extends DataService {

    private sampleListUrl = 'home/GetSampleList';
    private _sampleDetailUrl = 'home/GetSampleDetail';
    private deepLinkUrls: string;

    constructor(private _logger: Logger, private _http: Http) {
        super();
        this.deepLinkUrls = 'home/GetConfiguration';
    }

    getDataSetList(): Observable<any[]> {
        return this.getSamplesList();
    }

    getDetailDataObject(id: number) {
        return this.getSampleDetail(id);
    }

    getDataServiceName() {
        return 'Samples Service';
    }

    getSamplesList(): Observable<any> {
        return this._http.get(this.sampleListUrl)
            .map((res: Response) => <any>res.json().listofSamples)
            .do(data => this._logger.info('All: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    getSampleDetail(id: number): Observable<ISampleDetails> {
        return this._http.get(this._sampleDetailUrl + "/" + id + "?" + new Date().toString())
            .map((response: Response) => <ISampleDetails>response.json().sampleDetail)
            .do(data => this._logger.info('All: ' + JSON.stringify(data)))
            .catch(this.handleError);
    }

    //getSampleDetail(sampleNumber: number): Observable<ISampleDetails> {
    //    let params: URLSearchParams = new URLSearchParams();
    //    params.set('sampleNumber', sampleNumber);
    //    return this._http.get(this._sampleDetailUrl, {
    //        search: params
    //    }).map((res: Response) => res.json())
    //        .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    //}    

    //public GetSamplesList: Observable<any> {
    //    return this._http.get(this.sampleListUrl) // ...using get request
    //        .map((res: Response) => <SampleList>res.json())
    //        .catch((error: any) => Observable.throw(error.json().error || 'Server error')); // ...and calling .json() on the response to return data 
    //}

    private handleError(error: Response) {
        return Observable.throw(error.json().error || 'Server error');
    }

    // Getting deeplink URL
    public GetConfiguration = (): Observable<SamplesService> => {
        return this._http.get(this.deepLinkUrls)
            .map((res: Response) => <SamplesService>res.json())
    }

}