﻿export class sortOption {
    constructor(public sortOptionName: string, public value: boolean) { }
}