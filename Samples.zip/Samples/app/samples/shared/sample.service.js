"use strict";
var __extends = (this && this.__extends) || function (d, b) {
    for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p];
    function __() { this.constructor = d; }
    d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
};
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/http");
var Observable_1 = require("rxjs/Observable");
require("rxjs/add/operator/catch");
require("rxjs/add/operator/do");
require("rxjs/add/operator/map");
var core_2 = require("angular2-logger/core");
var dataservice_service_1 = require("ul_portal_components/app/services/dataservice.service");
var SamplesService = (function (_super) {
    __extends(SamplesService, _super);
    function SamplesService(_logger, _http) {
        var _this = _super.call(this) || this;
        _this._logger = _logger;
        _this._http = _http;
        _this.sampleListUrl = 'home/GetSampleList';
        _this._sampleDetailUrl = 'home/GetSampleDetail';
        // Getting deeplink URL
        _this.GetConfiguration = function () {
            return _this._http.get(_this.deepLinkUrls)
                .map(function (res) { return res.json(); });
        };
        _this.deepLinkUrls = 'home/GetConfiguration';
        return _this;
    }
    SamplesService.prototype.getDataSetList = function () {
        return this.getSamplesList();
    };
    SamplesService.prototype.getDetailDataObject = function (id) {
        return this.getSampleDetail(id);
    };
    SamplesService.prototype.getDataServiceName = function () {
        return 'Samples Service';
    };
    SamplesService.prototype.getSamplesList = function () {
        var _this = this;
        return this._http.get(this.sampleListUrl)
            .map(function (res) { return res.json().listofSamples; })
            .do(function (data) { return _this._logger.info('All: ' + JSON.stringify(data)); })
            .catch(this.handleError);
    };
    SamplesService.prototype.getSampleDetail = function (id) {
        var _this = this;
        return this._http.get(this._sampleDetailUrl + "/" + id + "?" + new Date().toString())
            .map(function (response) { return response.json().sampleDetail; })
            .do(function (data) { return _this._logger.info('All: ' + JSON.stringify(data)); })
            .catch(this.handleError);
    };
    //getSampleDetail(sampleNumber: number): Observable<ISampleDetails> {
    //    let params: URLSearchParams = new URLSearchParams();
    //    params.set('sampleNumber', sampleNumber);
    //    return this._http.get(this._sampleDetailUrl, {
    //        search: params
    //    }).map((res: Response) => res.json())
    //        .catch((error: any) => Observable.throw(error.json().error || 'Server error'));
    //}    
    //public GetSamplesList: Observable<any> {
    //    return this._http.get(this.sampleListUrl) // ...using get request
    //        .map((res: Response) => <SampleList>res.json())
    //        .catch((error: any) => Observable.throw(error.json().error || 'Server error')); // ...and calling .json() on the response to return data 
    //}
    SamplesService.prototype.handleError = function (error) {
        return Observable_1.Observable.throw(error.json().error || 'Server error');
    };
    return SamplesService;
}(dataservice_service_1.DataService));
SamplesService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [core_2.Logger, http_1.Http])
], SamplesService);
exports.SamplesService = SamplesService;
//# sourceMappingURL=sample.service.js.map