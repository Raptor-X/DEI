﻿export class Sampleinformation {
    static SampleStatus: string;
   
}