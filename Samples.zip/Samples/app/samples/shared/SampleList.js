"use strict";
var SampleList = (function () {
    function SampleList() {
    }
    return SampleList;
}());
exports.SampleList = SampleList;
//# sourceMappingURL=SampleList.js.map