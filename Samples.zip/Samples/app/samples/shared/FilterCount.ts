﻿export class FilterCount {
    count: number = 0;
}