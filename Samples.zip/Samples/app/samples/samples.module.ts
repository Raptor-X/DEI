﻿import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { SamplesListComponent } from './sample-list/sample-list.component';
import { SamplesDetailComponent } from './sample-detail/sample-detail.component';
import { SamplesService } from './shared/sample.service';
import { TooltipModule } from './Shared/tooltip/tooltip.module';
import { SafeHtmlPipe } from './shared/safehtml';
import { SampleSortFilterPipe } from './filters/sample-sort-filter.pipe';
import { SampleListSearchFilterPipe } from './filters/sample-list-search-filter.pipe';
import { CustomerFilterPipe } from './filters/sample-list-customer-filer';
import { SampleListStatusFilterPipe } from './filters/sample-list-status-filter.pipe';
import { ErrorHandlerModule } from '../Error/error.module';

@NgModule({
    imports: [
        CommonModule,
        FormsModule,
        RouterModule.forChild([
            { path: 'sample-list', component: SamplesListComponent },
            { path: 'SampleDetail/:id', component: SamplesDetailComponent }
        ]),
        TooltipModule,
        ErrorHandlerModule
    ],
    declarations: [
        SamplesListComponent,
        SamplesDetailComponent,
        SampleSortFilterPipe,
        SampleListSearchFilterPipe,
        SafeHtmlPipe,
        CustomerFilterPipe,
        SampleListStatusFilterPipe
    ],
    providers: [
        SamplesService
    ]
})
export class SamplesModule { }
