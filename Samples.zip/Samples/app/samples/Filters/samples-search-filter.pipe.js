"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var SamplesSearchFilterPipe = (function () {
    function SamplesSearchFilterPipe() {
    }
    SamplesSearchFilterPipe.prototype.transform = function (value, filterBy) {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        if (value != undefined) {
            this.filteredList = filterBy ? value.filter(function (quote) {
                return quote[0].largeValue != undefined && quote[0].largeValue.toLocaleLowerCase().indexOf(filterBy) !== -1
                    || quote[2].value != undefined && quote[2].value.toLocaleLowerCase().indexOf(filterBy) !== -1
                    || quote[4].ContactName != undefined && quote[4].ContactName.toLocaleLowerCase().indexOf(filterBy) !== -1;
            }) : value;
            var filteredValue = new RegExp("(" + filterBy + ")", "gi");
            for (var _i = 0, _a = this.filteredList; _i < _a.length; _i++) {
                var item = _a[_i];
                if (item[0].largeValue) {
                    item[0].largeValue = item[0].largeValue.replace(filteredValue, "<span class='highlighted'>$1</span>");
                }
                if (item[2].value) {
                    item[2].value = item[2].value.replace(filteredValue, "<span class='highlighted'>$1</span>");
                }
                if (item[4].ContactName) {
                    item[4].ContactName = item[4].ContactName.replace(filteredValue, "<span class='highlighted'>$1</span>");
                }
            }
        }
        return this.filteredList;
    };
    return SamplesSearchFilterPipe;
}());
SamplesSearchFilterPipe = __decorate([
    core_1.Pipe({
        name: 'samplesSearchFilter'
    }),
    __metadata("design:paramtypes", [])
], SamplesSearchFilterPipe);
exports.SamplesSearchFilterPipe = SamplesSearchFilterPipe;
//# sourceMappingURL=samples-search-filter.pipe.js.map