﻿import { PipeTransform, Pipe } from '@angular/core';

@Pipe({
    name: 'samplesCustomerFilter',
    pure: false

})

export class SamplesCustomerFilterPipe implements PipeTransform {
    checkedCompanyList: any[];
    filteredValue: any[];
    transform(value: any, checkedList: any): any {
        this.checkedCompanyList = checkedList;
        if (value != undefined && checkedList.length > 0) {
            for (var i = 0; i < checkedList.length; i++) {
                this.checkedCompanyList = checkedList[i].label ? value.filter((quote: any) =>
                    quote[4].CompanyName == (checkedList[i].label)) : value; 

                this.filteredValue = (this.filteredValue != undefined) ? this.filteredValue.concat(this.checkedCompanyList) : this.checkedCompanyList;
            }
        }
        return this.filteredValue ? this.filteredValue : this.checkedCompanyList;
    }
}