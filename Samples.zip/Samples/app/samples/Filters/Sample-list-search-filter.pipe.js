"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var SampleListSearchFilterPipe = (function () {
    function SampleListSearchFilterPipe() {
        this.specials = ["-", "[", "]", "/", "{", "}", "(", ")", "*", "+", "?", ".", "\\", "^", "$", "|", "<", ">"];
        this.regex = RegExp('[' + this.specials.join('\\') + ']', 'g');
    }
    SampleListSearchFilterPipe.prototype.transform = function (value, filterBy, filteredCount) {
        filterBy = filterBy ? filterBy.toLocaleLowerCase() : null;
        if (value != undefined) {
            this.filterList = filterBy ? value.filter(function (samplelist) {
                return samplelist.Status != null && samplelist.Status != '' && samplelist.Status != undefined && samplelist.Status.toLowerCase().indexOf(filterBy) !== -1
                    || samplelist.SampleNumber != null && samplelist.SampleNumber != '' && samplelist.SampleNumber != undefined && samplelist.SampleNumber.toLowerCase().indexOf(filterBy) !== -1
                    || samplelist.Description != null && samplelist.Description != '' && samplelist.Description != undefined && samplelist.Description.toLowerCase().indexOf(filterBy) !== -1
                    || samplelist.CustomerName != null && samplelist.CustomerName != '' && samplelist.CustomerName != undefined && samplelist.CustomerName.toLowerCase().indexOf(filterBy) !== -1
                    || samplelist.ProjectNumber != null && samplelist.ProjectNumber != '' && samplelist.ProjectNumber != undefined && samplelist.ProjectNumber.toLowerCase().indexOf(filterBy) !== -1
                    || samplelist.OrderNumber != null && samplelist.OrderNumber != '' && samplelist.OrderNumber != undefined && samplelist.OrderNumber.toLowerCase().indexOf(filterBy) !== -1
                    || samplelist.PartySiteNumber != null && samplelist.PartySiteNumber != '' && samplelist.PartySiteNumber != undefined && samplelist.PartySiteNumber.toLowerCase() === filterBy;
            }) : value;
            filteredCount.count = this.filterList ? this.filterList.length : 0;
            this.filterList = this.LoadOriginalValues(this.filterList);
            if (filterBy !== null && this.filterList.length > 0) {
                this.filterList = this.formatList(this.filterList, filterBy);
            }
            return this.filterList;
        }
    };
    SampleListSearchFilterPipe.prototype.LoadOriginalValues = function (tempfilterList) {
        var _filterList = [];
        tempfilterList.forEach(function (value) {
            var temp = value;
            temp.StatusDisplaypurpose = temp.Status;
            temp.SampleNumberDisplaypurpose = temp.SampleNumber;
            temp.DescriptionDisplaypurpose = temp.Description;
            temp.CustomerNameDisplaypurpose = temp.CustomerName;
            temp.ProjectNumberDisplaypurpose = temp.ProjectNumber;
            temp.OrderNumberDisplaypurpose = temp.OrderNumber;
            temp.PartySiteNumberDisplaypurpose = temp.PartySiteNumber;
            _filterList.push(value);
        });
        return _filterList;
    };
    SampleListSearchFilterPipe.prototype.escapeRegExp = function (value) {
        return (value !== undefined && value !== null) ? value.replace(this.regex, "\\$&") : null;
    };
    SampleListSearchFilterPipe.prototype.formatList = function (tempfilterList, filterBy) {
        var _this = this;
        var _filterList = [];
        tempfilterList.forEach(function (value) {
            var temp = value;
            var customername = temp.CustomerName;
            var pattern = _this.escapeRegExp(filterBy);
            temp.StatusDisplaypurpose = (temp.Status != null) ? temp.Status.replace(new RegExp(pattern, 'i'), '<span style="background-color: #ffb31a">' + filterBy + '</span>') : "";
            temp.SampleNumberDisplaypurpose = (temp.SampleNumber !== null) ? temp.SampleNumber.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            temp.DescriptionDisplaypurpose = (temp.Description !== null) ? temp.Description.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            temp.CustomerNameDisplaypurpose = (temp.CustomerName !== null) ?
                ((temp.PartySiteNumber !== null && temp.PartySiteNumber.toLowerCase() === filterBy) ? '<span style="background-color:#ffb31a;">' + temp.CustomerName + '</span>' :
                    temp.CustomerName.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>')) : temp.CustomerName;
            temp.ProjectNumberDisplaypurpose = (temp.ProjectNumber !== null) ? temp.ProjectNumber.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            temp.OrderNumberDisplaypurpose = (temp.OrderNumber !== null) ? temp.OrderNumber.replace(new RegExp(pattern, 'i'), '<span style="background-color:#ffb31a;">' + filterBy + '</span>') : "";
            _filterList.push(temp);
        });
        return _filterList;
    };
    return SampleListSearchFilterPipe;
}());
SampleListSearchFilterPipe = __decorate([
    core_1.Pipe({
        name: 'SamplelistSearchFilter',
    }),
    __metadata("design:paramtypes", [])
], SampleListSearchFilterPipe);
exports.SampleListSearchFilterPipe = SampleListSearchFilterPipe;
//# sourceMappingURL=sample-list-search-filter.pipe.js.map