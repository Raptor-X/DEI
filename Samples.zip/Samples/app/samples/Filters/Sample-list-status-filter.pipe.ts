﻿import { PipeTransform, Pipe } from '@angular/core';
import { SampleList } from '../shared/SampleList';
import { SampleListItem } from '../shared/samplelistitem';
import { FilterCount } from '../shared/filtercount';

@Pipe({
    name: 'SampleListStatusFilter',
})

export class SampleListStatusFilterPipe implements PipeTransform {
    filterlist: SampleListItem[]
    transform(value: SampleListItem[], filteredList: string[], filteredCount: FilterCount): SampleListItem[] {
        let filteredValue: any[] = [];
        let filteredValueTemp: any[] = [];

        if (filteredList.length > 0) {

            for (var i = 0; i < filteredList.length; i++) {
                if (value != undefined) {
                    filteredValue = filteredList[i] ? value.filter((samples: SampleListItem) =>
                        samples.Status.toLowerCase() === filteredList[i]) : value;
                    if (filteredValueTemp == undefined) {
                        filteredValueTemp = filteredValue;
                    }
                    else {
                        filteredValueTemp = filteredValueTemp.concat(filteredValue);
                    }
                }
            }
        }
        filteredCount.count = filteredValueTemp ? filteredValueTemp.length : value.length;
        return filteredValueTemp ? filteredValueTemp : value;
    }
}
