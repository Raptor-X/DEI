"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var common_1 = require("@angular/common");
var forms_1 = require("@angular/forms");
var sample_list_component_1 = require("./sample-list/sample-list.component");
var sample_detail_component_1 = require("./sample-detail/sample-detail.component");
var sample_service_1 = require("./shared/sample.service");
var tooltip_module_1 = require("./Shared/tooltip/tooltip.module");
var safehtml_1 = require("./shared/safehtml");
var sample_sort_filter_pipe_1 = require("./filters/sample-sort-filter.pipe");
var sample_list_search_filter_pipe_1 = require("./filters/sample-list-search-filter.pipe");
var sample_list_customer_filer_1 = require("./filters/sample-list-customer-filer");
var sample_list_status_filter_pipe_1 = require("./filters/sample-list-status-filter.pipe");
var error_module_1 = require("../Error/error.module");
var SamplesModule = (function () {
    function SamplesModule() {
    }
    return SamplesModule;
}());
SamplesModule = __decorate([
    core_1.NgModule({
        imports: [
            common_1.CommonModule,
            forms_1.FormsModule,
            router_1.RouterModule.forChild([
                { path: 'sample-list', component: sample_list_component_1.SamplesListComponent },
                { path: 'SampleDetail/:id', component: sample_detail_component_1.SamplesDetailComponent }
            ]),
            tooltip_module_1.TooltipModule,
            error_module_1.ErrorHandlerModule
        ],
        declarations: [
            sample_list_component_1.SamplesListComponent,
            sample_detail_component_1.SamplesDetailComponent,
            sample_sort_filter_pipe_1.SampleSortFilterPipe,
            sample_list_search_filter_pipe_1.SampleListSearchFilterPipe,
            safehtml_1.SafeHtmlPipe,
            sample_list_customer_filer_1.CustomerFilterPipe,
            sample_list_status_filter_pipe_1.SampleListStatusFilterPipe
        ],
        providers: [
            sample_service_1.SamplesService
        ]
    }),
    __metadata("design:paramtypes", [])
], SamplesModule);
exports.SamplesModule = SamplesModule;
//# sourceMappingURL=samples.module.js.map