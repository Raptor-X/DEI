﻿import { Component, OnInit, ViewChild, ViewChildren, ElementRef, AfterViewInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { Subscription } from 'rxjs/Subscription';
import { SamplesService } from '../shared/sample.service';
import { Logger } from "angular2-logger/core";
import {ISampleDetails, SampleItem, LocationDetail} from '../shared/sampleDetails';

@Component({
    templateUrl: '../../../app/samples/sample-detail/sample-detail.component.html',
    styleUrls: ['../../../app/samples/sample-detail/sample-detail.component.css']
})

export class SamplesDetailComponent implements OnInit, AfterViewInit {

    private sub: Subscription;
    sampleNumber: number;
    loadingSpinnerURL = 'images/preload.gif';
    sampleItem: SampleItem[];
    statusColor: string;
    errorMessage: string;
    deepLinkUrl: any;
    parentURL: string = "";
    errorState: boolean = false;
    errormsg: string;
    noRecords: string = "No Records Found";

    constructor(private _route: ActivatedRoute,
        private _router: Router, private _logger: Logger, private _sampleService: SamplesService) { }

    ngOnInit(): void {
        this.sub = this._route.params.subscribe(params => {
            this.sampleNumber = params['id'];
            this.getSampleDetail(this.sampleNumber);
        });
        this.ConfigurationURL();
    }

    ngAfterViewInit() {
        this.loadingSpinnerURL = (<any>window).cdnURL + 'Global/images/preload.gif';
    }

    private ConfigurationURL() {
        this._sampleService.GetConfiguration()
            .subscribe(data => {
                this.deepLinkUrl = <SamplesService>data;
                this.parentURL = this.deepLinkUrl.naftURL;
            });
    }

    getSampleDetail(sampleNumber: number) {
        (<any>document).getElementById('loadingSampleDetail').style.display = 'inline';
        this._sampleService.getSampleDetail(sampleNumber).subscribe(
            (sample: ISampleDetails) => {
                this.sampleItem = sample.Items;
                if (sample.success != null && !sample.success) {
                    this.errormsg = sample.message;
                    this.handleError();
                }
                else if (this.sampleItem === null || this.sampleItem === undefined) {
                    this.errormsg = this.noRecords;
                    this.handleError();
                }
                else {
                    this.errorState = false;
                    //this.formatSampleData();
                    this.sampleItem[0].Status = this.getStatus(this.sampleItem[0].Status, this.sampleItem[0].DispositionMethod, this.sampleItem[0].DisposalDate);
                    if (this.sampleItem[0].Status.toUpperCase() == "RECEIVED") {
                        this.statusColor = "green";
                    } else if (this.sampleItem[0].Status.toUpperCase() == "NOT RECEIVED") {
                        this.statusColor = "blue";
                    }
                    else {
                        this.statusColor = "grey";
                    }
                }
                (<any>document).getElementById('loadingSampleDetail').style.display = 'none';

            },
            (error: any) => {
                this.handleError();
            },
            () => this._logger.info('Get all Items complete' + this.sampleItem)
        );
    }

    private handleError(): void {
        (<any>document).getElementById('loadingSampleDetail').style.display = 'none';
        this.errorState = true;
    }

    formatSampleData(): void {
        for (let item of this.sampleItem) {
            var status: string = this.getStatus(this.sampleItem[0].Status, this.sampleItem[0].DispositionMethod, this.sampleItem[0].DisposalDate);
            if (status.toUpperCase() == "RECEIVED") {
                this.statusColor = "green";

            } else if (status.toUpperCase() == "NOT RECEIVED") {
                this.statusColor = "blue";
            }
            else {
                this.statusColor = "grey";
            }
        }
    }

    sampleLinkURL() {
        let sampleUrl = "List/Samples";
        parent.postMessage(sampleUrl, this.parentURL);
    }

    private getFormattedAddress(locationDetail: LocationDetail): string {
        let fullAddress: string = "";

        fullAddress += locationDetail.AddressLine1 ? locationDetail.AddressLine1 + ', ' : '';
        fullAddress += locationDetail.AddressLine2 ? locationDetail.AddressLine2 + ', ' : '';
        fullAddress += locationDetail.AddressLine3 ? locationDetail.AddressLine3 + ', ' : '';
        fullAddress += locationDetail.AddressLine4 ? locationDetail.AddressLine4 + ', ' : '';
        fullAddress += locationDetail.AddressLine5 ? locationDetail.AddressLine5 + ', ' : '';
        fullAddress += locationDetail.AddressLine6 ? locationDetail.AddressLine6 : '';
        fullAddress = fullAddress.replace(/,\s*$/, "");

        return fullAddress;
    }

    private getStatus(status: string, dispositionMethod: string, disposalDate: Date): string {
        if (status === 'Un-received' && disposalDate == null) {
            return 'Not Received';
        }
        if ((status === 'Incomplete' || status === 'Complete' || status === 'Authorized' || status === 'In Progress' || status === 'Rejected') && disposalDate == null) {
            return 'Received';
        }
        if (dispositionMethod === 'RETURN' && disposalDate != null) {
            return 'Returned to Customer';
        }
        if (dispositionMethod === 'DESTROY' && disposalDate != null) {
            return 'Destroyed';
        }
        if (dispositionMethod === 'ARCHIVE' && disposalDate != null) {
            return 'Archived';
        }
        if (dispositionMethod === 'PICKUP' && disposalDate != null) {
            return 'Customer Picked Up';
        }

        return dispositionMethod;
    }
}