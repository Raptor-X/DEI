﻿ 
/*  System Imports  */
import { NgModule, ErrorHandler } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule } from '@angular/router';
import { Http, HttpModule, RequestOptions, XHRBackend } from '@angular/http';
import { Logger } from "angular2-logger/core";
import { AppComponent } from './app.component'; 
import { HttpService } from './services/http.service';
import { CustomErrorHandler } from './services/errorhandler.service';
import { SamplesModule } from './samples/samples.module';
import { SamplesConfigService } from '../app/samples/shared/sampleconfig.service';
import { ComponentsModule } from '@ul_portal/ul_portal_components/app/content/components.module';
import { DataService } from '@ul_portal/ul_portal_components/app/services/dataservice.service';
import { AppConfigService } from '@ul_portal/ul_portal_components/app/services/appconfigservice.service';
import { PagerService } from '@ul_portal/ul_portal_components/app/services/pager.service';

@NgModule({
    imports: [
        ComponentsModule,
        BrowserModule,
        HttpModule,
        SamplesModule,
        RouterModule.forRoot([
            { path: '', redirectTo: 'sample-list', pathMatch: 'full' },
            { path: '**', redirectTo: 'sample-list', pathMatch: 'full' }
        ]),     
    ],
    declarations: [AppComponent], 
    providers: [
        {
            provide: Http, useClass: HttpService
        },
        {
            provide: AppConfigService, useClass: SamplesConfigService
        },
        {
            provide: ErrorHandler, useClass: CustomErrorHandler
        },
        PagerService,
        Logger,        

    ],      
    bootstrap: [AppComponent]
})

export class AppModule { }

