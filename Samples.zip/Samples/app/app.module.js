"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
/*  System Imports  */
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var router_1 = require("@angular/router");
var http_1 = require("@angular/http");
var core_2 = require("angular2-logger/core");
var app_component_1 = require("./app.component");
var http_service_1 = require("./services/http.service");
var errorhandler_service_1 = require("./services/errorhandler.service");
var samples_module_1 = require("./samples/samples.module");
var sampleconfig_service_1 = require("../app/samples/shared/sampleconfig.service");
var components_module_1 = require("ul_portal_components/app/content/components.module");
var appconfigservice_service_1 = require("ul_portal_components/app/services/appconfigservice.service");
var pager_service_1 = require("ul_portal_components/app/services/pager.service");
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [
            components_module_1.ComponentsModule,
            platform_browser_1.BrowserModule,
            http_1.HttpModule,
            samples_module_1.SamplesModule,
            router_1.RouterModule.forRoot([
                { path: '', redirectTo: 'sample-list', pathMatch: 'full' },
                { path: '**', redirectTo: 'sample-list', pathMatch: 'full' }
            ]),
        ],
        declarations: [app_component_1.AppComponent],
        providers: [
            {
                provide: http_1.Http, useClass: http_service_1.HttpService
            },
            {
                provide: appconfigservice_service_1.AppConfigService, useClass: sampleconfig_service_1.SamplesConfigService
            },
            {
                provide: core_1.ErrorHandler, useClass: errorhandler_service_1.CustomErrorHandler
            },
            pager_service_1.PagerService,
            core_2.Logger,
        ],
        bootstrap: [app_component_1.AppComponent]
    }),
    __metadata("design:paramtypes", [])
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map