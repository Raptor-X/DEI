﻿using Microsoft.Owin.Security.Cookies;
using Owin;
using System.Configuration;
using Microsoft.Owin.Security.WsFederation;
using Microsoft.Owin.Security;

namespace MyUL.Samples
{
    public partial class Startup
    {
        private static string realm = ConfigurationManager.AppSettings["ida:Wtrealm"];
        private static string adfsMetadata = ConfigurationManager.AppSettings["ida:ADFSMetadata"];
        private static string appCookieName = ConfigurationManager.AppSettings["AppCookieName"];
        public void ConfigureAuth(IAppBuilder app)
        {
            app.SetDefaultSignInAsAuthenticationType(CookieAuthenticationDefaults.AuthenticationType);

            //  app.UseCookieAuthentication(new CookieAuthenticationOptions());
            // app.UseCookieAuthentication(new CookieAuthenticationOptions() { CookieName = "myUL.AdminTools" });
            app.UseCookieAuthentication(new CookieAuthenticationOptions() { CookieName = appCookieName });


            app.UseWsFederationAuthentication(
                new WsFederationAuthenticationOptions
                {
                    Wtrealm = realm,
                    MetadataAddress = adfsMetadata
                });
        }
    }
}